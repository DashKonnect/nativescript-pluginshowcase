var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var nativescript_dev_appium_1 = require("nativescript-dev-appium");
var chai_1 = require("chai");
describe("smoke test", function () {
    var driver;
    function openMenuItem(which, verifyByLabel) {
        return __awaiter(this, void 0, void 0, function () {
            var menuButton, messageLabel;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, driver.findElementByText("", 1)];
                    case 1:
                        menuButton = _a.sent();
                        return [4, menuButton.click()];
                    case 2:
                        _a.sent();
                        return [4, driver.findElementByText(which, 1)];
                    case 3:
                        messageLabel = _a.sent();
                        return [4, messageLabel.click()];
                    case 4:
                        _a.sent();
                        return [4, driver.findElementByText(verifyByLabel, 1)];
                    case 5:
                        _a.sent();
                        return [2];
                }
            });
        });
    }
    function wait(ms) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2, new Promise(function (resolve) {
                        setTimeout(function () { return resolve(); }, ms);
                    })];
            });
        });
    }
    before(function () { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, nativescript_dev_appium_1.createDriver()];
                case 1:
                    driver = _a.sent();
                    return [2];
            }
        });
    }); });
    after(function () { return __awaiter(_this, void 0, void 0, function () {
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, driver.quit()];
                case 1:
                    _a.sent();
                    return [2];
            }
        });
    }); });
    afterEach(function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(this.currentTest.state === "failed")) return [3, 2];
                        return [4, driver.logScreenshoot(this.currentTest.title)];
                    case 1:
                        _a.sent();
                        _a.label = 2;
                    case 2: return [2];
                }
            });
        });
    });
    it("should find the welcome text", function () { return __awaiter(_this, void 0, void 0, function () {
        var displayMsg, messageLabel, _a, _b;
        return __generator(this, function (_c) {
            switch (_c.label) {
                case 0:
                    displayMsg = "Thanks for installing this app,";
                    return [4, driver.findElementByText(displayMsg, 0)];
                case 1:
                    messageLabel = _c.sent();
                    _b = (_a = chai_1.assert).equal;
                    return [4, messageLabel.text()];
                case 2:
                    _b.apply(_a, [_c.sent(), displayMsg]);
                    return [2];
            }
        });
    }); });
    it("navigate to feedback", function () { return __awaiter(_this, void 0, void 0, function () {
        var shortToastButton, feedbackSuccessButton, fancyAlertSuccessButton, fancyAlertButtonText;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, openMenuItem("Feedback", "Toast")];
                case 1:
                    _a.sent();
                    return [4, driver.findElementByText("Short", 0)];
                case 2:
                    shortToastButton = _a.sent();
                    return [4, shortToastButton.click()];
                case 3:
                    _a.sent();
                    return [4, driver.findElementByText("Success, 2.5s", 0)];
                case 4:
                    feedbackSuccessButton = _a.sent();
                    return [4, feedbackSuccessButton.click()];
                case 5:
                    _a.sent();
                    return [4, wait(3500)];
                case 6:
                    _a.sent();
                    return [4, driver.findElementByText("Success", 0)];
                case 7:
                    fancyAlertSuccessButton = _a.sent();
                    return [4, fancyAlertSuccessButton.text()];
                case 8:
                    fancyAlertButtonText = _a.sent();
                    chai_1.assert.equal(fancyAlertButtonText.toLowerCase(), "success");
                    return [2];
            }
        });
    }); });
    it("navigate to input", function () { return __awaiter(_this, void 0, void 0, function () {
        var checkboxTabButton;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, openMenuItem("Input", "Drawing")];
                case 1:
                    _a.sent();
                    return [4, driver.findElementByText("Checkbox", 0)];
                case 2:
                    checkboxTabButton = _a.sent();
                    return [4, checkboxTabButton.click()];
                case 3:
                    _a.sent();
                    return [4, driver.findElementByText("React Native", 0)];
                case 4:
                    (_a.sent()).click();
                    return [4, driver.findElementByText("NativeScript", 0)];
                case 5:
                    (_a.sent()).click();
                    return [4, driver.findElementByText("React Native", 0)];
                case 6:
                    (_a.sent()).click();
                    return [4, driver.findElementByText("React Native!", 0)];
                case 7:
                    (_a.sent()).click();
                    return [4, driver.findElementByText("NativeScript!", 0)];
                case 8:
                    (_a.sent()).click();
                    return [2];
            }
        });
    }); });
    it("navigate to app icon", function () { return __awaiter(_this, void 0, void 0, function () {
        var displayMsg, buttonLabel, buttonText;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, openMenuItem("App icon", "App shortcuts")];
                case 1:
                    _a.sent();
                    displayMsg = "add deeplink to mapping";
                    return [4, driver.findElementByText(displayMsg, 0)];
                case 2:
                    buttonLabel = _a.sent();
                    return [4, buttonLabel.text()];
                case 3:
                    buttonText = _a.sent();
                    chai_1.assert.equal(buttonText.toLowerCase(), displayMsg);
                    return [2];
            }
        });
    }); });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2FtcGxlLXRlc3QuZTJlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic2FtcGxlLXRlc3QuZTJlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGlCQW9GQTs7QUFwRkEsbUVBQW9GO0FBQ3BGLDZCQUE4QjtBQUU5QixRQUFRLENBQUMsWUFBWSxFQUFFO0lBQ3JCLElBQUksTUFBb0IsQ0FBQztJQUV6QixzQkFBNEIsS0FBYSxFQUFFLGFBQXFCOzs7Ozs0QkFFM0MsV0FBTSxNQUFNLENBQUMsaUJBQWlCLENBQUMsR0FBRyxJQUF5QixFQUFBOzt3QkFBeEUsVUFBVSxHQUFHLFNBQTJEO3dCQUM5RSxXQUFNLFVBQVUsQ0FBQyxLQUFLLEVBQUUsRUFBQTs7d0JBQXhCLFNBQXdCLENBQUM7d0JBQ0osV0FBTSxNQUFNLENBQUMsaUJBQWlCLENBQUMsS0FBSyxJQUF5QixFQUFBOzt3QkFBNUUsWUFBWSxHQUFHLFNBQTZEO3dCQUNsRixXQUFNLFlBQVksQ0FBQyxLQUFLLEVBQUUsRUFBQTs7d0JBQTFCLFNBQTBCLENBQUM7d0JBQzNCLFdBQU0sTUFBTSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsSUFBeUIsRUFBQTs7d0JBQXJFLFNBQXFFLENBQUM7Ozs7O0tBQ3ZFO0lBRUQsY0FBb0IsRUFBVTs7O2dCQUM1QixXQUFPLElBQUksT0FBTyxDQUFDLFVBQUEsT0FBTzt3QkFDeEIsVUFBVSxDQUFDLGNBQU0sT0FBQSxPQUFPLEVBQUUsRUFBVCxDQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7b0JBQ2xDLENBQUMsQ0FBQyxFQUFDOzs7S0FDSjtJQUVELE1BQU0sQ0FBQzs7O3dCQUNJLFdBQU0sc0NBQVksRUFBRSxFQUFBOztvQkFBN0IsTUFBTSxHQUFHLFNBQW9CLENBQUM7Ozs7U0FDL0IsQ0FBQyxDQUFDO0lBRUgsS0FBSyxDQUFDOzs7d0JBQ0osV0FBTSxNQUFNLENBQUMsSUFBSSxFQUFFLEVBQUE7O29CQUFuQixTQUFtQixDQUFDOzs7O1NBQ3JCLENBQUMsQ0FBQztJQUVILFNBQVMsQ0FBQzs7Ozs7NkJBQ0osQ0FBQSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssS0FBSyxRQUFRLENBQUEsRUFBbkMsY0FBbUM7d0JBQ3JDLFdBQU0sTUFBTSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxFQUFBOzt3QkFBbkQsU0FBbUQsQ0FBQzs7Ozs7O0tBRXZELENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQyw4QkFBOEIsRUFBRTs7Ozs7b0JBQzNCLFVBQVUsR0FBRyxpQ0FBaUMsQ0FBQztvQkFDaEMsV0FBTSxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxJQUFzQixFQUFBOztvQkFBOUUsWUFBWSxHQUFHLFNBQStEO29CQUNwRixLQUFBLENBQUEsS0FBQSxhQUFNLENBQUEsQ0FBQyxLQUFLLENBQUE7b0JBQUMsV0FBTSxZQUFZLENBQUMsSUFBSSxFQUFFLEVBQUE7O29CQUF0QyxjQUFhLFNBQXlCLEVBQUUsVUFBVSxFQUFDLENBQUM7Ozs7U0FDckQsQ0FBQyxDQUFDO0lBT0gsRUFBRSxDQUFDLHNCQUFzQixFQUFFOzs7O3dCQUN6QixXQUFNLFlBQVksQ0FBQyxVQUFVLEVBQUUsT0FBTyxDQUFDLEVBQUE7O29CQUF2QyxTQUF1QyxDQUFDO29CQUNmLFdBQU0sTUFBTSxDQUFDLGlCQUFpQixDQUFDLE9BQU8sSUFBc0IsRUFBQTs7b0JBQS9FLGdCQUFnQixHQUFHLFNBQTREO29CQUNyRixXQUFNLGdCQUFnQixDQUFDLEtBQUssRUFBRSxFQUFBOztvQkFBOUIsU0FBOEIsQ0FBQztvQkFFRCxXQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLElBQXNCLEVBQUE7O29CQUE1RixxQkFBcUIsR0FBRyxTQUFvRTtvQkFDbEcsV0FBTSxxQkFBcUIsQ0FBQyxLQUFLLEVBQUUsRUFBQTs7b0JBQW5DLFNBQW1DLENBQUM7b0JBRXBDLFdBQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFBOztvQkFBaEIsU0FBZ0IsQ0FBQztvQkFFZSxXQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxTQUFTLElBQXNCLEVBQUE7O29CQUF4Rix1QkFBdUIsR0FBRyxTQUE4RDtvQkFDekQsV0FBTSx1QkFBdUIsQ0FBQyxJQUFJLEVBQUUsRUFBQTs7b0JBQW5FLG9CQUFvQixHQUFXLFNBQW9DO29CQUN6RSxhQUFNLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDLFdBQVcsRUFBRSxFQUFFLFNBQVMsQ0FBQyxDQUFDOzs7O1NBQzdELENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQyxtQkFBbUIsRUFBRTs7Ozt3QkFDdEIsV0FBTSxZQUFZLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQyxFQUFBOztvQkFBdEMsU0FBc0MsQ0FBQztvQkFDYixXQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLElBQXNCLEVBQUE7O29CQUFuRixpQkFBaUIsR0FBRyxTQUErRDtvQkFDekYsV0FBTSxpQkFBaUIsQ0FBQyxLQUFLLEVBQUUsRUFBQTs7b0JBQS9CLFNBQStCLENBQUM7b0JBRy9CLFdBQU0sTUFBTSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsSUFBc0IsRUFBQTs7b0JBQXBFLENBQUMsU0FBbUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUM3RSxXQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLElBQXNCLEVBQUE7O29CQUFwRSxDQUFDLFNBQW1FLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQztvQkFDN0UsV0FBTSxNQUFNLENBQUMsaUJBQWlCLENBQUMsY0FBYyxJQUFzQixFQUFBOztvQkFBcEUsQ0FBQyxTQUFtRSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBRzdFLFdBQU0sTUFBTSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsSUFBc0IsRUFBQTs7b0JBQXJFLENBQUMsU0FBb0UsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUM5RSxXQUFNLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxlQUFlLElBQXNCLEVBQUE7O29CQUFyRSxDQUFDLFNBQW9FLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7OztTQUNoRixDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsc0JBQXNCLEVBQUU7Ozs7d0JBQ3pCLFdBQU0sWUFBWSxDQUFDLFVBQVUsRUFBRSxlQUFlLENBQUMsRUFBQTs7b0JBQS9DLFNBQStDLENBQUM7b0JBQzFDLFVBQVUsR0FBRyx5QkFBeUIsQ0FBQztvQkFDekIsV0FBTSxNQUFNLENBQUMsaUJBQWlCLENBQUMsVUFBVSxJQUFzQixFQUFBOztvQkFBN0UsV0FBVyxHQUFHLFNBQStEO29CQUN4RCxXQUFNLFdBQVcsQ0FBQyxJQUFJLEVBQUUsRUFBQTs7b0JBQTdDLFVBQVUsR0FBVyxTQUF3QjtvQkFDbkQsYUFBTSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUM7Ozs7U0FDcEQsQ0FBQyxDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBcHBpdW1Ecml2ZXIsIGNyZWF0ZURyaXZlciwgU2VhcmNoT3B0aW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZGV2LWFwcGl1bVwiO1xyXG5pbXBvcnQgeyBhc3NlcnQgfSBmcm9tIFwiY2hhaVwiO1xyXG5cclxuZGVzY3JpYmUoXCJzbW9rZSB0ZXN0XCIsICgpID0+IHtcclxuICBsZXQgZHJpdmVyOiBBcHBpdW1Ecml2ZXI7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIG9wZW5NZW51SXRlbSh3aGljaDogc3RyaW5nLCB2ZXJpZnlCeUxhYmVsOiBzdHJpbmcpIHtcclxuICAgIC8vIFRoZSBDaGluZXNlIGZlbGxhIGJlbG93IGlzIHRoZSBoYW1idXJnZXIgaWNvbiAoZm91bmQgaXQgYnkgcnVubmluZyBcInRucyBkZWJ1ZyBhbmRyb2lkXCIgYW5kIGluc3BlY3RpbmcgaXQgd2l0aCBDaHJvbWUpXHJcbiAgICBjb25zdCBtZW51QnV0dG9uID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KFwi75qEXCIsIFNlYXJjaE9wdGlvbnMuY29udGFpbnMpO1xyXG4gICAgYXdhaXQgbWVudUJ1dHRvbi5jbGljaygpO1xyXG4gICAgY29uc3QgbWVzc2FnZUxhYmVsID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KHdoaWNoLCBTZWFyY2hPcHRpb25zLmNvbnRhaW5zKTtcclxuICAgIGF3YWl0IG1lc3NhZ2VMYWJlbC5jbGljaygpO1xyXG4gICAgYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KHZlcmlmeUJ5TGFiZWwsIFNlYXJjaE9wdGlvbnMuY29udGFpbnMpO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gd2FpdChtczogbnVtYmVyKTogUHJvbWlzZTxhbnk+IHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiByZXNvbHZlKCksIG1zKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgYmVmb3JlKGFzeW5jICgpID0+IHtcclxuICAgIGRyaXZlciA9IGF3YWl0IGNyZWF0ZURyaXZlcigpO1xyXG4gIH0pO1xyXG5cclxuICBhZnRlcihhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBkcml2ZXIucXVpdCgpO1xyXG4gIH0pO1xyXG5cclxuICBhZnRlckVhY2goYXN5bmMgZnVuY3Rpb24gKCkge1xyXG4gICAgaWYgKHRoaXMuY3VycmVudFRlc3Quc3RhdGUgPT09IFwiZmFpbGVkXCIpIHtcclxuICAgICAgYXdhaXQgZHJpdmVyLmxvZ1NjcmVlbnNob290KHRoaXMuY3VycmVudFRlc3QudGl0bGUpO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBpdChcInNob3VsZCBmaW5kIHRoZSB3ZWxjb21lIHRleHRcIiwgYXN5bmMgKCkgPT4ge1xyXG4gICAgY29uc3QgZGlzcGxheU1zZyA9IFwiVGhhbmtzIGZvciBpbnN0YWxsaW5nIHRoaXMgYXBwLFwiO1xyXG4gICAgY29uc3QgbWVzc2FnZUxhYmVsID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KGRpc3BsYXlNc2csIFNlYXJjaE9wdGlvbnMuZXhhY3QpO1xyXG4gICAgYXNzZXJ0LmVxdWFsKGF3YWl0IG1lc3NhZ2VMYWJlbC50ZXh0KCksIGRpc3BsYXlNc2cpO1xyXG4gIH0pO1xyXG5cclxuICAvLyBpdChcInNjcmVlbnNob3QgY29tcGFyaXNvbiBzdWNjZWVkc1wiLCBhc3luYyAoKSA9PiB7XHJcbiAgLy8gICBjb25zdCBpc0Rpc3BsYXlNZXNzYWdlQ29ycmVjdCA9IGF3YWl0IGRyaXZlci5jb21wYXJlU2NyZWVuKFwiaGVsbG8td29ybGQtZGlzcGxheS5wbmdcIiwgMTAsIDAuMik7XHJcbiAgLy8gICBhc3NlcnQuaXNUcnVlKGlzRGlzcGxheU1lc3NhZ2VDb3JyZWN0LCBcIkxvb2sgYXQgaGVsbG8td29ybGQtZGlzcGxheS1kaWlmLnBuZ1wiKTtcclxuICAvLyB9KTtcclxuXHJcbiAgaXQoXCJuYXZpZ2F0ZSB0byBmZWVkYmFja1wiLCBhc3luYyAoKSA9PiB7XHJcbiAgICBhd2FpdCBvcGVuTWVudUl0ZW0oXCJGZWVkYmFja1wiLCBcIlRvYXN0XCIpO1xyXG4gICAgY29uc3Qgc2hvcnRUb2FzdEJ1dHRvbiA9IGF3YWl0IGRyaXZlci5maW5kRWxlbWVudEJ5VGV4dChcIlNob3J0XCIsIFNlYXJjaE9wdGlvbnMuZXhhY3QpO1xyXG4gICAgYXdhaXQgc2hvcnRUb2FzdEJ1dHRvbi5jbGljaygpO1xyXG5cclxuICAgIGNvbnN0IGZlZWRiYWNrU3VjY2Vzc0J1dHRvbiA9IGF3YWl0IGRyaXZlci5maW5kRWxlbWVudEJ5VGV4dChcIlN1Y2Nlc3MsIDIuNXNcIiwgU2VhcmNoT3B0aW9ucy5leGFjdCk7XHJcbiAgICBhd2FpdCBmZWVkYmFja1N1Y2Nlc3NCdXR0b24uY2xpY2soKTtcclxuICAgIC8vIHRoZSBtZXNzYWdlIG5lZWRzIHRvIGdvLCBzbyB3YWl0IGEgbGl0dGxlXHJcbiAgICBhd2FpdCB3YWl0KDM1MDApO1xyXG5cclxuICAgIGNvbnN0IGZhbmN5QWxlcnRTdWNjZXNzQnV0dG9uID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KFwiU3VjY2Vzc1wiLCBTZWFyY2hPcHRpb25zLmV4YWN0KTtcclxuICAgIGNvbnN0IGZhbmN5QWxlcnRCdXR0b25UZXh0OiBzdHJpbmcgPSBhd2FpdCBmYW5jeUFsZXJ0U3VjY2Vzc0J1dHRvbi50ZXh0KCk7XHJcbiAgICBhc3NlcnQuZXF1YWwoZmFuY3lBbGVydEJ1dHRvblRleHQudG9Mb3dlckNhc2UoKSwgXCJzdWNjZXNzXCIpO1xyXG4gIH0pO1xyXG5cclxuICBpdChcIm5hdmlnYXRlIHRvIGlucHV0XCIsIGFzeW5jICgpID0+IHtcclxuICAgIGF3YWl0IG9wZW5NZW51SXRlbShcIklucHV0XCIsIFwiRHJhd2luZ1wiKTtcclxuICAgIGNvbnN0IGNoZWNrYm94VGFiQnV0dG9uID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KFwiQ2hlY2tib3hcIiwgU2VhcmNoT3B0aW9ucy5leGFjdCk7XHJcbiAgICBhd2FpdCBjaGVja2JveFRhYkJ1dHRvbi5jbGljaygpO1xyXG5cclxuICAgIC8vIGNoZWNrYm94ZXNcclxuICAgIChhd2FpdCBkcml2ZXIuZmluZEVsZW1lbnRCeVRleHQoXCJSZWFjdCBOYXRpdmVcIiwgU2VhcmNoT3B0aW9ucy5leGFjdCkpLmNsaWNrKCk7XHJcbiAgICAoYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KFwiTmF0aXZlU2NyaXB0XCIsIFNlYXJjaE9wdGlvbnMuZXhhY3QpKS5jbGljaygpO1xyXG4gICAgKGF3YWl0IGRyaXZlci5maW5kRWxlbWVudEJ5VGV4dChcIlJlYWN0IE5hdGl2ZVwiLCBTZWFyY2hPcHRpb25zLmV4YWN0KSkuY2xpY2soKTtcclxuXHJcbiAgICAvLyByYWRpb2J1dHRvbnNcclxuICAgIChhd2FpdCBkcml2ZXIuZmluZEVsZW1lbnRCeVRleHQoXCJSZWFjdCBOYXRpdmUhXCIsIFNlYXJjaE9wdGlvbnMuZXhhY3QpKS5jbGljaygpO1xyXG4gICAgKGF3YWl0IGRyaXZlci5maW5kRWxlbWVudEJ5VGV4dChcIk5hdGl2ZVNjcmlwdCFcIiwgU2VhcmNoT3B0aW9ucy5leGFjdCkpLmNsaWNrKCk7XHJcbiAgfSk7XHJcblxyXG4gIGl0KFwibmF2aWdhdGUgdG8gYXBwIGljb25cIiwgYXN5bmMgKCkgPT4ge1xyXG4gICAgYXdhaXQgb3Blbk1lbnVJdGVtKFwiQXBwIGljb25cIiwgXCJBcHAgc2hvcnRjdXRzXCIpO1xyXG4gICAgY29uc3QgZGlzcGxheU1zZyA9IFwiYWRkIGRlZXBsaW5rIHRvIG1hcHBpbmdcIjtcclxuICAgIGNvbnN0IGJ1dHRvbkxhYmVsID0gYXdhaXQgZHJpdmVyLmZpbmRFbGVtZW50QnlUZXh0KGRpc3BsYXlNc2csIFNlYXJjaE9wdGlvbnMuZXhhY3QpO1xyXG4gICAgY29uc3QgYnV0dG9uVGV4dDogc3RyaW5nID0gYXdhaXQgYnV0dG9uTGFiZWwudGV4dCgpO1xyXG4gICAgYXNzZXJ0LmVxdWFsKGJ1dHRvblRleHQudG9Mb3dlckNhc2UoKSwgZGlzcGxheU1zZyk7XHJcbiAgfSk7XHJcbn0pO1xyXG4iXX0=