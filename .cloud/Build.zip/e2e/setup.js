var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var nativescript_dev_appium_1 = require("nativescript-dev-appium");
before("start server", function () { return __awaiter(_this, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, nativescript_dev_appium_1.startServer()];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); });
after("stop server", function () { return __awaiter(_this, void 0, void 0, function () {
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4, nativescript_dev_appium_1.stopServer()];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2V0dXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJzZXR1cC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxpQkFTQTs7QUFUQSxtRUFBa0U7QUFFbEUsTUFBTSxDQUFDLGNBQWMsRUFBRTs7O29CQUNyQixXQUFNLHFDQUFXLEVBQUUsRUFBQTs7Z0JBQW5CLFNBQW1CLENBQUM7Ozs7S0FDckIsQ0FBQyxDQUFDO0FBRUgsS0FBSyxDQUFDLGFBQWEsRUFBRTs7O29CQUNuQixXQUFNLG9DQUFVLEVBQUUsRUFBQTs7Z0JBQWxCLFNBQWtCLENBQUM7Ozs7S0FDcEIsQ0FBQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgc3RhcnRTZXJ2ZXIsIHN0b3BTZXJ2ZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWRldi1hcHBpdW1cIjtcclxuXHJcbmJlZm9yZShcInN0YXJ0IHNlcnZlclwiLCBhc3luYyAoKSA9PiB7XHJcbiAgYXdhaXQgc3RhcnRTZXJ2ZXIoKTtcclxufSk7XHJcblxyXG5hZnRlcihcInN0b3Agc2VydmVyXCIsIGFzeW5jICgpID0+IHtcclxuICBhd2FpdCBzdG9wU2VydmVyKCk7XHJcbn0pO1xyXG4iXX0=