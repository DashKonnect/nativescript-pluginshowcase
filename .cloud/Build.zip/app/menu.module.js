Object.defineProperty(exports, "__esModule", { value: true });
var common_1 = require("nativescript-angular/common");
var nativescript_angular_1 = require("nativescript-angular");
var core_1 = require("@angular/core");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var angular_1 = require("nativescript-pro-ui/sidedrawer/angular");
var menu_component_1 = require("./menu/menu.component");
var home_component_1 = require("./home/home.component");
var info_modal_1 = require("./info-modal/info-modal");
var routerConfig = [
    {
        path: "",
        component: menu_component_1.MenuComponent,
        children: [
            {
                path: "",
                component: home_component_1.HomeComponent
            },
            {
                path: "feedback",
                loadChildren: "./feedback/feedback.module#FeedbackModule"
            },
            {
                path: "mapping",
                loadChildren: "./mapping/mapping.module#MappingModule"
            },
            {
                path: "speech",
                loadChildren: "./speech/speech.module#SpeechModule"
            },
            {
                path: "input",
                loadChildren: "./input/input.module#InputModule"
            },
            {
                path: "appicon",
                loadChildren: "./appicon/appicon.module#AppIconModule"
            },
            {
                path: "ar",
                loadChildren: "./ar/ar.module#ARModule"
            },
        ]
    }
];
var MenuModule = (function () {
    function MenuModule() {
    }
    MenuModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                nativescript_angular_1.NativeScriptFormsModule,
                nativescript_angular_1.NativeScriptRouterModule,
                nativescript_angular_1.NativeScriptRouterModule.forChild(routerConfig),
                angular_1.NativeScriptUISideDrawerModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
            ],
            schemas: [core_1.NO_ERRORS_SCHEMA],
            providers: [
                nativescript_angular_1.ModalDialogService
            ],
            declarations: [
                menu_component_1.MenuComponent,
                home_component_1.HomeComponent,
                info_modal_1.InfoModalComponent,
            ],
            entryComponents: [info_modal_1.InfoModalComponent]
        })
    ], MenuModule);
    return MenuModule;
}());
exports.MenuModule = MenuModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtZW51Lm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0RBQXVFO0FBQ3ZFLDZEQUE2RztBQUM3RyxzQ0FBMkQ7QUFFM0QsdUVBQThEO0FBQzlELGtFQUF3RjtBQUN4Rix3REFBc0Q7QUFDdEQsd0RBQXNEO0FBQ3RELHNEQUE2RDtBQUU3RCxJQUFNLFlBQVksR0FBVztJQUMzQjtRQUNFLElBQUksRUFBRSxFQUFFO1FBQ1IsU0FBUyxFQUFFLDhCQUFhO1FBQ3hCLFFBQVEsRUFBRTtZQUNSO2dCQUNFLElBQUksRUFBRSxFQUFFO2dCQUNSLFNBQVMsRUFBRSw4QkFBYTthQUN6QjtZQUNEO2dCQUNFLElBQUksRUFBRSxVQUFVO2dCQUNoQixZQUFZLEVBQUUsMkNBQTJDO2FBQzFEO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsWUFBWSxFQUFFLHdDQUF3QzthQUN2RDtZQUNEO2dCQUNFLElBQUksRUFBRSxRQUFRO2dCQUNkLFlBQVksRUFBRSxxQ0FBcUM7YUFDcEQ7WUFDRDtnQkFDRSxJQUFJLEVBQUUsT0FBTztnQkFDYixZQUFZLEVBQUUsa0NBQWtDO2FBQ2pEO1lBQ0Q7Z0JBQ0UsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsWUFBWSxFQUFFLHdDQUF3QzthQUN2RDtZQUNEO2dCQUNFLElBQUksRUFBRSxJQUFJO2dCQUNWLFlBQVksRUFBRSx5QkFBeUI7YUFDeEM7U0FDRjtLQUNGO0NBQ0YsQ0FBQztBQXdCRjtJQUFBO0lBQ0EsQ0FBQztJQURZLFVBQVU7UUFyQnRCLGVBQVEsQ0FBQztZQUNSLE9BQU8sRUFBRTtnQkFDUCxpQ0FBd0I7Z0JBQ3hCLDhDQUF1QjtnQkFDdkIsK0NBQXdCO2dCQUN4QiwrQ0FBd0IsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDO2dCQUMvQyx3Q0FBOEI7Z0JBQzlCLDZDQUFpQjthQUNsQjtZQUNELE9BQU8sRUFBRSxDQUFDLHVCQUFnQixDQUFDO1lBQzNCLFNBQVMsRUFBRTtnQkFDVCx5Q0FBa0I7YUFDbkI7WUFDRCxZQUFZLEVBQUU7Z0JBQ1osOEJBQWE7Z0JBQ2IsOEJBQWE7Z0JBQ2IsK0JBQWtCO2FBQ25CO1lBQ0QsZUFBZSxFQUFFLENBQUMsK0JBQWtCLENBQUM7U0FDdEMsQ0FBQztPQUVXLFVBQVUsQ0FDdEI7SUFBRCxpQkFBQztDQUFBLEFBREQsSUFDQztBQURZLGdDQUFVIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2NvbW1vblwiO1xyXG5pbXBvcnQgeyBNb2RhbERpYWxvZ1NlcnZpY2UsIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLCBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgTmdNb2R1bGUsIE5PX0VSUk9SU19TQ0hFTUEgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBSb3V0ZXMgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IFROU0ZvbnRJY29uTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1uZ3gtZm9udGljb25cIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0VUlTaWRlRHJhd2VyTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1wcm8tdWkvc2lkZWRyYXdlci9hbmd1bGFyXCI7XHJcbmltcG9ydCB7IE1lbnVDb21wb25lbnQgfSBmcm9tIFwiLi9tZW51L21lbnUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEhvbWVDb21wb25lbnQgfSBmcm9tIFwiLi9ob21lL2hvbWUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IEluZm9Nb2RhbENvbXBvbmVudCB9IGZyb20gXCIuL2luZm8tbW9kYWwvaW5mby1tb2RhbFwiO1xyXG5cclxuY29uc3Qgcm91dGVyQ29uZmlnOiBSb3V0ZXMgPSBbXHJcbiAge1xyXG4gICAgcGF0aDogXCJcIixcclxuICAgIGNvbXBvbmVudDogTWVudUNvbXBvbmVudCxcclxuICAgIGNoaWxkcmVuOiBbXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcIlwiLFxyXG4gICAgICAgIGNvbXBvbmVudDogSG9tZUNvbXBvbmVudFxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJmZWVkYmFja1wiLFxyXG4gICAgICAgIGxvYWRDaGlsZHJlbjogXCIuL2ZlZWRiYWNrL2ZlZWRiYWNrLm1vZHVsZSNGZWVkYmFja01vZHVsZVwiXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcIm1hcHBpbmdcIixcclxuICAgICAgICBsb2FkQ2hpbGRyZW46IFwiLi9tYXBwaW5nL21hcHBpbmcubW9kdWxlI01hcHBpbmdNb2R1bGVcIlxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJzcGVlY2hcIixcclxuICAgICAgICBsb2FkQ2hpbGRyZW46IFwiLi9zcGVlY2gvc3BlZWNoLm1vZHVsZSNTcGVlY2hNb2R1bGVcIlxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJpbnB1dFwiLFxyXG4gICAgICAgIGxvYWRDaGlsZHJlbjogXCIuL2lucHV0L2lucHV0Lm1vZHVsZSNJbnB1dE1vZHVsZVwiXHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBwYXRoOiBcImFwcGljb25cIixcclxuICAgICAgICBsb2FkQ2hpbGRyZW46IFwiLi9hcHBpY29uL2FwcGljb24ubW9kdWxlI0FwcEljb25Nb2R1bGVcIlxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgcGF0aDogXCJhclwiLFxyXG4gICAgICAgIGxvYWRDaGlsZHJlbjogXCIuL2FyL2FyLm1vZHVsZSNBUk1vZHVsZVwiXHJcbiAgICAgIH0sXHJcbiAgICBdXHJcbiAgfVxyXG5dO1xyXG5cclxuLy9ub2luc3BlY3Rpb24gSlNVbnVzZWRHbG9iYWxTeW1ib2xzXHJcbkBOZ01vZHVsZSh7XHJcbiAgaW1wb3J0czogW1xyXG4gICAgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlLFxyXG4gICAgTmF0aXZlU2NyaXB0Rm9ybXNNb2R1bGUsXHJcbiAgICBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUsXHJcbiAgICBOYXRpdmVTY3JpcHRSb3V0ZXJNb2R1bGUuZm9yQ2hpbGQocm91dGVyQ29uZmlnKSxcclxuICAgIE5hdGl2ZVNjcmlwdFVJU2lkZURyYXdlck1vZHVsZSxcclxuICAgIFROU0ZvbnRJY29uTW9kdWxlLFxyXG4gIF0sXHJcbiAgc2NoZW1hczogW05PX0VSUk9SU19TQ0hFTUFdLFxyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgTW9kYWxEaWFsb2dTZXJ2aWNlXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIE1lbnVDb21wb25lbnQsXHJcbiAgICBIb21lQ29tcG9uZW50LFxyXG4gICAgSW5mb01vZGFsQ29tcG9uZW50LFxyXG4gIF0sXHJcbiAgZW50cnlDb21wb25lbnRzOiBbSW5mb01vZGFsQ29tcG9uZW50XVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIE1lbnVNb2R1bGUge1xyXG59Il19