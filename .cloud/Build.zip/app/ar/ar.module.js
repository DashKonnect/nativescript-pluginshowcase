Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var ar_routing_module_1 = require("./ar-routing.module");
var ar_component_1 = require("./ar.component");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var angular_1 = require("nativescript-drop-down/angular");
var element_registry_1 = require("nativescript-angular/element-registry");
element_registry_1.registerElement("AR", function () { return require("nativescript-ar").AR; });
var ARModule = (function () {
    function ARModule() {
    }
    ARModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                ar_routing_module_1.ARRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
                angular_1.DropDownModule
            ],
            declarations: [
                ar_component_1.ARComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], ARModule);
    return ARModule;
}());
exports.ARModule = ARModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXIubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXIubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBMkQ7QUFDM0Qsc0RBQXVFO0FBRXZFLHlEQUFzRDtBQUN0RCwrQ0FBNkM7QUFDN0MsdUVBQThEO0FBQzlELDBEQUFnRTtBQUVoRSwwRUFBd0U7QUFDeEUsa0NBQWUsQ0FBQyxJQUFJLEVBQUUsY0FBTSxPQUFBLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLEVBQUUsRUFBN0IsQ0FBNkIsQ0FBQyxDQUFDO0FBZ0IzRDtJQUFBO0lBQXdCLENBQUM7SUFBWixRQUFRO1FBZHBCLGVBQVEsQ0FBQztZQUNSLE9BQU8sRUFBRTtnQkFDUCxpQ0FBd0I7Z0JBQ3hCLG1DQUFlO2dCQUNmLDZDQUFpQjtnQkFDakIsd0JBQWM7YUFDZjtZQUNELFlBQVksRUFBRTtnQkFDWiwwQkFBVzthQUNaO1lBQ0QsT0FBTyxFQUFFO2dCQUNQLHVCQUFnQjthQUNqQjtTQUNGLENBQUM7T0FDVyxRQUFRLENBQUk7SUFBRCxlQUFDO0NBQUEsQUFBekIsSUFBeUI7QUFBWiw0QkFBUSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlLCBOT19FUlJPUlNfU0NIRU1BIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2NvbW1vblwiO1xyXG5cclxuaW1wb3J0IHsgQVJSb3V0aW5nTW9kdWxlIH0gZnJvbSBcIi4vYXItcm91dGluZy5tb2R1bGVcIjtcclxuaW1wb3J0IHsgQVJDb21wb25lbnQgfSBmcm9tIFwiLi9hci5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgVE5TRm9udEljb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LW5neC1mb250aWNvblwiO1xyXG5pbXBvcnQgeyBEcm9wRG93bk1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZHJvcC1kb3duL2FuZ3VsYXJcIjtcclxuXHJcbmltcG9ydCB7IHJlZ2lzdGVyRWxlbWVudCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9lbGVtZW50LXJlZ2lzdHJ5XCI7XHJcbnJlZ2lzdGVyRWxlbWVudChcIkFSXCIsICgpID0+IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtYXJcIikuQVIpO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXHJcbiAgICBBUlJvdXRpbmdNb2R1bGUsXHJcbiAgICBUTlNGb250SWNvbk1vZHVsZSxcclxuICAgIERyb3BEb3duTW9kdWxlXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIEFSQ29tcG9uZW50XHJcbiAgXSxcclxuICBzY2hlbWFzOiBbXHJcbiAgICBOT19FUlJPUlNfU0NIRU1BXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgQVJNb2R1bGUgeyB9XHJcbiJdfQ==