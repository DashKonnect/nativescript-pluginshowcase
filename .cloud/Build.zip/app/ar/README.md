## Augmented Reality

- [nativescript-ar](https://github.com/EddyVerbruggen/nativescript-ar)
- [nativescript-drop-down](https://github.com/PeterStaev/NativeScript-Drop-Down)
- [nativescript-insomnia](https://github.com/EddyVerbruggen/nativescript-insomnia)

<img src="../../screenshots/themes/ar.jpg" width="375px"/>