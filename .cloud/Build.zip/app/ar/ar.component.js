Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var nativescript_ar_1 = require("nativescript-ar");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var color_1 = require("tns-core-modules/color");
var flashlight = require("nativescript-flashlight");
var insomnia = require("nativescript-insomnia");
var ARComponent = (function (_super) {
    __extends(ARComponent, _super);
    function ARComponent(menuComponent, vcRef, modalService) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.firstPlaneDetected = false;
        _this.planesVisible = true;
        _this.planeDetectionActive = true;
        _this.statsEnabled = true;
        _this.flashlightActive = false;
        _this.debugLevel = nativescript_ar_1.ARDebugLevel.FEATURE_POINTS;
        _this.models = ["Box", "Sphere", "Tube", "Car", "Ball", "Tree"];
        _this.selectedModelIndex = 0;
        _this.planeMaterial = {
            diffuse: new color_1.Color("white"),
            transparency: 0.2
        };
        _this.hint = "Search for planes by pointing at a surface";
        return _this;
    }
    ARComponent.prototype.ngOnInit = function () {
        this.isSupported = nativescript_ar_1.AR.isSupported();
        if (!this.isSupported) {
            this.hint = "THIS DEVICE DOESN'T SUPPORT AR ☹️";
        }
        var drop = this.dropDown.nativeElement;
        if (this.dropDown.nativeElement.ios) {
            var pickerView = drop._listPicker;
            pickerView.backgroundColor = new color_1.Color("#444").ios;
        }
        insomnia.keepAwake().then(function () { return console.log("Insomnia is now ON"); });
    };
    ARComponent.prototype.ngOnDestroy = function () {
        insomnia.allowSleepAgain().then(function () { return console.log("Insomnia is now OFF"); });
    };
    ARComponent.prototype.togglePlaneDetection = function (args) {
        if (args.value !== null && args.value !== this.planeDetectionActive) {
            this.planeDetectionActive = args.value;
            this.ar.togglePlaneDetection(this.planeDetectionActive);
            this.debugLevel = this.planeDetectionActive ? nativescript_ar_1.ARDebugLevel.FEATURE_POINTS : nativescript_ar_1.ARDebugLevel.NONE;
        }
    };
    ARComponent.prototype.toggleFlashlight = function (args) {
        if (args.value !== null && args.value !== this.flashlightActive) {
            this.flashlightActive = args.value;
            this.flashlightActive ? flashlight.on() : flashlight.off();
        }
    };
    ARComponent.prototype.togglePlaneVisibility = function (args) {
        if (args.value !== null && args.value !== this.planesVisible) {
            this.planesVisible = args.value;
            this.ar.togglePlaneVisibility(this.planesVisible);
            this.debugLevel = this.planesVisible ? nativescript_ar_1.ARDebugLevel.FEATURE_POINTS : nativescript_ar_1.ARDebugLevel.NONE;
        }
    };
    ARComponent.prototype.toggleStats = function (args) {
        if (args.value !== null && args.value !== this.statsEnabled) {
            this.statsEnabled = args.value;
            this.ar.toggleStatistics(this.statsEnabled);
        }
    };
    ARComponent.prototype.reset = function () {
        if (this.ar) {
            this.ar.reset();
        }
        this.firstPlaneDetected = false;
        this.hint = "Search for planes by scanning a surface";
    };
    ARComponent.prototype.arLoaded = function (args) {
        this.ar = args.object;
    };
    ARComponent.prototype.planeDetected = function (args) {
        console.log("Plane detected @ " + new Date().getTime());
    };
    ARComponent.prototype.planeTapped = function (args) {
        this.hint = "Tapped at " + args.position.x + " y " + args.position.y + " z " + args.position.z;
        if (this.selectedModelIndex === 0) {
            this.addBox(args.position);
        }
        else if (this.selectedModelIndex === 1) {
            this.addSphere(args.position);
        }
        else if (this.selectedModelIndex === 2) {
            this.addTube(args.position);
        }
        else if (this.selectedModelIndex === 3) {
            this.addCar(args.position);
        }
        else if (this.selectedModelIndex === 4) {
            this.addBall(args.position);
        }
        else if (this.selectedModelIndex === 5) {
            this.addTree(args.position);
        }
    };
    ARComponent.prototype.addBox = function (position) {
        this.ar.addBox({
            materials: [{
                    diffuse: {
                        contents: "Assets.scnassets/Materials/tnsgranite/tnsgranite-diffuse.png",
                        wrapMode: "ClampToBorder"
                    }
                }],
            position: { x: position.x, y: position.y + 0.8, z: position.z },
            dimensions: 0.15,
            mass: 1,
            onTap: (function (model) {
                console.log("Box was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        }).then(function (arNode) {
            console.log("Box successfully added");
            if (arNode.ios) {
            }
        });
    };
    ARComponent.prototype.addSphere = function (position) {
        this.ar.addSphere({
            materials: [{
                    diffuse: new color_1.Color("red"),
                    normal: new color_1.Color("blue"),
                    roughness: new color_1.Color("green"),
                    specular: new color_1.Color("yellow"),
                    metalness: new color_1.Color("purple"),
                    transparency: 0.9
                }],
            position: { x: position.x, y: position.y + 1.3, z: position.z },
            radius: 0.2,
            mass: 0.01,
            onTap: (function (model) {
                console.log("Sphere was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        }).then(function (arNode) {
            console.log("Sphere successfully added at " + JSON.stringify(arNode.position));
        });
    };
    ARComponent.prototype.addTube = function (position) {
        this.ar.addTube({
            materials: [{
                    diffuse: {
                        contents: "Assets.scnassets/Materials/tnsgranite/tnsgranite-diffuse.png",
                        wrapMode: "Repeat"
                    },
                    roughness: "Assets.scnassets/Materials/tnsgranite/tnsgranite-roughness.png",
                    transparency: 1
                }],
            position: { x: position.x, y: position.y + 0.3, z: position.z },
            innerRadius: 0.2,
            outerRadius: 0.35,
            radialSegmentCount: 1000,
            height: 0.7,
            mass: 8,
            onTap: (function (model) {
                console.log("Tube was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        }).then(function (arNode) {
            console.log("Tube successfully added");
        });
    };
    ARComponent.prototype.addBall = function (position) {
        this.ar.addModel({
            name: "Models.scnassets/Ball.dae",
            position: { x: position.x, y: position.y + 1.3, z: position.z },
            scale: 0.08,
            mass: 0.2,
            onTap: (function (model) {
                console.log("Ball was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        }).then(function (arNode) {
            setTimeout(function () {
                arNode.remove();
            }, 2000);
        });
    };
    ARComponent.prototype.addCar = function (position) {
        this.ar.addModel({
            name: "Models.scnassets/Car.dae",
            position: { x: position.x, y: position.y + 0.06, z: position.z },
            scale: 0.75,
            mass: 100,
            onTap: (function (model) {
                console.log("Car was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        });
    };
    ARComponent.prototype.addTree = function (position) {
        this.ar.addModel({
            name: "Models.scnassets/Tree.dae",
            childNodeName: "Tree_lp_11",
            position: position,
            scale: 0.01,
            mass: 0.0002,
            onTap: (function (model) {
                console.log("Tree was tapped");
            }),
            onLongPress: (function (model) {
                model.remove();
            })
        });
    };
    ARComponent.prototype.getPluginInfo = function () {
        return new plugin_info_wrapper_1.PluginInfoWrapper("Is normal reality too dull for you? Augment it with the experimental plugin!", Array.of(new plugin_info_1.PluginInfo("nativescript-ar", "AR  👀", "https://github.com/EddyVerbruggen/nativescript-ar", "Proof of Concept of an AR plugin. Currently supporting ARKit (iOS), and in the future ARCore (Android) as well."), new plugin_info_1.PluginInfo("nativescript-drop-down", "DropDown", "https://github.com/PeterStaev/NativeScript-Drop-Down", "The DropDown displays items from which the user can select one. If the built-in ActionSheet is not to your liking, give this one a try!"), new plugin_info_1.PluginInfo("nativescript-flashlight", "Flashlight  🔦", "https://github.com/tjvantoll/nativescript-flashlight/", "Use the device torch in your app!"), new plugin_info_1.PluginInfo("nativescript-insomnia", "Insomnia  😪", "https://github.com/EddyVerbruggen/nativescript-insomnia", "Keep the device awake (not dim the screen, lock, etc). Useful if the user needs to see stuff on the device but doesn't touch it.")));
    };
    __decorate([
        core_1.ViewChild("dropDown"),
        __metadata("design:type", core_1.ElementRef)
    ], ARComponent.prototype, "dropDown", void 0);
    ARComponent = __decorate([
        core_1.Component({
            selector: "page-ar",
            moduleId: module.id,
            templateUrl: "./ar.component.html",
            styleUrls: ["ar-common.css"],
            animations: [
                animations_1.trigger("flyInOut", [
                    animations_1.state("in", animations_1.style({ transform: "scale(1)", opacity: 1 })),
                    animations_1.transition("void => *", [
                        animations_1.style({ transform: "scale(0.9)", opacity: 0 }),
                        animations_1.animate("1000ms 100ms ease-out")
                    ])
                ]),
                animations_1.trigger("from-right", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translate(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translate(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("600ms 1500ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService])
    ], ARComponent);
    return ARComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.ARComponent = ARComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXIuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiYXIuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBc0c7QUFDdEcsa0RBQWlGO0FBQ2pGLGdGQUE0RTtBQUM1RSx5REFBdUQ7QUFDdkQsbURBQTJHO0FBQzNHLDZEQUEwRDtBQUMxRCxxREFBbUQ7QUFDbkQscUVBQWtFO0FBR2xFLGdEQUErQztBQUMvQyxJQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQztBQUN0RCxJQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQztBQTRCbEQ7SUFBaUMsK0JBQXlCO0lBeUJ4RCxxQkFBc0IsYUFBNEIsRUFDNUIsS0FBdUIsRUFDdkIsWUFBZ0M7UUFGdEQsWUFHRSxrQkFBTSxhQUFhLEVBQUUsS0FBSyxFQUFFLFlBQVksQ0FBQyxTQUUxQztRQUxxQixtQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUM1QixXQUFLLEdBQUwsS0FBSyxDQUFrQjtRQUN2QixrQkFBWSxHQUFaLFlBQVksQ0FBb0I7UUF6QjlDLHdCQUFrQixHQUFZLEtBQUssQ0FBQztRQUc1QyxtQkFBYSxHQUFZLElBQUksQ0FBQztRQUM5QiwwQkFBb0IsR0FBWSxJQUFJLENBQUM7UUFDckMsa0JBQVksR0FBWSxJQUFJLENBQUM7UUFDN0Isc0JBQWdCLEdBQVksS0FBSyxDQUFDO1FBRWxDLGdCQUFVLEdBQWlCLDhCQUFZLENBQUMsY0FBYyxDQUFDO1FBRXZELFlBQU0sR0FBa0IsQ0FBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBQ3pFLHdCQUFrQixHQUFHLENBQUMsQ0FBQztRQUt2QixtQkFBYSxHQUFlO1lBQzFCLE9BQU8sRUFBRSxJQUFJLGFBQUssQ0FBQyxPQUFPLENBQUM7WUFDM0IsWUFBWSxFQUFFLEdBQUc7U0FDbEIsQ0FBQztRQVFBLEtBQUksQ0FBQyxJQUFJLEdBQUcsNENBQTRDLENBQUM7O0lBQzNELENBQUM7SUFFRCw4QkFBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFdBQVcsR0FBRyxvQkFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRXBDLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUM7WUFDdEIsSUFBSSxDQUFDLElBQUksR0FBRyxtQ0FBbUMsQ0FBQztRQUNsRCxDQUFDO1FBR0QsSUFBTSxJQUFJLEdBQVEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUM7UUFDOUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUNwQyxJQUFNLFVBQVUsR0FBaUIsSUFBSSxDQUFDLFdBQVcsQ0FBQztZQUNsRCxVQUFVLENBQUMsZUFBZSxHQUFHLElBQUksYUFBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsQ0FBQztRQUNyRCxDQUFDO1FBRUQsUUFBUSxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxjQUFNLE9BQUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxFQUFqQyxDQUFpQyxDQUFDLENBQUM7SUFDckUsQ0FBQztJQUVELGlDQUFXLEdBQVg7UUFDRSxRQUFRLENBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxDQUFDLGNBQU0sT0FBQSxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLEVBQWxDLENBQWtDLENBQUMsQ0FBQztJQUM1RSxDQUFDO0lBRUQsMENBQW9CLEdBQXBCLFVBQXFCLElBQXdCO1FBQzNDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUMsQ0FBQztZQUNwRSxJQUFJLENBQUMsb0JBQW9CLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUN2QyxJQUFJLENBQUMsRUFBRSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQ3hELElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixHQUFHLDhCQUFZLENBQUMsY0FBYyxHQUFHLDhCQUFZLENBQUMsSUFBSSxDQUFDO1FBQ2hHLENBQUM7SUFDSCxDQUFDO0lBRUQsc0NBQWdCLEdBQWhCLFVBQWlCLElBQXdCO1FBQ3ZDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLEtBQUssSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztZQUNoRSxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNuQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsVUFBVSxDQUFDLEVBQUUsRUFBRSxHQUFHLFVBQVUsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM3RCxDQUFDO0lBQ0gsQ0FBQztJQUVELDJDQUFxQixHQUFyQixVQUFzQixJQUF3QjtRQUM1QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsS0FBSyxLQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO1lBQzdELElBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQztZQUNoQyxJQUFJLENBQUMsRUFBRSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQztZQUNsRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLEdBQUcsOEJBQVksQ0FBQyxjQUFjLEdBQUcsOEJBQVksQ0FBQyxJQUFJLENBQUM7UUFDekYsQ0FBQztJQUNILENBQUM7SUFFRCxpQ0FBVyxHQUFYLFVBQVksSUFBd0I7UUFDbEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLElBQUksSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQztZQUM1RCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUM7WUFDL0IsSUFBSSxDQUFDLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDOUMsQ0FBQztJQUNILENBQUM7SUFFRCwyQkFBSyxHQUFMO1FBQ0UsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7WUFDWixJQUFJLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFDO1FBQ2xCLENBQUM7UUFDRCxJQUFJLENBQUMsa0JBQWtCLEdBQUcsS0FBSyxDQUFDO1FBQ2hDLElBQUksQ0FBQyxJQUFJLEdBQUcseUNBQXlDLENBQUM7SUFDeEQsQ0FBQztJQUVELDhCQUFRLEdBQVIsVUFBUyxJQUFJO1FBQ1gsSUFBSSxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDO0lBQ3hCLENBQUM7SUFFRCxtQ0FBYSxHQUFiLFVBQWMsSUFBSTtRQUNoQixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixHQUFHLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUMxRCxDQUFDO0lBRUQsaUNBQVcsR0FBWCxVQUFZLElBQTRCO1FBQ3RDLElBQUksQ0FBQyxJQUFJLEdBQUcsZUFBYSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBTSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsV0FBTSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUcsQ0FBQztRQUVyRixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNsQyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM3QixDQUFDO1FBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ2hDLENBQUM7UUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDOUIsQ0FBQztRQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN6QyxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUM3QixDQUFDO1FBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3pDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQzlCLENBQUM7UUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGtCQUFrQixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDOUIsQ0FBQztJQUNILENBQUM7SUFFTyw0QkFBTSxHQUFkLFVBQWUsUUFBb0I7UUFDakMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUM7WUFDYixTQUFTLEVBQUUsQ0FBQztvQkFDVixPQUFPLEVBQUU7d0JBQ1AsUUFBUSxFQUFFLDhEQUE4RDt3QkFDeEUsUUFBUSxFQUFFLGVBQWU7cUJBQzFCO2lCQUNGLENBQUM7WUFDRixRQUFRLEVBQUUsRUFBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUM7WUFDN0QsVUFBVSxFQUFFLElBQUk7WUFDaEIsSUFBSSxFQUFFLENBQUM7WUFDUCxLQUFLLEVBQUUsQ0FBQyxVQUFDLEtBQWE7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUM7WUFDRixXQUFXLEVBQUUsQ0FBQyxVQUFDLEtBQWE7Z0JBQzFCLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNqQixDQUFDLENBQUM7U0FDSCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsTUFBTTtZQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztZQUN0QyxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUVqQixDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sK0JBQVMsR0FBakIsVUFBa0IsUUFBb0I7UUFDcEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUM7WUFDaEIsU0FBUyxFQUFFLENBQUM7b0JBQ1YsT0FBTyxFQUFFLElBQUksYUFBSyxDQUFDLEtBQUssQ0FBQztvQkFDekIsTUFBTSxFQUFFLElBQUksYUFBSyxDQUFDLE1BQU0sQ0FBQztvQkFDekIsU0FBUyxFQUFFLElBQUksYUFBSyxDQUFDLE9BQU8sQ0FBQztvQkFDN0IsUUFBUSxFQUFFLElBQUksYUFBSyxDQUFDLFFBQVEsQ0FBQztvQkFDN0IsU0FBUyxFQUFFLElBQUksYUFBSyxDQUFDLFFBQVEsQ0FBQztvQkFDOUIsWUFBWSxFQUFFLEdBQUc7aUJBQ2xCLENBQUM7WUFDRixRQUFRLEVBQUUsRUFBQyxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUM7WUFDN0QsTUFBTSxFQUFFLEdBQUc7WUFDWCxJQUFJLEVBQUUsSUFBSTtZQUNWLEtBQUssRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1lBQ25DLENBQUMsQ0FBQztZQUNGLFdBQVcsRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDMUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLENBQUMsQ0FBQztTQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxNQUFNO1lBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQ2pGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLDZCQUFPLEdBQWYsVUFBZ0IsUUFBb0I7UUFDbEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxPQUFPLENBQUM7WUFHZCxTQUFTLEVBQUUsQ0FBQztvQkFDVixPQUFPLEVBQUU7d0JBQ1AsUUFBUSxFQUFFLDhEQUE4RDt3QkFDeEUsUUFBUSxFQUFFLFFBQVE7cUJBQ25CO29CQUNELFNBQVMsRUFBRSxnRUFBZ0U7b0JBQzNFLFlBQVksRUFBRSxDQUFDO2lCQUNoQixDQUFDO1lBQ0YsUUFBUSxFQUFFLEVBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsR0FBRyxFQUFFLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDO1lBQzdELFdBQVcsRUFBRSxHQUFHO1lBQ2hCLFdBQVcsRUFBRSxJQUFJO1lBQ2pCLGtCQUFrQixFQUFFLElBQUk7WUFDeEIsTUFBTSxFQUFFLEdBQUc7WUFDWCxJQUFJLEVBQUUsQ0FBQztZQUNQLEtBQUssRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsQ0FBQztZQUNGLFdBQVcsRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDMUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLENBQUMsQ0FBQztTQUNILENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxNQUFNO1lBQ1osT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDO1FBQ3pDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLDZCQUFPLEdBQWYsVUFBZ0IsUUFBb0I7UUFDbEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUM7WUFDZixJQUFJLEVBQUUsMkJBQTJCO1lBQ2pDLFFBQVEsRUFBRSxFQUFDLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxHQUFHLEdBQUcsRUFBRSxDQUFDLEVBQUUsUUFBUSxDQUFDLENBQUMsRUFBQztZQUM3RCxLQUFLLEVBQUUsSUFBSTtZQUNYLElBQUksRUFBRSxHQUFHO1lBQ1QsS0FBSyxFQUFFLENBQUMsVUFBQyxLQUFhO2dCQUNwQixPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDakMsQ0FBQyxDQUFDO1lBQ0YsV0FBVyxFQUFFLENBQUMsVUFBQyxLQUFhO2dCQUMxQixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDakIsQ0FBQyxDQUFDO1NBQ0gsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFBLE1BQU07WUFFWixVQUFVLENBQUM7Z0JBQ1QsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2xCLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNYLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVPLDRCQUFNLEdBQWQsVUFBZSxRQUFvQjtRQUNqQyxJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztZQUNmLElBQUksRUFBRSwwQkFBMEI7WUFDaEMsUUFBUSxFQUFFLEVBQUMsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLFFBQVEsQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsRUFBRSxRQUFRLENBQUMsQ0FBQyxFQUFDO1lBQzlELEtBQUssRUFBRSxJQUFJO1lBQ1gsSUFBSSxFQUFFLEdBQUc7WUFDVCxLQUFLLEVBQUUsQ0FBQyxVQUFDLEtBQWE7Z0JBQ3BCLE9BQU8sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztZQUNoQyxDQUFDLENBQUM7WUFDRixXQUFXLEVBQUUsQ0FBQyxVQUFDLEtBQWE7Z0JBQzFCLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztZQUNqQixDQUFDLENBQUM7U0FDSCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sNkJBQU8sR0FBZixVQUFnQixRQUFvQjtRQUNsQyxJQUFJLENBQUMsRUFBRSxDQUFDLFFBQVEsQ0FBQztZQUNmLElBQUksRUFBRSwyQkFBMkI7WUFDakMsYUFBYSxFQUFFLFlBQVk7WUFDM0IsUUFBUSxFQUFFLFFBQVE7WUFDbEIsS0FBSyxFQUFFLElBQUk7WUFDWCxJQUFJLEVBQUUsTUFBTTtZQUNaLEtBQUssRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDcEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ2pDLENBQUMsQ0FBQztZQUNGLFdBQVcsRUFBRSxDQUFDLFVBQUMsS0FBYTtnQkFDMUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO1lBQ2pCLENBQUMsQ0FBQztTQUNILENBQUMsQ0FBQztJQUNMLENBQUM7SUFFUyxtQ0FBYSxHQUF2QjtRQUNFLE1BQU0sQ0FBQyxJQUFJLHVDQUFpQixDQUN4Qiw4RUFBOEUsRUFDOUUsS0FBSyxDQUFDLEVBQUUsQ0FDSixJQUFJLHdCQUFVLENBQ1YsaUJBQWlCLEVBQ2pCLFFBQVEsRUFDUixtREFBbUQsRUFDbkQsaUhBQWlILENBQ3BILEVBQ0QsSUFBSSx3QkFBVSxDQUNWLHdCQUF3QixFQUN4QixVQUFVLEVBQ1Ysc0RBQXNELEVBQ3RELHlJQUF5SSxDQUM1SSxFQUNELElBQUksd0JBQVUsQ0FDVix5QkFBeUIsRUFDekIsZ0JBQWdCLEVBQ2hCLHVEQUF1RCxFQUN2RCxtQ0FBbUMsQ0FDdEMsRUFDRCxJQUFJLHdCQUFVLENBQ1YsdUJBQXVCLEVBQ3ZCLGNBQWMsRUFDZCx5REFBeUQsRUFDekQsa0lBQWtJLENBQ3JJLENBQ0osQ0FDSixDQUFDO0lBQ0osQ0FBQztJQTdQc0I7UUFBdEIsZ0JBQVMsQ0FBQyxVQUFVLENBQUM7a0NBQVcsaUJBQVU7aURBQUM7SUF2QmpDLFdBQVc7UUExQnZCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsU0FBUztZQUNuQixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLHFCQUFxQjtZQUNsQyxTQUFTLEVBQUUsQ0FBQyxlQUFlLENBQUM7WUFDNUIsVUFBVSxFQUFFO2dCQUNWLG9CQUFPLENBQUMsVUFBVSxFQUFFO29CQUNsQixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDLEVBQUMsU0FBUyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFDLENBQUMsQ0FBQztvQkFDdkQsdUJBQVUsQ0FBQyxXQUFXLEVBQUU7d0JBQ3RCLGtCQUFLLENBQUMsRUFBQyxTQUFTLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUMsQ0FBQzt3QkFDNUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQztxQkFDakMsQ0FBQztpQkFDSCxDQUFDO2dCQUNGLG9CQUFPLENBQUMsWUFBWSxFQUFFO29CQUNwQixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQzt3QkFDWixTQUFTLEVBQUUsY0FBYztxQkFDMUIsQ0FBQyxDQUFDO29CQUNILGtCQUFLLENBQUMsTUFBTSxFQUFFLGtCQUFLLENBQUM7d0JBQ2xCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxnQkFBZ0I7cUJBQzVCLENBQUMsQ0FBQztvQkFDSCx1QkFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDLG9CQUFPLENBQUMsdUJBQXVCLENBQUMsQ0FBQyxDQUFDO2lCQUM1RCxDQUFDO2FBQ0g7U0FDRixDQUFDO3lDQTBCcUMsOEJBQWE7WUFDckIsdUJBQWdCO1lBQ1QseUNBQWtCO09BM0IzQyxXQUFXLENBcVJ2QjtJQUFELGtCQUFDO0NBQUEsQUFyUkQsQ0FBaUMsd0RBQXlCLEdBcVJ6RDtBQXJSWSxrQ0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgRWxlbWVudFJlZiwgT25EZXN0cm95LCBPbkluaXQsIFZpZXdDaGlsZCwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IGFuaW1hdGUsIHN0YXRlLCBzdHlsZSwgdHJhbnNpdGlvbiwgdHJpZ2dlciB9IGZyb20gXCJAYW5ndWxhci9hbmltYXRpb25zXCI7XHJcbmltcG9ydCB7IEFic3RyYWN0TWVudVBhZ2VDb21wb25lbnQgfSBmcm9tIFwiLi4vYWJzdHJhY3QtbWVudS1wYWdlLWNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBNZW51Q29tcG9uZW50IH0gZnJvbSBcIi4uL21lbnUvbWVudS5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgQVIsIEFSRGVidWdMZXZlbCwgQVJNYXRlcmlhbCwgQVJOb2RlLCBBUlBsYW5lVGFwcGVkRXZlbnREYXRhLCBBUlBvc2l0aW9uIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hclwiO1xyXG5pbXBvcnQgeyBNb2RhbERpYWxvZ1NlcnZpY2UgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mbyB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm9cIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mb1dyYXBwZXIgfSBmcm9tIFwiLi4vc2hhcmVkL3BsdWdpbi1pbmZvLXdyYXBwZXJcIjtcclxuaW1wb3J0IHsgUHJvcGVydHlDaGFuZ2VEYXRhIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvZGF0YS9vYnNlcnZhYmxlXCI7XHJcbmltcG9ydCB7IERyb3BEb3duIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1kcm9wLWRvd25cIjtcclxuaW1wb3J0IHsgQ29sb3IgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9jb2xvclwiO1xyXG5jb25zdCBmbGFzaGxpZ2h0ID0gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1mbGFzaGxpZ2h0XCIpO1xyXG5jb25zdCBpbnNvbW5pYSA9IHJlcXVpcmUoXCJuYXRpdmVzY3JpcHQtaW5zb21uaWFcIik7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJwYWdlLWFyXCIsXHJcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICB0ZW1wbGF0ZVVybDogXCIuL2FyLmNvbXBvbmVudC5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXCJhci1jb21tb24uY3NzXCJdLFxyXG4gIGFuaW1hdGlvbnM6IFtcclxuICAgIHRyaWdnZXIoXCJmbHlJbk91dFwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe3RyYW5zZm9ybTogXCJzY2FsZSgxKVwiLCBvcGFjaXR5OiAxfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFtcclxuICAgICAgICBzdHlsZSh7dHJhbnNmb3JtOiBcInNjYWxlKDAuOSlcIiwgb3BhY2l0eTogMH0pLFxyXG4gICAgICAgIGFuaW1hdGUoXCIxMDAwbXMgMTAwbXMgZWFzZS1vdXRcIilcclxuICAgICAgXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcImZyb20tcmlnaHRcIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDApXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMjAlKVwiXHJcbiAgICAgIH0pKSxcclxuICAgICAgdHJhbnNpdGlvbihcInZvaWQgPT4gKlwiLCBbYW5pbWF0ZShcIjYwMG1zIDE1MDBtcyBlYXNlLW91dFwiKV0pXHJcbiAgICBdKVxyXG4gIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEFSQ29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RNZW51UGFnZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcclxuICBwcml2YXRlIGFyOiBBUjtcclxuICBwcml2YXRlIGZpcnN0UGxhbmVEZXRlY3RlZDogYm9vbGVhbiA9IGZhbHNlO1xyXG5cclxuICBoaW50OiBzdHJpbmc7XHJcbiAgcGxhbmVzVmlzaWJsZTogYm9vbGVhbiA9IHRydWU7XHJcbiAgcGxhbmVEZXRlY3Rpb25BY3RpdmU6IGJvb2xlYW4gPSB0cnVlO1xyXG4gIHN0YXRzRW5hYmxlZDogYm9vbGVhbiA9IHRydWU7XHJcbiAgZmxhc2hsaWdodEFjdGl2ZTogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIGlzU3VwcG9ydGVkOiBib29sZWFuO1xyXG4gIGRlYnVnTGV2ZWw6IEFSRGVidWdMZXZlbCA9IEFSRGVidWdMZXZlbC5GRUFUVVJFX1BPSU5UUztcclxuXHJcbiAgbW9kZWxzOiBBcnJheTxzdHJpbmc+ID0gW1wiQm94XCIsIFwiU3BoZXJlXCIsIFwiVHViZVwiLCBcIkNhclwiLCBcIkJhbGxcIiwgXCJUcmVlXCJdO1xyXG4gIHNlbGVjdGVkTW9kZWxJbmRleCA9IDA7XHJcblxyXG4gIC8vIEFsbCB0aGVzZSBhcmUgdmFsaWQgcGxhbmUgbWF0ZXJpYWxzOlxyXG4gIC8vIHBsYW5lTWF0ZXJpYWwgPSBcIkFzc2V0cy5zY25hc3NldHMvTWF0ZXJpYWxzL3Ryb24vdHJvbi1kaWZmdXNlLnBuZ1wiO1xyXG4gIC8vIHBsYW5lTWF0ZXJpYWwgPSBuZXcgQ29sb3IoXCJyZWRcIik7XHJcbiAgcGxhbmVNYXRlcmlhbCA9IDxBUk1hdGVyaWFsPntcclxuICAgIGRpZmZ1c2U6IG5ldyBDb2xvcihcIndoaXRlXCIpLFxyXG4gICAgdHJhbnNwYXJlbmN5OiAwLjJcclxuICB9O1xyXG5cclxuICBAVmlld0NoaWxkKFwiZHJvcERvd25cIikgZHJvcERvd246IEVsZW1lbnRSZWY7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBtZW51Q29tcG9uZW50OiBNZW51Q29tcG9uZW50LFxyXG4gICAgICAgICAgICAgIHByb3RlY3RlZCB2Y1JlZjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgbW9kYWxTZXJ2aWNlOiBNb2RhbERpYWxvZ1NlcnZpY2UpIHtcclxuICAgIHN1cGVyKG1lbnVDb21wb25lbnQsIHZjUmVmLCBtb2RhbFNlcnZpY2UpO1xyXG4gICAgdGhpcy5oaW50ID0gXCJTZWFyY2ggZm9yIHBsYW5lcyBieSBwb2ludGluZyBhdCBhIHN1cmZhY2VcIjtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgdGhpcy5pc1N1cHBvcnRlZCA9IEFSLmlzU3VwcG9ydGVkKCk7XHJcbiAgICAvLyBpZiB0aGlzIGlzIGZhbHNlIG9uIGEgbW9kZXJuIGlPUyAxMSBkZXZpY2UsIHJlYnVpbGQgaW4gWGNvZGVcclxuICAgIGlmICghdGhpcy5pc1N1cHBvcnRlZCkge1xyXG4gICAgICB0aGlzLmhpbnQgPSBcIlRISVMgREVWSUNFIERPRVNOJ1QgU1VQUE9SVCBBUiDimLnvuI9cIjtcclxuICAgIH1cclxuXHJcbiAgICAvLyBtb2RpZnkgdGhlIGJhY2tncm91bmQgY29sb3Igb2YgdGhlIERyb3BEb3duIHBpY2tlclxyXG4gICAgY29uc3QgZHJvcDogYW55ID0gdGhpcy5kcm9wRG93bi5uYXRpdmVFbGVtZW50O1xyXG4gICAgaWYgKHRoaXMuZHJvcERvd24ubmF0aXZlRWxlbWVudC5pb3MpIHtcclxuICAgICAgY29uc3QgcGlja2VyVmlldzogVUlQaWNrZXJWaWV3ID0gZHJvcC5fbGlzdFBpY2tlcjtcclxuICAgICAgcGlja2VyVmlldy5iYWNrZ3JvdW5kQ29sb3IgPSBuZXcgQ29sb3IoXCIjNDQ0XCIpLmlvcztcclxuICAgIH1cclxuXHJcbiAgICBpbnNvbW5pYS5rZWVwQXdha2UoKS50aGVuKCgpID0+IGNvbnNvbGUubG9nKFwiSW5zb21uaWEgaXMgbm93IE9OXCIpKTtcclxuICB9XHJcblxyXG4gIG5nT25EZXN0cm95KCk6IHZvaWQge1xyXG4gICAgaW5zb21uaWEuYWxsb3dTbGVlcEFnYWluKCkudGhlbigoKSA9PiBjb25zb2xlLmxvZyhcIkluc29tbmlhIGlzIG5vdyBPRkZcIikpO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlUGxhbmVEZXRlY3Rpb24oYXJnczogUHJvcGVydHlDaGFuZ2VEYXRhKTogdm9pZCB7XHJcbiAgICBpZiAoYXJncy52YWx1ZSAhPT0gbnVsbCAmJiBhcmdzLnZhbHVlICE9PSB0aGlzLnBsYW5lRGV0ZWN0aW9uQWN0aXZlKSB7XHJcbiAgICAgIHRoaXMucGxhbmVEZXRlY3Rpb25BY3RpdmUgPSBhcmdzLnZhbHVlO1xyXG4gICAgICB0aGlzLmFyLnRvZ2dsZVBsYW5lRGV0ZWN0aW9uKHRoaXMucGxhbmVEZXRlY3Rpb25BY3RpdmUpO1xyXG4gICAgICB0aGlzLmRlYnVnTGV2ZWwgPSB0aGlzLnBsYW5lRGV0ZWN0aW9uQWN0aXZlID8gQVJEZWJ1Z0xldmVsLkZFQVRVUkVfUE9JTlRTIDogQVJEZWJ1Z0xldmVsLk5PTkU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB0b2dnbGVGbGFzaGxpZ2h0KGFyZ3M6IFByb3BlcnR5Q2hhbmdlRGF0YSk6IHZvaWQge1xyXG4gICAgaWYgKGFyZ3MudmFsdWUgIT09IG51bGwgJiYgYXJncy52YWx1ZSAhPT0gdGhpcy5mbGFzaGxpZ2h0QWN0aXZlKSB7XHJcbiAgICAgIHRoaXMuZmxhc2hsaWdodEFjdGl2ZSA9IGFyZ3MudmFsdWU7XHJcbiAgICAgIHRoaXMuZmxhc2hsaWdodEFjdGl2ZSA/IGZsYXNobGlnaHQub24oKSA6IGZsYXNobGlnaHQub2ZmKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB0b2dnbGVQbGFuZVZpc2liaWxpdHkoYXJnczogUHJvcGVydHlDaGFuZ2VEYXRhKTogdm9pZCB7XHJcbiAgICBpZiAoYXJncy52YWx1ZSAhPT0gbnVsbCAmJiBhcmdzLnZhbHVlICE9PSB0aGlzLnBsYW5lc1Zpc2libGUpIHtcclxuICAgICAgdGhpcy5wbGFuZXNWaXNpYmxlID0gYXJncy52YWx1ZTtcclxuICAgICAgdGhpcy5hci50b2dnbGVQbGFuZVZpc2liaWxpdHkodGhpcy5wbGFuZXNWaXNpYmxlKTtcclxuICAgICAgdGhpcy5kZWJ1Z0xldmVsID0gdGhpcy5wbGFuZXNWaXNpYmxlID8gQVJEZWJ1Z0xldmVsLkZFQVRVUkVfUE9JTlRTIDogQVJEZWJ1Z0xldmVsLk5PTkU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICB0b2dnbGVTdGF0cyhhcmdzOiBQcm9wZXJ0eUNoYW5nZURhdGEpOiB2b2lkIHtcclxuICAgIGlmIChhcmdzLnZhbHVlICE9PSBudWxsICYmIGFyZ3MudmFsdWUgIT09IHRoaXMuc3RhdHNFbmFibGVkKSB7XHJcbiAgICAgIHRoaXMuc3RhdHNFbmFibGVkID0gYXJncy52YWx1ZTtcclxuICAgICAgdGhpcy5hci50b2dnbGVTdGF0aXN0aWNzKHRoaXMuc3RhdHNFbmFibGVkKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJlc2V0KCk6IHZvaWQge1xyXG4gICAgaWYgKHRoaXMuYXIpIHtcclxuICAgICAgdGhpcy5hci5yZXNldCgpO1xyXG4gICAgfVxyXG4gICAgdGhpcy5maXJzdFBsYW5lRGV0ZWN0ZWQgPSBmYWxzZTtcclxuICAgIHRoaXMuaGludCA9IFwiU2VhcmNoIGZvciBwbGFuZXMgYnkgc2Nhbm5pbmcgYSBzdXJmYWNlXCI7XHJcbiAgfVxyXG5cclxuICBhckxvYWRlZChhcmdzKTogdm9pZCB7XHJcbiAgICB0aGlzLmFyID0gYXJncy5vYmplY3Q7XHJcbiAgfVxyXG5cclxuICBwbGFuZURldGVjdGVkKGFyZ3MpOiB2b2lkIHtcclxuICAgIGNvbnNvbGUubG9nKFwiUGxhbmUgZGV0ZWN0ZWQgQCBcIiArIG5ldyBEYXRlKCkuZ2V0VGltZSgpKTtcclxuICB9XHJcblxyXG4gIHBsYW5lVGFwcGVkKGFyZ3M6IEFSUGxhbmVUYXBwZWRFdmVudERhdGEpOiB2b2lkIHtcclxuICAgIHRoaXMuaGludCA9IGBUYXBwZWQgYXQgJHthcmdzLnBvc2l0aW9uLnh9IHkgJHthcmdzLnBvc2l0aW9uLnl9IHogJHthcmdzLnBvc2l0aW9uLnp9YDtcclxuXHJcbiAgICBpZiAodGhpcy5zZWxlY3RlZE1vZGVsSW5kZXggPT09IDApIHtcclxuICAgICAgdGhpcy5hZGRCb3goYXJncy5wb3NpdGlvbik7XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2VsZWN0ZWRNb2RlbEluZGV4ID09PSAxKSB7XHJcbiAgICAgIHRoaXMuYWRkU3BoZXJlKGFyZ3MucG9zaXRpb24pO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLnNlbGVjdGVkTW9kZWxJbmRleCA9PT0gMikge1xyXG4gICAgICB0aGlzLmFkZFR1YmUoYXJncy5wb3NpdGlvbik7XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2VsZWN0ZWRNb2RlbEluZGV4ID09PSAzKSB7XHJcbiAgICAgIHRoaXMuYWRkQ2FyKGFyZ3MucG9zaXRpb24pO1xyXG4gICAgfSBlbHNlIGlmICh0aGlzLnNlbGVjdGVkTW9kZWxJbmRleCA9PT0gNCkge1xyXG4gICAgICB0aGlzLmFkZEJhbGwoYXJncy5wb3NpdGlvbik7XHJcbiAgICB9IGVsc2UgaWYgKHRoaXMuc2VsZWN0ZWRNb2RlbEluZGV4ID09PSA1KSB7XHJcbiAgICAgIHRoaXMuYWRkVHJlZShhcmdzLnBvc2l0aW9uKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByaXZhdGUgYWRkQm94KHBvc2l0aW9uOiBBUlBvc2l0aW9uKTogdm9pZCB7XHJcbiAgICB0aGlzLmFyLmFkZEJveCh7XHJcbiAgICAgIG1hdGVyaWFsczogW3tcclxuICAgICAgICBkaWZmdXNlOiB7XHJcbiAgICAgICAgICBjb250ZW50czogXCJBc3NldHMuc2NuYXNzZXRzL01hdGVyaWFscy90bnNncmFuaXRlL3Ruc2dyYW5pdGUtZGlmZnVzZS5wbmdcIixcclxuICAgICAgICAgIHdyYXBNb2RlOiBcIkNsYW1wVG9Cb3JkZXJcIlxyXG4gICAgICAgIH1cclxuICAgICAgfV0sXHJcbiAgICAgIHBvc2l0aW9uOiB7eDogcG9zaXRpb24ueCwgeTogcG9zaXRpb24ueSArIDAuOCwgejogcG9zaXRpb24uen0sXHJcbiAgICAgIGRpbWVuc2lvbnM6IDAuMTUsXHJcbiAgICAgIG1hc3M6IDEsXHJcbiAgICAgIG9uVGFwOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkJveCB3YXMgdGFwcGVkXCIpO1xyXG4gICAgICB9KSxcclxuICAgICAgb25Mb25nUHJlc3M6ICgobW9kZWw6IEFSTm9kZSkgPT4ge1xyXG4gICAgICAgIG1vZGVsLnJlbW92ZSgpO1xyXG4gICAgICB9KVxyXG4gICAgfSkudGhlbihhck5vZGUgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIkJveCBzdWNjZXNzZnVsbHkgYWRkZWRcIik7XHJcbiAgICAgIGlmIChhck5vZGUuaW9zKSB7XHJcbiAgICAgICAgLy8gZG8gc29tZXRoaW5nIGlPUyBzcGVjaWZpYyBoZXJlIGlmIHlvdSBsaWtlXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhZGRTcGhlcmUocG9zaXRpb246IEFSUG9zaXRpb24pOiB2b2lkIHtcclxuICAgIHRoaXMuYXIuYWRkU3BoZXJlKHtcclxuICAgICAgbWF0ZXJpYWxzOiBbe1xyXG4gICAgICAgIGRpZmZ1c2U6IG5ldyBDb2xvcihcInJlZFwiKSxcclxuICAgICAgICBub3JtYWw6IG5ldyBDb2xvcihcImJsdWVcIiksXHJcbiAgICAgICAgcm91Z2huZXNzOiBuZXcgQ29sb3IoXCJncmVlblwiKSxcclxuICAgICAgICBzcGVjdWxhcjogbmV3IENvbG9yKFwieWVsbG93XCIpLFxyXG4gICAgICAgIG1ldGFsbmVzczogbmV3IENvbG9yKFwicHVycGxlXCIpLFxyXG4gICAgICAgIHRyYW5zcGFyZW5jeTogMC45XHJcbiAgICAgIH1dLFxyXG4gICAgICBwb3NpdGlvbjoge3g6IHBvc2l0aW9uLngsIHk6IHBvc2l0aW9uLnkgKyAxLjMsIHo6IHBvc2l0aW9uLnp9LFxyXG4gICAgICByYWRpdXM6IDAuMixcclxuICAgICAgbWFzczogMC4wMSxcclxuICAgICAgb25UYXA6ICgobW9kZWw6IEFSTm9kZSkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiU3BoZXJlIHdhcyB0YXBwZWRcIik7XHJcbiAgICAgIH0pLFxyXG4gICAgICBvbkxvbmdQcmVzczogKChtb2RlbDogQVJOb2RlKSA9PiB7XHJcbiAgICAgICAgbW9kZWwucmVtb3ZlKCk7XHJcbiAgICAgIH0pXHJcbiAgICB9KS50aGVuKGFyTm9kZSA9PiB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiU3BoZXJlIHN1Y2Nlc3NmdWxseSBhZGRlZCBhdCBcIiArIEpTT04uc3RyaW5naWZ5KGFyTm9kZS5wb3NpdGlvbikpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFkZFR1YmUocG9zaXRpb246IEFSUG9zaXRpb24pOiB2b2lkIHtcclxuICAgIHRoaXMuYXIuYWRkVHViZSh7XHJcbiAgICAgIC8vIFRPRE8gYSB0dWJlIGFsc28gaGFzIDQgc3VyZmFjZXMgd2UgY2FuIHVzZSBkaWZmZXJlbnQgbWF0ZXJpYWxzIGZvciAoaHR0cHM6Ly9kZXZlbG9wZXIuYXBwbGUuY29tL2RvY3VtZW50YXRpb24vc2NlbmVraXQvc2NudHViZT9sYW5ndWFnZT1vYmpjKVxyXG4gICAgICAvLyBUT0RPIGEgeW91dHViZSB0ZXh0dXJlIDpQXHJcbiAgICAgIG1hdGVyaWFsczogW3tcclxuICAgICAgICBkaWZmdXNlOiB7XHJcbiAgICAgICAgICBjb250ZW50czogXCJBc3NldHMuc2NuYXNzZXRzL01hdGVyaWFscy90bnNncmFuaXRlL3Ruc2dyYW5pdGUtZGlmZnVzZS5wbmdcIixcclxuICAgICAgICAgIHdyYXBNb2RlOiBcIlJlcGVhdFwiIC8vIHdoaWNoIGlzIHRoZSBkZWZhdWx0XHJcbiAgICAgICAgfSxcclxuICAgICAgICByb3VnaG5lc3M6IFwiQXNzZXRzLnNjbmFzc2V0cy9NYXRlcmlhbHMvdG5zZ3Jhbml0ZS90bnNncmFuaXRlLXJvdWdobmVzcy5wbmdcIixcclxuICAgICAgICB0cmFuc3BhcmVuY3k6IDEgLy8gc29saWQgKHdoaWNoIGlzIHRoZSBkZWZhdWx0KVxyXG4gICAgICB9XSxcclxuICAgICAgcG9zaXRpb246IHt4OiBwb3NpdGlvbi54LCB5OiBwb3NpdGlvbi55ICsgMC4zLCB6OiBwb3NpdGlvbi56fSxcclxuICAgICAgaW5uZXJSYWRpdXM6IDAuMixcclxuICAgICAgb3V0ZXJSYWRpdXM6IDAuMzUsXHJcbiAgICAgIHJhZGlhbFNlZ21lbnRDb3VudDogMTAwMCxcclxuICAgICAgaGVpZ2h0OiAwLjcsXHJcbiAgICAgIG1hc3M6IDgsXHJcbiAgICAgIG9uVGFwOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIlR1YmUgd2FzIHRhcHBlZFwiKTtcclxuICAgICAgfSksXHJcbiAgICAgIG9uTG9uZ1ByZXNzOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBtb2RlbC5yZW1vdmUoKTtcclxuICAgICAgfSlcclxuICAgIH0pLnRoZW4oYXJOb2RlID0+IHtcclxuICAgICAgY29uc29sZS5sb2coXCJUdWJlIHN1Y2Nlc3NmdWxseSBhZGRlZFwiKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhZGRCYWxsKHBvc2l0aW9uOiBBUlBvc2l0aW9uKTogdm9pZCB7XHJcbiAgICB0aGlzLmFyLmFkZE1vZGVsKHtcclxuICAgICAgbmFtZTogXCJNb2RlbHMuc2NuYXNzZXRzL0JhbGwuZGFlXCIsXHJcbiAgICAgIHBvc2l0aW9uOiB7eDogcG9zaXRpb24ueCwgeTogcG9zaXRpb24ueSArIDEuMywgejogcG9zaXRpb24uen0sXHJcbiAgICAgIHNjYWxlOiAwLjA4LFxyXG4gICAgICBtYXNzOiAwLjIsXHJcbiAgICAgIG9uVGFwOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIkJhbGwgd2FzIHRhcHBlZFwiKTtcclxuICAgICAgfSksXHJcbiAgICAgIG9uTG9uZ1ByZXNzOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBtb2RlbC5yZW1vdmUoKTtcclxuICAgICAgfSlcclxuICAgIH0pLnRoZW4oYXJOb2RlID0+IHtcclxuICAgICAgLy8gdG8gcmVtb3ZlIGJhbGxzIGFmdGVyIGEgZmV3IHNlY29uZHMgeW91IGNhbiBkbyB0aGlzOlxyXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgICBhck5vZGUucmVtb3ZlKCk7XHJcbiAgICAgIH0sIDIwMDApO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIGFkZENhcihwb3NpdGlvbjogQVJQb3NpdGlvbik6IHZvaWQge1xyXG4gICAgdGhpcy5hci5hZGRNb2RlbCh7XHJcbiAgICAgIG5hbWU6IFwiTW9kZWxzLnNjbmFzc2V0cy9DYXIuZGFlXCIsXHJcbiAgICAgIHBvc2l0aW9uOiB7eDogcG9zaXRpb24ueCwgeTogcG9zaXRpb24ueSArIDAuMDYsIHo6IHBvc2l0aW9uLnp9LFxyXG4gICAgICBzY2FsZTogMC43NSxcclxuICAgICAgbWFzczogMTAwLFxyXG4gICAgICBvblRhcDogKChtb2RlbDogQVJOb2RlKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJDYXIgd2FzIHRhcHBlZFwiKTtcclxuICAgICAgfSksXHJcbiAgICAgIG9uTG9uZ1ByZXNzOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBtb2RlbC5yZW1vdmUoKTtcclxuICAgICAgfSlcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhZGRUcmVlKHBvc2l0aW9uOiBBUlBvc2l0aW9uKTogdm9pZCB7XHJcbiAgICB0aGlzLmFyLmFkZE1vZGVsKHtcclxuICAgICAgbmFtZTogXCJNb2RlbHMuc2NuYXNzZXRzL1RyZWUuZGFlXCIsXHJcbiAgICAgIGNoaWxkTm9kZU5hbWU6IFwiVHJlZV9scF8xMVwiLFxyXG4gICAgICBwb3NpdGlvbjogcG9zaXRpb24sXHJcbiAgICAgIHNjYWxlOiAwLjAxLFxyXG4gICAgICBtYXNzOiAwLjAwMDIsXHJcbiAgICAgIG9uVGFwOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIlRyZWUgd2FzIHRhcHBlZFwiKTtcclxuICAgICAgfSksXHJcbiAgICAgIG9uTG9uZ1ByZXNzOiAoKG1vZGVsOiBBUk5vZGUpID0+IHtcclxuICAgICAgICBtb2RlbC5yZW1vdmUoKTtcclxuICAgICAgfSlcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIGdldFBsdWdpbkluZm8oKTogUGx1Z2luSW5mb1dyYXBwZXIge1xyXG4gICAgcmV0dXJuIG5ldyBQbHVnaW5JbmZvV3JhcHBlcihcclxuICAgICAgICBcIklzIG5vcm1hbCByZWFsaXR5IHRvbyBkdWxsIGZvciB5b3U/IEF1Z21lbnQgaXQgd2l0aCB0aGUgZXhwZXJpbWVudGFsIHBsdWdpbiFcIixcclxuICAgICAgICBBcnJheS5vZihcclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1hclwiLFxyXG4gICAgICAgICAgICAgICAgXCJBUiAg7aC97bGAXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9FZGR5VmVyYnJ1Z2dlbi9uYXRpdmVzY3JpcHQtYXJcIixcclxuICAgICAgICAgICAgICAgIFwiUHJvb2Ygb2YgQ29uY2VwdCBvZiBhbiBBUiBwbHVnaW4uIEN1cnJlbnRseSBzdXBwb3J0aW5nIEFSS2l0IChpT1MpLCBhbmQgaW4gdGhlIGZ1dHVyZSBBUkNvcmUgKEFuZHJvaWQpIGFzIHdlbGwuXCJcclxuICAgICAgICAgICAgKSxcclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1kcm9wLWRvd25cIixcclxuICAgICAgICAgICAgICAgIFwiRHJvcERvd25cIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL1BldGVyU3RhZXYvTmF0aXZlU2NyaXB0LURyb3AtRG93blwiLFxyXG4gICAgICAgICAgICAgICAgXCJUaGUgRHJvcERvd24gZGlzcGxheXMgaXRlbXMgZnJvbSB3aGljaCB0aGUgdXNlciBjYW4gc2VsZWN0IG9uZS4gSWYgdGhlIGJ1aWx0LWluIEFjdGlvblNoZWV0IGlzIG5vdCB0byB5b3VyIGxpa2luZywgZ2l2ZSB0aGlzIG9uZSBhIHRyeSFcIlxyXG4gICAgICAgICAgICApLFxyXG4gICAgICAgICAgICBuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgICAgICAgIFwibmF0aXZlc2NyaXB0LWZsYXNobGlnaHRcIixcclxuICAgICAgICAgICAgICAgIFwiRmxhc2hsaWdodCAg7aC97bSmXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS90anZhbnRvbGwvbmF0aXZlc2NyaXB0LWZsYXNobGlnaHQvXCIsXHJcbiAgICAgICAgICAgICAgICBcIlVzZSB0aGUgZGV2aWNlIHRvcmNoIGluIHlvdXIgYXBwIVwiXHJcbiAgICAgICAgICAgICksXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtaW5zb21uaWFcIixcclxuICAgICAgICAgICAgICAgIFwiSW5zb21uaWEgIO2gve24qlwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vbmF0aXZlc2NyaXB0LWluc29tbmlhXCIsXHJcbiAgICAgICAgICAgICAgICBcIktlZXAgdGhlIGRldmljZSBhd2FrZSAobm90IGRpbSB0aGUgc2NyZWVuLCBsb2NrLCBldGMpLiBVc2VmdWwgaWYgdGhlIHVzZXIgbmVlZHMgdG8gc2VlIHN0dWZmIG9uIHRoZSBkZXZpY2UgYnV0IGRvZXNuJ3QgdG91Y2ggaXQuXCJcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgIClcclxuICAgICk7XHJcbiAgfVxyXG59XHJcbiJdfQ==