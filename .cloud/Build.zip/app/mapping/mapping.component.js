Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var nativescript_directions_1 = require("nativescript-directions");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var MappingComponent = (function (_super) {
    __extends(MappingComponent, _super);
    function MappingComponent(menuComponent, vcRef, modalService) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.directions = new nativescript_directions_1.Directions();
        return _this;
    }
    MappingComponent.prototype.onMapReady = function (args) {
        var _this = this;
        this.map = args.map;
        this.map.addMarkers([
            {
                id: 1,
                lat: 42.624189,
                lng: 23.372106,
                title: 'DevReach 2017',
                subtitle: 'Such an awesome little conference',
                onTap: function () {
                    console.log("DevReach 2017 was tapped");
                },
                onCalloutTap: function () {
                    console.log("DevReach 2017 callout tapped");
                }
            }, {
                id: 2,
                lat: 51.9280572,
                lng: 4.4201952,
                title: '{N} Developer day EU',
                subtitle: 'Tap to show directions (with waypoints)',
                icon: 'res://tnsmarker',
                onTap: function () {
                    console.log("{N} Developer day EU was tapped");
                },
                onCalloutTap: function () {
                    _this.showDirectionsTo([
                        {
                            lat: 52.1851585,
                            lng: 5.3974241
                        },
                        {
                            lat: 51.9280572,
                            lng: 4.4201952
                        }
                    ]);
                }
            },
            {
                id: 3,
                lat: 52.1851585,
                lng: 5.3974241,
                title: "Eddy's home",
                subtitle: "Tap to show directions",
                iconPath: "images/mapmarkers/home_marker.png",
                onTap: function () {
                    console.log("Eddy's home was tapped");
                },
                onCalloutTap: function () {
                    _this.showDirectionsTo([{
                            lat: 52.1851585,
                            lng: 5.3974241
                        }]);
                }
            },
            {
                id: 4,
                lat: 43.421834,
                lng: 24.086096,
                icon: 'res://truck1',
            },
            {
                id: 5,
                lat: 42.421834,
                lng: 26.786096,
                icon: 'res://truck2',
            },
            {
                id: 6,
                lat: 42.021834,
                lng: 25.086096,
                icon: 'res://truck3',
            }
        ]);
    };
    MappingComponent.prototype.fabTapped = function () {
        var _this = this;
        this.map.getViewport().then(function (viewport) {
            var lat = (viewport.bounds.north + viewport.bounds.south) / 2;
            var lng = (viewport.bounds.east + viewport.bounds.west) / 2;
            var markerId = new Date().getTime();
            _this.map.addMarkers([{
                    id: new Date().getTime(),
                    lat: lat,
                    lng: lng,
                    title: "FAB marker",
                    subtitle: "Tap to remove",
                    onCalloutTap: function () {
                        _this.map.removeMarkers([markerId]);
                    }
                }]);
        });
    };
    MappingComponent.prototype.showDirectionsTo = function (addresses) {
        this.directions.navigate({
            to: addresses,
            ios: {
                preferGoogleMaps: addresses.length > 1
            }
        }).then(function () {
            console.log("Maps app launched.");
        }, function (error) {
            console.log(error);
        });
    };
    MappingComponent.prototype.getPluginInfo = function () {
        return new plugin_info_wrapper_1.PluginInfoWrapper("Try a few one- and two-finger gestures. Alos, press the FAB to drop a marker at the center of the viewport.\n\nThen, when you're bored playing with the map, scroll to the center of The Netherlands and tap the Home icon. Then follow its instructions to trigger the Directions plugin!", Array.of(new plugin_info_1.PluginInfo("nativescript-mapbox", "Mapbox  🗽 🗼 🗻", "https://github.com/EddyVerbruggen/nativescript-mapbox", "Native OpenGL powered Maps. Crazy performance and feature-rich! Use custom markers and show the user's location. Here we use the map style 'traffic_day' to show live traffic!"), new plugin_info_1.PluginInfo("nativescript-directions", "Directions  👆 👉 👇 👈", "https://github.com/EddyVerbruggen/nativescript-directions", "Open the native Maps app to show directions to anywhere on 🌏 you like. Even with (multiple) waypoints in between!"), new plugin_info_1.PluginInfo("nativescript-floatingactionbutton", "FAB", "https://github.com/bradmartin/nativescript-floatingactionbutton", "Add a Material Design Floating Action Button to your page, at a corner of your liking.")));
    };
    MappingComponent = __decorate([
        core_1.Component({
            selector: "page-mapping",
            moduleId: module.id,
            templateUrl: "./mapping.component.html",
            styleUrls: ["mapping-common.css"],
            animations: [
                animations_1.trigger("flyInOut", [
                    animations_1.state("in", animations_1.style({ transform: "scale(1)", opacity: 1 })),
                    animations_1.transition("void => *", [
                        animations_1.style({ transform: "scale(0.9)", opacity: 0 }),
                        animations_1.animate("1000ms 100ms ease-out")
                    ])
                ]),
                animations_1.trigger("from-right", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translate(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translate(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("600ms 1500ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService])
    ], MappingComponent);
    return MappingComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.MappingComponent = MappingComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWFwcGluZy5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtYXBwaW5nLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQTREO0FBQzVELGtEQU02QjtBQUM3QixnRkFBNEU7QUFDNUUseURBQXVEO0FBRXZELG1FQUFxRTtBQUNyRSw2REFBMEQ7QUFDMUQscURBQW1EO0FBQ25ELHFFQUFrRTtBQTRCbEU7SUFBc0Msb0NBQXlCO0lBSzdELDBCQUFzQixhQUE0QixFQUM1QixLQUF1QixFQUN2QixZQUFnQztRQUZ0RCxZQUdFLGtCQUFNLGFBQWEsRUFBRSxLQUFLLEVBQUUsWUFBWSxDQUFDLFNBRTFDO1FBTHFCLG1CQUFhLEdBQWIsYUFBYSxDQUFlO1FBQzVCLFdBQUssR0FBTCxLQUFLLENBQWtCO1FBQ3ZCLGtCQUFZLEdBQVosWUFBWSxDQUFvQjtRQUVwRCxLQUFJLENBQUMsVUFBVSxHQUFHLElBQUksb0NBQVUsRUFBRSxDQUFDOztJQUNyQyxDQUFDO0lBRUQscUNBQVUsR0FBVixVQUFXLElBQUk7UUFBZixpQkEyRUM7UUExRUMsSUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ3BCLElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1lBQ2Q7Z0JBQ0UsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsS0FBSyxFQUFFLGVBQWU7Z0JBQ3RCLFFBQVEsRUFBRSxtQ0FBbUM7Z0JBQzdDLEtBQUssRUFBRTtvQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7Z0JBQzFDLENBQUM7Z0JBQ0QsWUFBWSxFQUFFO29CQUNaLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztnQkFDOUMsQ0FBQzthQUNGLEVBQUU7Z0JBQ0QsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsR0FBRyxFQUFFLFVBQVU7Z0JBQ2YsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsS0FBSyxFQUFFLHNCQUFzQjtnQkFDN0IsUUFBUSxFQUFFLHlDQUF5QztnQkFDbkQsSUFBSSxFQUFFLGlCQUFpQjtnQkFDdkIsS0FBSyxFQUFFO29CQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztnQkFDakQsQ0FBQztnQkFDRCxZQUFZLEVBQUU7b0JBQ1osS0FBSSxDQUFDLGdCQUFnQixDQUFDO3dCQUNwQjs0QkFDRSxHQUFHLEVBQUUsVUFBVTs0QkFDZixHQUFHLEVBQUUsU0FBUzt5QkFDZjt3QkFDRDs0QkFDRSxHQUFHLEVBQUUsVUFBVTs0QkFDZixHQUFHLEVBQUUsU0FBUzt5QkFDZjtxQkFDRixDQUFDLENBQUM7Z0JBQ0wsQ0FBQzthQUNGO1lBQ0Q7Z0JBQ0UsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsR0FBRyxFQUFFLFVBQVU7Z0JBQ2YsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsS0FBSyxFQUFFLGFBQWE7Z0JBQ3BCLFFBQVEsRUFBRSx3QkFBd0I7Z0JBQ2xDLFFBQVEsRUFBRSxtQ0FBbUM7Z0JBQzdDLEtBQUssRUFBRTtvQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7Z0JBQ3hDLENBQUM7Z0JBQ0QsWUFBWSxFQUFFO29CQUNaLEtBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzRCQUNyQixHQUFHLEVBQUUsVUFBVTs0QkFDZixHQUFHLEVBQUUsU0FBUzt5QkFDZixDQUFDLENBQUMsQ0FBQztnQkFDTixDQUFDO2FBQ0Y7WUFDRDtnQkFDRSxFQUFFLEVBQUUsQ0FBQztnQkFDTCxHQUFHLEVBQUUsU0FBUztnQkFDZCxHQUFHLEVBQUUsU0FBUztnQkFDZCxJQUFJLEVBQUUsY0FBYzthQUNyQjtZQUNEO2dCQUNFLEVBQUUsRUFBRSxDQUFDO2dCQUNMLEdBQUcsRUFBRSxTQUFTO2dCQUNkLEdBQUcsRUFBRSxTQUFTO2dCQUNkLElBQUksRUFBRSxjQUFjO2FBQ3JCO1lBQ0Q7Z0JBQ0UsRUFBRSxFQUFFLENBQUM7Z0JBQ0wsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsR0FBRyxFQUFFLFNBQVM7Z0JBQ2QsSUFBSSxFQUFFLGNBQWM7YUFDckI7U0FDRixDQUNKLENBQUM7SUFDSixDQUFDO0lBRUQsb0NBQVMsR0FBVDtRQUFBLGlCQWtCQztRQWhCQyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLFFBQXdCO1lBQ25ELElBQU0sR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDaEUsSUFBTSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUM5RCxJQUFNLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBRXRDLEtBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUM7b0JBQ25CLEVBQUUsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLE9BQU8sRUFBRTtvQkFDeEIsR0FBRyxFQUFFLEdBQUc7b0JBQ1IsR0FBRyxFQUFFLEdBQUc7b0JBQ1IsS0FBSyxFQUFFLFlBQVk7b0JBQ25CLFFBQVEsRUFBRSxlQUFlO29CQUN6QixZQUFZLEVBQUU7d0JBQ1osS0FBSSxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO29CQUNyQyxDQUFDO2lCQUNGLENBQUMsQ0FBQyxDQUFDO1FBQ04sQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU8sMkNBQWdCLEdBQXhCLFVBQXlCLFNBQWdDO1FBQ3ZELElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDO1lBQ3ZCLEVBQUUsRUFBRSxTQUFTO1lBQ2IsR0FBRyxFQUFFO2dCQUVILGdCQUFnQixFQUFFLFNBQVMsQ0FBQyxNQUFNLEdBQUcsQ0FBQzthQUN2QztTQUNGLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDTixPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7UUFDcEMsQ0FBQyxFQUFFLFVBQUEsS0FBSztZQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDckIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRVMsd0NBQWEsR0FBdkI7UUFDRSxNQUFNLENBQUMsSUFBSSx1Q0FBaUIsQ0FDeEIsNFJBQTRSLEVBQzVSLEtBQUssQ0FBQyxFQUFFLENBQ0osSUFBSSx3QkFBVSxDQUNWLHFCQUFxQixFQUNyQixrQkFBa0IsRUFDbEIsdURBQXVELEVBQ3ZELGdMQUFnTCxDQUNuTCxFQUVELElBQUksd0JBQVUsQ0FDVix5QkFBeUIsRUFDekIseUJBQXlCLEVBQ3pCLDJEQUEyRCxFQUMzRCxvSEFBb0gsQ0FDdkgsRUFFRCxJQUFJLHdCQUFVLENBQ1YsbUNBQW1DLEVBQ25DLEtBQUssRUFDTCxpRUFBaUUsRUFDakUsd0ZBQXdGLENBQzNGLENBQ0osQ0FDSixDQUFDO0lBQ0osQ0FBQztJQXJKVSxnQkFBZ0I7UUExQjVCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsY0FBYztZQUN4QixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLDBCQUEwQjtZQUN2QyxTQUFTLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQztZQUNqQyxVQUFVLEVBQUU7Z0JBQ1Ysb0JBQU8sQ0FBQyxVQUFVLEVBQUU7b0JBQ2xCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUMsRUFBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUFDO29CQUN2RCx1QkFBVSxDQUFDLFdBQVcsRUFBRTt3QkFDdEIsa0JBQUssQ0FBQyxFQUFDLFNBQVMsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBQyxDQUFDO3dCQUM1QyxvQkFBTyxDQUFDLHVCQUF1QixDQUFDO3FCQUNqQyxDQUFDO2lCQUNILENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxZQUFZLEVBQUU7b0JBQ3BCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxjQUFjO3FCQUMxQixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLGdCQUFnQjtxQkFDNUIsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7aUJBQzVELENBQUM7YUFDSDtTQUNGLENBQUM7eUNBTXFDLDhCQUFhO1lBQ3JCLHVCQUFnQjtZQUNULHlDQUFrQjtPQVAzQyxnQkFBZ0IsQ0FzSjVCO0lBQUQsdUJBQUM7Q0FBQSxBQXRKRCxDQUFzQyx3REFBeUIsR0FzSjlEO0FBdEpZLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgVmlld0NvbnRhaW5lclJlZiB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7XHJcbiAgdHJpZ2dlcixcclxuICBzdGF0ZSxcclxuICBzdHlsZSxcclxuICBhbmltYXRlLFxyXG4gIHRyYW5zaXRpb25cclxufSBmcm9tIFwiQGFuZ3VsYXIvYW5pbWF0aW9uc1wiO1xyXG5pbXBvcnQgeyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IH0gZnJvbSBcIi4uL2Fic3RyYWN0LW1lbnUtcGFnZS1jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgTWVudUNvbXBvbmVudCB9IGZyb20gXCIuLi9tZW51L21lbnUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IE1hcGJveFZpZXdBcGksIFZpZXdwb3J0IGFzIE1hcGJveFZpZXdwb3J0IH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1tYXBib3hcIjtcclxuaW1wb3J0IHsgQWRkcmVzc09wdGlvbnMsIERpcmVjdGlvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWRpcmVjdGlvbnNcIjtcclxuaW1wb3J0IHsgTW9kYWxEaWFsb2dTZXJ2aWNlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyXCI7XHJcbmltcG9ydCB7IFBsdWdpbkluZm8gfSBmcm9tIFwiLi4vc2hhcmVkL3BsdWdpbi1pbmZvXCI7XHJcbmltcG9ydCB7IFBsdWdpbkluZm9XcmFwcGVyIH0gZnJvbSBcIi4uL3NoYXJlZC9wbHVnaW4taW5mby13cmFwcGVyXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJwYWdlLW1hcHBpbmdcIixcclxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vbWFwcGluZy5jb21wb25lbnQuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1wibWFwcGluZy1jb21tb24uY3NzXCJdLFxyXG4gIGFuaW1hdGlvbnM6IFtcclxuICAgIHRyaWdnZXIoXCJmbHlJbk91dFwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe3RyYW5zZm9ybTogXCJzY2FsZSgxKVwiLCBvcGFjaXR5OiAxfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFtcclxuICAgICAgICBzdHlsZSh7dHJhbnNmb3JtOiBcInNjYWxlKDAuOSlcIiwgb3BhY2l0eTogMH0pLFxyXG4gICAgICAgIGFuaW1hdGUoXCIxMDAwbXMgMTAwbXMgZWFzZS1vdXRcIilcclxuICAgICAgXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcImZyb20tcmlnaHRcIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlKDApXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGUoMjAlKVwiXHJcbiAgICAgIH0pKSxcclxuICAgICAgdHJhbnNpdGlvbihcInZvaWQgPT4gKlwiLCBbYW5pbWF0ZShcIjYwMG1zIDE1MDBtcyBlYXNlLW91dFwiKV0pXHJcbiAgICBdKVxyXG4gIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIE1hcHBpbmdDb21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IHtcclxuXHJcbiAgcHJpdmF0ZSBkaXJlY3Rpb25zOiBEaXJlY3Rpb25zO1xyXG4gIHByaXZhdGUgbWFwOiBNYXBib3hWaWV3QXBpO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgbWVudUNvbXBvbmVudDogTWVudUNvbXBvbmVudCxcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgdmNSZWY6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgICAgICAgcHJvdGVjdGVkIG1vZGFsU2VydmljZTogTW9kYWxEaWFsb2dTZXJ2aWNlKSB7XHJcbiAgICBzdXBlcihtZW51Q29tcG9uZW50LCB2Y1JlZiwgbW9kYWxTZXJ2aWNlKTtcclxuICAgIHRoaXMuZGlyZWN0aW9ucyA9IG5ldyBEaXJlY3Rpb25zKCk7XHJcbiAgfVxyXG5cclxuICBvbk1hcFJlYWR5KGFyZ3MpOiB2b2lkIHtcclxuICAgIHRoaXMubWFwID0gYXJncy5tYXA7XHJcbiAgICB0aGlzLm1hcC5hZGRNYXJrZXJzKFtcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAgICAgIGxhdDogNDIuNjI0MTg5LFxyXG4gICAgICAgICAgICBsbmc6IDIzLjM3MjEwNixcclxuICAgICAgICAgICAgdGl0bGU6ICdEZXZSZWFjaCAyMDE3JyxcclxuICAgICAgICAgICAgc3VidGl0bGU6ICdTdWNoIGFuIGF3ZXNvbWUgbGl0dGxlIGNvbmZlcmVuY2UnLFxyXG4gICAgICAgICAgICBvblRhcDogKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiRGV2UmVhY2ggMjAxNyB3YXMgdGFwcGVkXCIpO1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBvbkNhbGxvdXRUYXA6ICgpID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkRldlJlYWNoIDIwMTcgY2FsbG91dCB0YXBwZWRcIik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgaWQ6IDIsXHJcbiAgICAgICAgICAgIGxhdDogNTEuOTI4MDU3MixcclxuICAgICAgICAgICAgbG5nOiA0LjQyMDE5NTIsXHJcbiAgICAgICAgICAgIHRpdGxlOiAne059IERldmVsb3BlciBkYXkgRVUnLFxyXG4gICAgICAgICAgICBzdWJ0aXRsZTogJ1RhcCB0byBzaG93IGRpcmVjdGlvbnMgKHdpdGggd2F5cG9pbnRzKScsXHJcbiAgICAgICAgICAgIGljb246ICdyZXM6Ly90bnNtYXJrZXInLFxyXG4gICAgICAgICAgICBvblRhcDogKCkgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwie059IERldmVsb3BlciBkYXkgRVUgd2FzIHRhcHBlZFwiKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgb25DYWxsb3V0VGFwOiAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgdGhpcy5zaG93RGlyZWN0aW9uc1RvKFtcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgbGF0OiA1Mi4xODUxNTg1LFxyXG4gICAgICAgICAgICAgICAgICBsbmc6IDUuMzk3NDI0MVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgbGF0OiA1MS45MjgwNTcyLFxyXG4gICAgICAgICAgICAgICAgICBsbmc6IDQuNDIwMTk1MlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIF0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogMyxcclxuICAgICAgICAgICAgbGF0OiA1Mi4xODUxNTg1LFxyXG4gICAgICAgICAgICBsbmc6IDUuMzk3NDI0MSxcclxuICAgICAgICAgICAgdGl0bGU6IFwiRWRkeSdzIGhvbWVcIixcclxuICAgICAgICAgICAgc3VidGl0bGU6IFwiVGFwIHRvIHNob3cgZGlyZWN0aW9uc1wiLFxyXG4gICAgICAgICAgICBpY29uUGF0aDogXCJpbWFnZXMvbWFwbWFya2Vycy9ob21lX21hcmtlci5wbmdcIixcclxuICAgICAgICAgICAgb25UYXA6ICgpID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIkVkZHkncyBob21lIHdhcyB0YXBwZWRcIik7XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG9uQ2FsbG91dFRhcDogKCkgPT4ge1xyXG4gICAgICAgICAgICAgIHRoaXMuc2hvd0RpcmVjdGlvbnNUbyhbe1xyXG4gICAgICAgICAgICAgICAgbGF0OiA1Mi4xODUxNTg1LFxyXG4gICAgICAgICAgICAgICAgbG5nOiA1LjM5NzQyNDFcclxuICAgICAgICAgICAgICB9XSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGlkOiA0LFxyXG4gICAgICAgICAgICBsYXQ6IDQzLjQyMTgzNCxcclxuICAgICAgICAgICAgbG5nOiAyNC4wODYwOTYsXHJcbiAgICAgICAgICAgIGljb246ICdyZXM6Ly90cnVjazEnLFxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaWQ6IDUsXHJcbiAgICAgICAgICAgIGxhdDogNDIuNDIxODM0LFxyXG4gICAgICAgICAgICBsbmc6IDI2Ljc4NjA5NixcclxuICAgICAgICAgICAgaWNvbjogJ3JlczovL3RydWNrMicsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBpZDogNixcclxuICAgICAgICAgICAgbGF0OiA0Mi4wMjE4MzQsXHJcbiAgICAgICAgICAgIGxuZzogMjUuMDg2MDk2LFxyXG4gICAgICAgICAgICBpY29uOiAncmVzOi8vdHJ1Y2szJyxcclxuICAgICAgICAgIH1cclxuICAgICAgICBdXHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgZmFiVGFwcGVkKCk6IHZvaWQge1xyXG4gICAgLy8gYWRkIGEgbWFya2VyIGF0IHRoZSBjZW50ZXIgb2YgdGhlIHZpZXdwb3J0XHJcbiAgICB0aGlzLm1hcC5nZXRWaWV3cG9ydCgpLnRoZW4oKHZpZXdwb3J0OiBNYXBib3hWaWV3cG9ydCkgPT4ge1xyXG4gICAgICBjb25zdCBsYXQgPSAodmlld3BvcnQuYm91bmRzLm5vcnRoICsgdmlld3BvcnQuYm91bmRzLnNvdXRoKSAvIDI7XHJcbiAgICAgIGNvbnN0IGxuZyA9ICh2aWV3cG9ydC5ib3VuZHMuZWFzdCArIHZpZXdwb3J0LmJvdW5kcy53ZXN0KSAvIDI7XHJcbiAgICAgIGNvbnN0IG1hcmtlcklkID0gbmV3IERhdGUoKS5nZXRUaW1lKCk7XHJcblxyXG4gICAgICB0aGlzLm1hcC5hZGRNYXJrZXJzKFt7XHJcbiAgICAgICAgaWQ6IG5ldyBEYXRlKCkuZ2V0VGltZSgpLFxyXG4gICAgICAgIGxhdDogbGF0LFxyXG4gICAgICAgIGxuZzogbG5nLFxyXG4gICAgICAgIHRpdGxlOiBcIkZBQiBtYXJrZXJcIixcclxuICAgICAgICBzdWJ0aXRsZTogXCJUYXAgdG8gcmVtb3ZlXCIsXHJcbiAgICAgICAgb25DYWxsb3V0VGFwOiAoKSA9PiB7XHJcbiAgICAgICAgICB0aGlzLm1hcC5yZW1vdmVNYXJrZXJzKFttYXJrZXJJZF0pO1xyXG4gICAgICAgIH1cclxuICAgICAgfV0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHNob3dEaXJlY3Rpb25zVG8oYWRkcmVzc2VzOiBBcnJheTxBZGRyZXNzT3B0aW9ucz4pOiB2b2lkIHtcclxuICAgIHRoaXMuZGlyZWN0aW9ucy5uYXZpZ2F0ZSh7XHJcbiAgICAgIHRvOiBhZGRyZXNzZXMsXHJcbiAgICAgIGlvczoge1xyXG4gICAgICAgIC8vIEFwcGxlIE1hcHMgY2FuJ3Qgc2hvdyB3YXlwb2ludHMsIHNvIG9wZW4gR29vZ2xlIG1hcHMgaWYgYXZhaWxhYmxlIGluIHRoYXQgY2FzZVxyXG4gICAgICAgIHByZWZlckdvb2dsZU1hcHM6IGFkZHJlc3Nlcy5sZW5ndGggPiAxXHJcbiAgICAgIH1cclxuICAgIH0pLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIk1hcHMgYXBwIGxhdW5jaGVkLlwiKTtcclxuICAgIH0sIGVycm9yID0+IHtcclxuICAgICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgZ2V0UGx1Z2luSW5mbygpOiBQbHVnaW5JbmZvV3JhcHBlciB7XHJcbiAgICByZXR1cm4gbmV3IFBsdWdpbkluZm9XcmFwcGVyKFxyXG4gICAgICAgIFwiVHJ5IGEgZmV3IG9uZS0gYW5kIHR3by1maW5nZXIgZ2VzdHVyZXMuIEFsb3MsIHByZXNzIHRoZSBGQUIgdG8gZHJvcCBhIG1hcmtlciBhdCB0aGUgY2VudGVyIG9mIHRoZSB2aWV3cG9ydC5cXG5cXG5UaGVuLCB3aGVuIHlvdSdyZSBib3JlZCBwbGF5aW5nIHdpdGggdGhlIG1hcCwgc2Nyb2xsIHRvIHRoZSBjZW50ZXIgb2YgVGhlIE5ldGhlcmxhbmRzIGFuZCB0YXAgdGhlIEhvbWUgaWNvbi4gVGhlbiBmb2xsb3cgaXRzIGluc3RydWN0aW9ucyB0byB0cmlnZ2VyIHRoZSBEaXJlY3Rpb25zIHBsdWdpbiFcIixcclxuICAgICAgICBBcnJheS5vZihcclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1tYXBib3hcIixcclxuICAgICAgICAgICAgICAgIFwiTWFwYm94ICDtoL3tt70g7aC97be8IO2gve23u1wiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vbmF0aXZlc2NyaXB0LW1hcGJveFwiLFxyXG4gICAgICAgICAgICAgICAgXCJOYXRpdmUgT3BlbkdMIHBvd2VyZWQgTWFwcy4gQ3JhenkgcGVyZm9ybWFuY2UgYW5kIGZlYXR1cmUtcmljaCEgVXNlIGN1c3RvbSBtYXJrZXJzIGFuZCBzaG93IHRoZSB1c2VyJ3MgbG9jYXRpb24uIEhlcmUgd2UgdXNlIHRoZSBtYXAgc3R5bGUgJ3RyYWZmaWNfZGF5JyB0byBzaG93IGxpdmUgdHJhZmZpYyFcIlxyXG4gICAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1kaXJlY3Rpb25zXCIsXHJcbiAgICAgICAgICAgICAgICBcIkRpcmVjdGlvbnMgIO2gve2xhiDtoL3tsYkg7aC97bGHIO2gve2xiFwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vbmF0aXZlc2NyaXB0LWRpcmVjdGlvbnNcIixcclxuICAgICAgICAgICAgICAgIFwiT3BlbiB0aGUgbmF0aXZlIE1hcHMgYXBwIHRvIHNob3cgZGlyZWN0aW9ucyB0byBhbnl3aGVyZSBvbiDtoLztvI8geW91IGxpa2UuIEV2ZW4gd2l0aCAobXVsdGlwbGUpIHdheXBvaW50cyBpbiBiZXR3ZWVuIVwiXHJcbiAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICBuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgICAgICAgIFwibmF0aXZlc2NyaXB0LWZsb2F0aW5nYWN0aW9uYnV0dG9uXCIsXHJcbiAgICAgICAgICAgICAgICBcIkZBQlwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vYnJhZG1hcnRpbi9uYXRpdmVzY3JpcHQtZmxvYXRpbmdhY3Rpb25idXR0b25cIixcclxuICAgICAgICAgICAgICAgIFwiQWRkIGEgTWF0ZXJpYWwgRGVzaWduIEZsb2F0aW5nIEFjdGlvbiBCdXR0b24gdG8geW91ciBwYWdlLCBhdCBhIGNvcm5lciBvZiB5b3VyIGxpa2luZy5cIlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgKVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl19