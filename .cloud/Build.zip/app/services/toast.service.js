Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ToastModule = require("nativescript-toast");
var color_1 = require("color");
var platform_1 = require("platform");
var font_1 = require("ui/styling/font");
var config_1 = require("../shared/config");
var ToastService = (function () {
    function ToastService() {
        this.previousToast = null;
        if (platform_1.isIOS) {
            ToastView.appearance().bottomOffsetPortrait = 40;
            ToastView.appearance().bottomOffsetLandscape = 40;
            ToastView.appearance().backgroundColor = new color_1.Color(240, 70, 70, 70).ios;
            ToastView.appearance().font = UIFont.fontWithNameSize("Source Sans Pro", config_1.Config.isTablet ? 20 : 16);
        }
        else {
            var f = new font_1.Font("SourceSansPro-Regular", (config_1.Config.isTablet ? 17 : 14), "normal", "normal");
            this.androidTypeface = f.getAndroidTypeface();
        }
    }
    ToastService.prototype.show = function (message, long) {
        if (this.previousToast) {
            this.previousToast.cancel();
            this.previousToast = null;
        }
        var t = ToastModule.makeText(message, long ? "long" : undefined);
        if (!platform_1.isIOS) {
            t.getView().getChildAt(0).setTypeface(this.androidTypeface);
        }
        t.show();
        this.previousToast = t;
    };
    ToastService = __decorate([
        core_1.Injectable(),
        __metadata("design:paramtypes", [])
    ], ToastService);
    return ToastService;
}());
exports.ToastService = ToastService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3Quc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInRvYXN0LnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUEyQztBQUMzQyxnREFBa0Q7QUFFbEQsK0JBQThCO0FBQzlCLHFDQUFpQztBQUNqQyx3Q0FBdUM7QUFDdkMsMkNBQTBDO0FBSzFDO0lBS0U7UUFIUSxrQkFBYSxHQUFVLElBQUksQ0FBQztRQUlsQyxFQUFFLENBQUMsQ0FBQyxnQkFBSyxDQUFDLENBQUMsQ0FBQztZQUVWLFNBQVMsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxvQkFBb0IsR0FBRyxFQUFFLENBQUM7WUFDakQsU0FBUyxDQUFDLFVBQVUsRUFBRSxDQUFDLHFCQUFxQixHQUFHLEVBQUUsQ0FBQztZQUNsRCxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsZUFBZSxHQUFHLElBQUksYUFBSyxDQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQUcsQ0FBQztZQUN4RSxTQUFTLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxHQUFHLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxpQkFBaUIsRUFBRSxlQUFNLENBQUMsUUFBUSxHQUFHLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztRQUN0RyxDQUFDO1FBQUMsSUFBSSxDQUFDLENBQUM7WUFDTixJQUFJLENBQUMsR0FBRyxJQUFJLFdBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFDLGVBQU0sQ0FBQyxRQUFRLEdBQUcsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQztZQUMzRixJQUFJLENBQUMsZUFBZSxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1FBQ2hELENBQUM7SUFDSCxDQUFDO0lBRUQsMkJBQUksR0FBSixVQUFLLE9BQWUsRUFBRSxJQUFjO1FBQ2xDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDNUIsSUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUM7UUFDNUIsQ0FBQztRQUVELElBQUksQ0FBQyxHQUFHLFdBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLElBQUksR0FBRyxNQUFNLEdBQUcsU0FBUyxDQUFDLENBQUM7UUFFakUsRUFBRSxDQUFDLENBQUMsQ0FBQyxnQkFBSyxDQUFDLENBQUMsQ0FBQztZQUNMLENBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztRQUNyRSxDQUFDO1FBRUQsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ1QsSUFBSSxDQUFDLGFBQWEsR0FBRyxDQUFDLENBQUM7SUFDekIsQ0FBQztJQWhDVSxZQUFZO1FBRHhCLGlCQUFVLEVBQUU7O09BQ0EsWUFBWSxDQWlDeEI7SUFBRCxtQkFBQztDQUFBLEFBakNELElBaUNDO0FBakNZLG9DQUFZIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCAqIGFzIFRvYXN0TW9kdWxlIGZyb20gXCJuYXRpdmVzY3JpcHQtdG9hc3RcIjtcclxuaW1wb3J0IHsgVG9hc3QgfSBmcm9tIFwibmF0aXZlc2NyaXB0LXRvYXN0XCI7XHJcbmltcG9ydCB7IENvbG9yIH0gZnJvbSBcImNvbG9yXCI7XHJcbmltcG9ydCB7IGlzSU9TIH0gZnJvbSBcInBsYXRmb3JtXCI7XHJcbmltcG9ydCB7IEZvbnQgfSBmcm9tIFwidWkvc3R5bGluZy9mb250XCI7XHJcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gXCIuLi9zaGFyZWQvY29uZmlnXCI7XHJcblxyXG5kZWNsYXJlIGNvbnN0IFRvYXN0VmlldywgVUlGb250O1xyXG5cclxuQEluamVjdGFibGUoKVxyXG5leHBvcnQgY2xhc3MgVG9hc3RTZXJ2aWNlIHtcclxuXHJcbiAgcHJpdmF0ZSBwcmV2aW91c1RvYXN0OiBUb2FzdCA9IG51bGw7XHJcbiAgcHJpdmF0ZSBhbmRyb2lkVHlwZWZhY2U6IGFueTtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICBpZiAoaXNJT1MpIHtcclxuICAgICAgLy8gZm9yIHByb3BlcnRpZXMgc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9kZXZ4b3VsL1RvYXN0ZXJcclxuICAgICAgVG9hc3RWaWV3LmFwcGVhcmFuY2UoKS5ib3R0b21PZmZzZXRQb3J0cmFpdCA9IDQwO1xyXG4gICAgICBUb2FzdFZpZXcuYXBwZWFyYW5jZSgpLmJvdHRvbU9mZnNldExhbmRzY2FwZSA9IDQwO1xyXG4gICAgICBUb2FzdFZpZXcuYXBwZWFyYW5jZSgpLmJhY2tncm91bmRDb2xvciA9IG5ldyBDb2xvcigyNDAsIDcwLCA3MCwgNzApLmlvcztcclxuICAgICAgVG9hc3RWaWV3LmFwcGVhcmFuY2UoKS5mb250ID0gVUlGb250LmZvbnRXaXRoTmFtZVNpemUoXCJTb3VyY2UgU2FucyBQcm9cIiwgQ29uZmlnLmlzVGFibGV0ID8gMjAgOiAxNik7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBsZXQgZiA9IG5ldyBGb250KFwiU291cmNlU2Fuc1Byby1SZWd1bGFyXCIsIChDb25maWcuaXNUYWJsZXQgPyAxNyA6IDE0KSwgXCJub3JtYWxcIiwgXCJub3JtYWxcIik7XHJcbiAgICAgIHRoaXMuYW5kcm9pZFR5cGVmYWNlID0gZi5nZXRBbmRyb2lkVHlwZWZhY2UoKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHNob3cobWVzc2FnZTogc3RyaW5nLCBsb25nPzogYm9vbGVhbikge1xyXG4gICAgaWYgKHRoaXMucHJldmlvdXNUb2FzdCkge1xyXG4gICAgICB0aGlzLnByZXZpb3VzVG9hc3QuY2FuY2VsKCk7XHJcbiAgICAgIHRoaXMucHJldmlvdXNUb2FzdCA9IG51bGw7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHQgPSBUb2FzdE1vZHVsZS5tYWtlVGV4dChtZXNzYWdlLCBsb25nID8gXCJsb25nXCIgOiB1bmRlZmluZWQpO1xyXG5cclxuICAgIGlmICghaXNJT1MpIHtcclxuICAgICAgKDxhbnk+dCkuZ2V0VmlldygpLmdldENoaWxkQXQoMCkuc2V0VHlwZWZhY2UodGhpcy5hbmRyb2lkVHlwZWZhY2UpO1xyXG4gICAgfVxyXG5cclxuICAgIHQuc2hvdygpO1xyXG4gICAgdGhpcy5wcmV2aW91c1RvYXN0ID0gdDtcclxuICB9XHJcbn0iXX0=