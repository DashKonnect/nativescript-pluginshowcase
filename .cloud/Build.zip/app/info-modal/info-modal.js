Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var modal_dialog_1 = require("nativescript-angular/modal-dialog");
var page_1 = require("ui/page");
var color_1 = require("tns-core-modules/color");
var utils = require("utils/utils");
var utils_1 = require("tns-core-modules/utils/utils");
var config_1 = require("../shared/config");
var tablet_util_1 = require("../utils/tablet-util");
var pageCommon = require("tns-core-modules/ui/page/page-common").PageBase;
var InfoModalComponent = (function () {
    function InfoModalComponent(params, page) {
        var _this = this;
        this.params = params;
        this.page = page;
        this.isTablet = config_1.Config.isTablet;
        this.pluginInfo = params.context;
        this.page.on("unloaded", function () {
            _this.params.closeCallback();
        });
        this.page.backgroundColor = new color_1.Color(50, 0, 0, 0);
        if (page.ios) {
            page._showNativeModalView = function (parent, context, closeCallback, fullscreen) {
                pageCommon.prototype._showNativeModalView.call(this, parent, context, closeCallback, fullscreen);
                var that = this;
                this._modalParent = parent;
                if (fullscreen) {
                    this._ios.modalPresentationStyle = 0;
                }
                else {
                    this._ios.modalPresentationStyle = 2;
                    this._UIModalPresentationFormSheet = true;
                }
                pageCommon.prototype._raiseShowingModallyEvent.call(this);
                this._ios.providesPresentationContextTransitionStyle = true;
                this._ios.definesPresentationContext = true;
                this._ios.modalPresentationStyle = 5;
                this._ios.modalTransitionStyle = 2;
                this._ios.view.backgroundColor = UIColor.clearColor;
                parent.ios.presentViewControllerAnimatedCompletion(this._ios, utils.ios.MajorVersion >= 9, function () {
                    that._ios.modalPresentationStyle = 3;
                    that._raiseShownModallyEvent(parent, context, closeCallback);
                });
            };
        }
        tablet_util_1.addTabletCss(this.page, "info-modal");
    }
    InfoModalComponent.prototype.openPluginUrl = function (pluginInfo) {
        utils_1.openUrl(pluginInfo.url);
    };
    InfoModalComponent.prototype.close = function () {
        this.params.closeCallback();
    };
    InfoModalComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: "./info-modal.html",
            styleUrls: [
                "./info-modal-common.css",
                "./info-modal.css"
            ]
        }),
        __metadata("design:paramtypes", [modal_dialog_1.ModalDialogParams,
            page_1.Page])
    ], InfoModalComponent);
    return InfoModalComponent;
}());
exports.InfoModalComponent = InfoModalComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5mby1tb2RhbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImluZm8tbW9kYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUEwQztBQUMxQyxrRUFBc0U7QUFDdEUsZ0NBQStCO0FBQy9CLGdEQUErQztBQUMvQyxtQ0FBcUM7QUFFckMsc0RBQXVEO0FBRXZELDJDQUEwQztBQUMxQyxvREFBb0Q7QUFFcEQsSUFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLHNDQUFzQyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBVTVFO0lBSUUsNEJBQW9CLE1BQXlCLEVBQ3pCLElBQVU7UUFEOUIsaUJBNkNDO1FBN0NtQixXQUFNLEdBQU4sTUFBTSxDQUFtQjtRQUN6QixTQUFJLEdBQUosSUFBSSxDQUFNO1FBSDlCLGFBQVEsR0FBWSxlQUFNLENBQUMsUUFBUSxDQUFDO1FBSWxDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUVqQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxVQUFVLEVBQUU7WUFDdkIsS0FBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUM5QixDQUFDLENBQUMsQ0FBQztRQUNILElBQUksQ0FBQyxJQUFJLENBQUMsZUFBZSxHQUFHLElBQUksYUFBSyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBRW5ELEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBTVAsSUFBSyxDQUFDLG9CQUFvQixHQUFHLFVBQVUsTUFBTSxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsVUFBVTtnQkFDckYsVUFBVSxDQUFDLFNBQVMsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsYUFBYSxFQUFFLFVBQVUsQ0FBQyxDQUFDO2dCQUNqRyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBR2hCLElBQUksQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDO2dCQUUzQixFQUFFLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDO29CQUNmLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsQ0FBQyxDQUFDO2dCQUN2QyxDQUFDO2dCQUFDLElBQUksQ0FBQyxDQUFDO29CQUNOLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLEdBQUcsQ0FBQyxDQUFDO29CQUNyQyxJQUFJLENBQUMsNkJBQTZCLEdBQUcsSUFBSSxDQUFDO2dCQUM1QyxDQUFDO2dCQUVELFVBQVUsQ0FBQyxTQUFTLENBQUMseUJBQXlCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO2dCQUUxRCxJQUFJLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxHQUFHLElBQUksQ0FBQztnQkFDNUQsSUFBSSxDQUFDLElBQUksQ0FBQywwQkFBMEIsR0FBRyxJQUFJLENBQUM7Z0JBQzVDLElBQUksQ0FBQyxJQUFJLENBQUMsc0JBQXNCLElBQTBDLENBQUM7Z0JBQzNFLElBQUksQ0FBQyxJQUFJLENBQUMsb0JBQW9CLElBQXVDLENBQUM7Z0JBQ3RFLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLGVBQWUsR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDO2dCQUVwRCxNQUFNLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxZQUFZLElBQUksQ0FBQyxFQUFFO29CQUN6RixJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQixJQUEwQyxDQUFDO29CQUMzRSxJQUFJLENBQUMsdUJBQXVCLENBQUMsTUFBTSxFQUFFLE9BQU8sRUFBRSxhQUFhLENBQUMsQ0FBQztnQkFDL0QsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDLENBQUM7UUFDSixDQUFDO1FBRUQsMEJBQVksQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLFlBQVksQ0FBQyxDQUFDO0lBQ3hDLENBQUM7SUFFRCwwQ0FBYSxHQUFiLFVBQWMsVUFBc0I7UUFFbEMsZUFBTyxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUMxQixDQUFDO0lBRUQsa0NBQUssR0FBTDtRQUNFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxFQUFFLENBQUM7SUFDOUIsQ0FBQztJQTFEVSxrQkFBa0I7UUFSOUIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsbUJBQW1CO1lBQ2hDLFNBQVMsRUFBRTtnQkFDVCx5QkFBeUI7Z0JBQ3pCLGtCQUFrQjthQUNuQjtTQUNGLENBQUM7eUNBSzRCLGdDQUFpQjtZQUNuQixXQUFJO09BTG5CLGtCQUFrQixDQTJEOUI7SUFBRCx5QkFBQztDQUFBLEFBM0RELElBMkRDO0FBM0RZLGdEQUFrQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IE1vZGFsRGlhbG9nUGFyYW1zIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL21vZGFsLWRpYWxvZ1wiO1xyXG5pbXBvcnQgeyBQYWdlIH0gZnJvbSBcInVpL3BhZ2VcIjtcclxuaW1wb3J0IHsgQ29sb3IgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9jb2xvclwiO1xyXG5pbXBvcnQgKiBhcyB1dGlscyBmcm9tICd1dGlscy91dGlscyc7XHJcbmltcG9ydCB7IFBsdWdpbkluZm8gfSBmcm9tIFwiLi4vc2hhcmVkL3BsdWdpbi1pbmZvXCI7XHJcbmltcG9ydCB7IG9wZW5VcmwgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91dGlscy91dGlsc1wiO1xyXG5pbXBvcnQgeyBQbHVnaW5JbmZvV3JhcHBlciB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm8td3JhcHBlclwiO1xyXG5pbXBvcnQgeyBDb25maWcgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbmZpZ1wiO1xyXG5pbXBvcnQgeyBhZGRUYWJsZXRDc3MgfSBmcm9tIFwiLi4vdXRpbHMvdGFibGV0LXV0aWxcIjtcclxuXHJcbmNvbnN0IHBhZ2VDb21tb24gPSByZXF1aXJlKFwidG5zLWNvcmUtbW9kdWxlcy91aS9wYWdlL3BhZ2UtY29tbW9uXCIpLlBhZ2VCYXNlO1xyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICB0ZW1wbGF0ZVVybDogXCIuL2luZm8tbW9kYWwuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1xyXG4gICAgXCIuL2luZm8tbW9kYWwtY29tbW9uLmNzc1wiLFxyXG4gICAgXCIuL2luZm8tbW9kYWwuY3NzXCJcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJbmZvTW9kYWxDb21wb25lbnQge1xyXG4gIHBsdWdpbkluZm86IFBsdWdpbkluZm9XcmFwcGVyO1xyXG4gIGlzVGFibGV0OiBib29sZWFuID0gQ29uZmlnLmlzVGFibGV0O1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIHBhcmFtczogTW9kYWxEaWFsb2dQYXJhbXMsXHJcbiAgICAgICAgICAgICAgcHJpdmF0ZSBwYWdlOiBQYWdlKSB7XHJcbiAgICB0aGlzLnBsdWdpbkluZm8gPSBwYXJhbXMuY29udGV4dDtcclxuXHJcbiAgICB0aGlzLnBhZ2Uub24oXCJ1bmxvYWRlZFwiLCAoKSA9PiB7XHJcbiAgICAgIHRoaXMucGFyYW1zLmNsb3NlQ2FsbGJhY2soKTtcclxuICAgIH0pO1xyXG4gICAgdGhpcy5wYWdlLmJhY2tncm91bmRDb2xvciA9IG5ldyBDb2xvcig1MCwgMCwgMCwgMCk7XHJcblxyXG4gICAgaWYgKHBhZ2UuaW9zKSB7XHJcblxyXG4gICAgICAvLyBpT1MgYnkgZGVmYXVsdCB3b24ndCBsZXQgdXMgaGF2ZSBhIHRyYW5zcGFyZW50IGJhY2tncm91bmQgb24gYSBtb2RhbFxyXG4gICAgICAvLyBVZ2x5IHdvcmthcm91bmQgZnJvbTogaHR0cHM6Ly9naXRodWIuY29tL05hdGl2ZVNjcmlwdC9uYXRpdmVzY3JpcHQvaXNzdWVzLzIwODYjaXNzdWVjb21tZW50LTIyMTk1NjQ4M1xyXG4gICAgICAvLyB0aGlzLnBhZ2UuYmFja2dyb3VuZENvbG9yID0gbmV3IENvbG9yKDUwLCAwLCAwLCAwKTtcclxuXHJcbiAgICAgICg8YW55PnBhZ2UpLl9zaG93TmF0aXZlTW9kYWxWaWV3ID0gZnVuY3Rpb24gKHBhcmVudCwgY29udGV4dCwgY2xvc2VDYWxsYmFjaywgZnVsbHNjcmVlbikge1xyXG4gICAgICAgIHBhZ2VDb21tb24ucHJvdG90eXBlLl9zaG93TmF0aXZlTW9kYWxWaWV3LmNhbGwodGhpcywgcGFyZW50LCBjb250ZXh0LCBjbG9zZUNhbGxiYWNrLCBmdWxsc2NyZWVuKTtcclxuICAgICAgICBsZXQgdGhhdCA9IHRoaXM7XHJcblxyXG4gICAgICAgIC8vIG5vaW5zcGVjdGlvbiBKU1VudXNlZEdsb2JhbFN5bWJvbHNcclxuICAgICAgICB0aGlzLl9tb2RhbFBhcmVudCA9IHBhcmVudDtcclxuXHJcbiAgICAgICAgaWYgKGZ1bGxzY3JlZW4pIHtcclxuICAgICAgICAgIHRoaXMuX2lvcy5tb2RhbFByZXNlbnRhdGlvblN0eWxlID0gMDtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgdGhpcy5faW9zLm1vZGFsUHJlc2VudGF0aW9uU3R5bGUgPSAyO1xyXG4gICAgICAgICAgdGhpcy5fVUlNb2RhbFByZXNlbnRhdGlvbkZvcm1TaGVldCA9IHRydWU7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBwYWdlQ29tbW9uLnByb3RvdHlwZS5fcmFpc2VTaG93aW5nTW9kYWxseUV2ZW50LmNhbGwodGhpcyk7XHJcblxyXG4gICAgICAgIHRoaXMuX2lvcy5wcm92aWRlc1ByZXNlbnRhdGlvbkNvbnRleHRUcmFuc2l0aW9uU3R5bGUgPSB0cnVlO1xyXG4gICAgICAgIHRoaXMuX2lvcy5kZWZpbmVzUHJlc2VudGF0aW9uQ29udGV4dCA9IHRydWU7XHJcbiAgICAgICAgdGhpcy5faW9zLm1vZGFsUHJlc2VudGF0aW9uU3R5bGUgPSBVSU1vZGFsUHJlc2VudGF0aW9uU3R5bGUuT3ZlckZ1bGxTY3JlZW47XHJcbiAgICAgICAgdGhpcy5faW9zLm1vZGFsVHJhbnNpdGlvblN0eWxlID0gVUlNb2RhbFRyYW5zaXRpb25TdHlsZS5Dcm9zc0Rpc3NvbHZlO1xyXG4gICAgICAgIHRoaXMuX2lvcy52aWV3LmJhY2tncm91bmRDb2xvciA9IFVJQ29sb3IuY2xlYXJDb2xvcjtcclxuXHJcbiAgICAgICAgcGFyZW50Lmlvcy5wcmVzZW50Vmlld0NvbnRyb2xsZXJBbmltYXRlZENvbXBsZXRpb24odGhpcy5faW9zLCB1dGlscy5pb3MuTWFqb3JWZXJzaW9uID49IDksIGZ1bmN0aW9uICgpIHtcclxuICAgICAgICAgIHRoYXQuX2lvcy5tb2RhbFByZXNlbnRhdGlvblN0eWxlID0gVUlNb2RhbFByZXNlbnRhdGlvblN0eWxlLkN1cnJlbnRDb250ZXh0O1xyXG4gICAgICAgICAgdGhhdC5fcmFpc2VTaG93bk1vZGFsbHlFdmVudChwYXJlbnQsIGNvbnRleHQsIGNsb3NlQ2FsbGJhY2spO1xyXG4gICAgICAgIH0pO1xyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGFkZFRhYmxldENzcyh0aGlzLnBhZ2UsIFwiaW5mby1tb2RhbFwiKTtcclxuICB9XHJcblxyXG4gIG9wZW5QbHVnaW5VcmwocGx1Z2luSW5mbzogUGx1Z2luSW5mbyk6IHZvaWQge1xyXG4gICAgLy8gb3BlbiBpbiB0aGUgZGVmYXVsdCBicm93c2VyXHJcbiAgICBvcGVuVXJsKHBsdWdpbkluZm8udXJsKTtcclxuICB9XHJcblxyXG4gIGNsb3NlKCkge1xyXG4gICAgdGhpcy5wYXJhbXMuY2xvc2VDYWxsYmFjaygpO1xyXG4gIH1cclxufSJdfQ==