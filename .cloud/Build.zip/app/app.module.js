Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var nativescript_module_1 = require("nativescript-angular/nativescript.module");
var router_1 = require("nativescript-angular/router");
var app_routing_module_1 = require("./app-routing.module");
var app_component_1 = require("./app.component");
var status_bar_util_1 = require("./utils/status-bar-util");
var config_1 = require("./shared/config");
var nativescript_angular_1 = require("nativescript-angular");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var animations_1 = require("nativescript-angular/animations");
var nativescript_app_shortcuts_1 = require("nativescript-app-shortcuts");
var platform_1 = require("tns-core-modules/platform");
var enums_1 = require("tns-core-modules/ui/enums");
var application = require("application");
var toast_service_1 = require("./services/toast.service");
var fs = require("file-system");
nativescript_angular_1.registerElement("Gradient", function () { return require("nativescript-gradient").Gradient; });
status_bar_util_1.setStatusBarColors();
config_1.Config.isTablet = platform_1.device.deviceType === enums_1.DeviceType.Tablet;
var AppModule = (function () {
    function AppModule(routerExtensions, zone) {
        var _this = this;
        this.routerExtensions = routerExtensions;
        this.zone = zone;
        if (config_1.Config.isTablet) {
            var cssFileName = fs.path.join(fs.knownFolders.currentApp().path, "app.tablet.css");
            fs.File.fromPath(cssFileName).readText().then(function (result) {
                application.addCss(result);
            });
        }
        new nativescript_app_shortcuts_1.AppShortcuts().setQuickActionCallback(function (shortcutItem) {
            console.log("The app was launched by shortcut type '" + shortcutItem.type + "'");
            if (shortcutItem.type === "feedback") {
                _this.deeplink("/menu/feedback");
            }
            else if (shortcutItem.type === "appicon") {
                _this.deeplink("/menu/appicon");
            }
            else if (shortcutItem.type === "mapping") {
                _this.deeplink("/menu/mapping");
            }
        });
    }
    AppModule.prototype.deeplink = function (to) {
        var _this = this;
        setTimeout(function () {
            _this.zone.run(function () {
                _this.routerExtensions.navigate([to], {
                    animated: true,
                    clearHistory: true
                });
            });
        }, platform_1.isIOS ? 0 : 1000);
    };
    AppModule = __decorate([
        core_1.NgModule({
            bootstrap: [
                app_component_1.AppComponent
            ],
            imports: [
                nativescript_module_1.NativeScriptModule,
                nativescript_angular_1.NativeScriptFormsModule,
                animations_1.NativeScriptAnimationsModule,
                app_routing_module_1.AppRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule.forRoot({
                    'mdi': 'fonts/materialdesignicons.css'
                }),
            ],
            declarations: [
                app_component_1.AppComponent
            ],
            providers: [
                toast_service_1.ToastService,
                {
                    provide: core_1.NgModuleFactoryLoader, useClass: router_1.NSModuleFactoryLoader
                }
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        }),
        __metadata("design:paramtypes", [nativescript_angular_1.RouterExtensions,
            core_1.NgZone])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFwcC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUEwRjtBQUMxRixnRkFBOEU7QUFDOUUsc0RBQW9FO0FBRXBFLDJEQUF3RDtBQUN4RCxpREFBK0M7QUFDL0MsMkRBQTZEO0FBQzdELDBDQUF5QztBQUN6Qyw2REFBa0c7QUFDbEcsdUVBQThEO0FBQzlELDhEQUErRTtBQUMvRSx5RUFBMEQ7QUFDMUQsc0RBQTBEO0FBQzFELG1EQUF1RDtBQUN2RCx5Q0FBMkM7QUFDM0MsMERBQXdEO0FBRXhELElBQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxhQUFhLENBQUMsQ0FBQztBQUVsQyxzQ0FBZSxDQUFDLFVBQVUsRUFBRSxjQUFNLE9BQUEsT0FBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsUUFBUSxFQUF6QyxDQUF5QyxDQUFDLENBQUM7QUFFN0Usb0NBQWtCLEVBQUUsQ0FBQztBQUVyQixlQUFNLENBQUMsUUFBUSxHQUFHLGlCQUFNLENBQUMsVUFBVSxLQUFLLGtCQUFVLENBQUMsTUFBTSxDQUFDO0FBNEIxRDtJQUNFLG1CQUFvQixnQkFBa0MsRUFDbEMsSUFBWTtRQURoQyxpQkF1QkM7UUF2Qm1CLHFCQUFnQixHQUFoQixnQkFBZ0IsQ0FBa0I7UUFDbEMsU0FBSSxHQUFKLElBQUksQ0FBUTtRQUU5QixFQUFFLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNwQixJQUFJLFdBQVcsR0FBRyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsWUFBWSxDQUFDLFVBQVUsRUFBRSxDQUFDLElBQUksRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3BGLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLE1BQWM7Z0JBQzNELFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDN0IsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBR0QsSUFBSSx5Q0FBWSxFQUFFLENBQUMsc0JBQXNCLENBQUMsVUFBQSxZQUFZO1lBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTBDLFlBQVksQ0FBQyxJQUFJLE1BQUcsQ0FBQyxDQUFDO1lBRzVFLEVBQUUsQ0FBQyxDQUFDLFlBQVksQ0FBQyxJQUFJLEtBQUssVUFBVSxDQUFDLENBQUMsQ0FBQztnQkFDckMsS0FBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ2xDLENBQUM7WUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxLQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2pDLENBQUM7WUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUMzQyxLQUFJLENBQUMsUUFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDO1lBQ2pDLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTyw0QkFBUSxHQUFoQixVQUFpQixFQUFVO1FBQTNCLGlCQVVDO1FBUkMsVUFBVSxDQUFDO1lBQ1QsS0FBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Z0JBQ1osS0FBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFO29CQUNuQyxRQUFRLEVBQUUsSUFBSTtvQkFDZCxZQUFZLEVBQUUsSUFBSTtpQkFDbkIsQ0FBQyxDQUFDO1lBQ0wsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsZ0JBQUssR0FBRyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7SUFDdkIsQ0FBQztJQXBDVSxTQUFTO1FBMUJyQixlQUFRLENBQUM7WUFDUixTQUFTLEVBQUU7Z0JBQ1QsNEJBQVk7YUFDYjtZQUNELE9BQU8sRUFBRTtnQkFDUCx3Q0FBa0I7Z0JBQ2xCLDhDQUF1QjtnQkFDdkIseUNBQTRCO2dCQUM1QixxQ0FBZ0I7Z0JBQ2hCLDZDQUFpQixDQUFDLE9BQU8sQ0FBQztvQkFDeEIsS0FBSyxFQUFFLCtCQUErQjtpQkFDdkMsQ0FBQzthQUNIO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLDRCQUFZO2FBQ2I7WUFDRCxTQUFTLEVBQUU7Z0JBQ1QsNEJBQVk7Z0JBQ1o7b0JBQ0UsT0FBTyxFQUFFLDRCQUFxQixFQUFFLFFBQVEsRUFBRSw4QkFBcUI7aUJBQ2hFO2FBQ0Y7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsdUJBQWdCO2FBQ2pCO1NBQ0YsQ0FBQzt5Q0FFc0MsdUNBQWdCO1lBQzVCLGFBQU07T0FGckIsU0FBUyxDQXFDckI7SUFBRCxnQkFBQztDQUFBLEFBckNELElBcUNDO0FBckNZLDhCQUFTIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUsIE5nTW9kdWxlRmFjdG9yeUxvYWRlciwgTmdab25lLCBOT19FUlJPUlNfU0NIRU1BIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0TW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL25hdGl2ZXNjcmlwdC5tb2R1bGVcIjtcclxuaW1wb3J0IHsgTlNNb2R1bGVGYWN0b3J5TG9hZGVyIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL3JvdXRlclwiO1xyXG5cclxuaW1wb3J0IHsgQXBwUm91dGluZ01vZHVsZSB9IGZyb20gXCIuL2FwcC1yb3V0aW5nLm1vZHVsZVwiO1xyXG5pbXBvcnQgeyBBcHBDb21wb25lbnQgfSBmcm9tIFwiLi9hcHAuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IHNldFN0YXR1c0JhckNvbG9ycyB9IGZyb20gXCIuL3V0aWxzL3N0YXR1cy1iYXItdXRpbFwiO1xyXG5pbXBvcnQgeyBDb25maWcgfSBmcm9tIFwiLi9zaGFyZWQvY29uZmlnXCI7XHJcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLCByZWdpc3RlckVsZW1lbnQsIFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgVE5TRm9udEljb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LW5neC1mb250aWNvblwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRBbmltYXRpb25zTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2FuaW1hdGlvbnNcIjtcclxuaW1wb3J0IHsgQXBwU2hvcnRjdXRzIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hcHAtc2hvcnRjdXRzXCI7XHJcbmltcG9ydCB7IGRldmljZSwgaXNJT1MgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9wbGF0Zm9ybVwiO1xyXG5pbXBvcnQgeyBEZXZpY2VUeXBlIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZW51bXNcIjtcclxuaW1wb3J0ICogYXMgYXBwbGljYXRpb24gZnJvbSBcImFwcGxpY2F0aW9uXCI7XHJcbmltcG9ydCB7IFRvYXN0U2VydmljZSB9IGZyb20gXCIuL3NlcnZpY2VzL3RvYXN0LnNlcnZpY2VcIjtcclxuXHJcbmNvbnN0IGZzID0gcmVxdWlyZShcImZpbGUtc3lzdGVtXCIpO1xyXG5cclxucmVnaXN0ZXJFbGVtZW50KFwiR3JhZGllbnRcIiwgKCkgPT4gcmVxdWlyZShcIm5hdGl2ZXNjcmlwdC1ncmFkaWVudFwiKS5HcmFkaWVudCk7XHJcblxyXG5zZXRTdGF0dXNCYXJDb2xvcnMoKTtcclxuXHJcbkNvbmZpZy5pc1RhYmxldCA9IGRldmljZS5kZXZpY2VUeXBlID09PSBEZXZpY2VUeXBlLlRhYmxldDtcclxuXHJcbkBOZ01vZHVsZSh7XHJcbiAgYm9vdHN0cmFwOiBbXHJcbiAgICBBcHBDb21wb25lbnRcclxuICBdLFxyXG4gIGltcG9ydHM6IFtcclxuICAgIE5hdGl2ZVNjcmlwdE1vZHVsZSxcclxuICAgIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLFxyXG4gICAgTmF0aXZlU2NyaXB0QW5pbWF0aW9uc01vZHVsZSxcclxuICAgIEFwcFJvdXRpbmdNb2R1bGUsXHJcbiAgICBUTlNGb250SWNvbk1vZHVsZS5mb3JSb290KHtcclxuICAgICAgJ21kaSc6ICdmb250cy9tYXRlcmlhbGRlc2lnbmljb25zLmNzcydcclxuICAgIH0pLFxyXG4gIF0sXHJcbiAgZGVjbGFyYXRpb25zOiBbXHJcbiAgICBBcHBDb21wb25lbnRcclxuICBdLFxyXG4gIHByb3ZpZGVyczogW1xyXG4gICAgVG9hc3RTZXJ2aWNlLFxyXG4gICAge1xyXG4gICAgICBwcm92aWRlOiBOZ01vZHVsZUZhY3RvcnlMb2FkZXIsIHVzZUNsYXNzOiBOU01vZHVsZUZhY3RvcnlMb2FkZXJcclxuICAgIH1cclxuICBdLFxyXG4gIHNjaGVtYXM6IFtcclxuICAgIE5PX0VSUk9SU19TQ0hFTUFcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHBNb2R1bGUge1xyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgcm91dGVyRXh0ZW5zaW9uczogUm91dGVyRXh0ZW5zaW9ucyxcclxuICAgICAgICAgICAgICBwcml2YXRlIHpvbmU6IE5nWm9uZSkge1xyXG5cclxuICAgIGlmIChDb25maWcuaXNUYWJsZXQpIHtcclxuICAgICAgbGV0IGNzc0ZpbGVOYW1lID0gZnMucGF0aC5qb2luKGZzLmtub3duRm9sZGVycy5jdXJyZW50QXBwKCkucGF0aCwgXCJhcHAudGFibGV0LmNzc1wiKTtcclxuICAgICAgZnMuRmlsZS5mcm9tUGF0aChjc3NGaWxlTmFtZSkucmVhZFRleHQoKS50aGVuKChyZXN1bHQ6IHN0cmluZykgPT4ge1xyXG4gICAgICAgIGFwcGxpY2F0aW9uLmFkZENzcyhyZXN1bHQpO1xyXG4gICAgICB9KTtcclxuICAgIH1cclxuXHJcbiAgICAvLyBUaGlzIGlzIGZvciBuYXRpdmVzY3JpcHQtYXBwLXNob3J0Y3V0c1xyXG4gICAgbmV3IEFwcFNob3J0Y3V0cygpLnNldFF1aWNrQWN0aW9uQ2FsbGJhY2soc2hvcnRjdXRJdGVtID0+IHtcclxuICAgICAgY29uc29sZS5sb2coYFRoZSBhcHAgd2FzIGxhdW5jaGVkIGJ5IHNob3J0Y3V0IHR5cGUgJyR7c2hvcnRjdXRJdGVtLnR5cGV9J2ApO1xyXG5cclxuICAgICAgLy8gdGhpcyBpcyB3aGVyZSB5b3UgaGFuZGxlIGFueSBzcGVjaWZpYyBjYXNlIGZvciB0aGUgc2hvcnRjdXQsIGJhc2VkIG9uIGl0cyB0eXBlXHJcbiAgICAgIGlmIChzaG9ydGN1dEl0ZW0udHlwZSA9PT0gXCJmZWVkYmFja1wiKSB7XHJcbiAgICAgICAgdGhpcy5kZWVwbGluayhcIi9tZW51L2ZlZWRiYWNrXCIpO1xyXG4gICAgICB9IGVsc2UgaWYgKHNob3J0Y3V0SXRlbS50eXBlID09PSBcImFwcGljb25cIikge1xyXG4gICAgICAgIHRoaXMuZGVlcGxpbmsoXCIvbWVudS9hcHBpY29uXCIpO1xyXG4gICAgICB9IGVsc2UgaWYgKHNob3J0Y3V0SXRlbS50eXBlID09PSBcIm1hcHBpbmdcIikge1xyXG4gICAgICAgIHRoaXMuZGVlcGxpbmsoXCIvbWVudS9tYXBwaW5nXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZGVlcGxpbmsodG86IHN0cmluZyk6IHZvaWQge1xyXG4gICAgLy8gYSB0aW1lb3V0IGlzIHJlcXVpcmVkIGZvciBBbmRyb2lkIChub3Qgc3VyZSBob3cgbG9uZyB0aGUgZGVsYXkgc2hvdWxkIGJlIHlldClcclxuICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICB0aGlzLnpvbmUucnVuKCgpID0+IHtcclxuICAgICAgICB0aGlzLnJvdXRlckV4dGVuc2lvbnMubmF2aWdhdGUoW3RvXSwge1xyXG4gICAgICAgICAgYW5pbWF0ZWQ6IHRydWUsXHJcbiAgICAgICAgICBjbGVhckhpc3Rvcnk6IHRydWVcclxuICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcbiAgICB9LCBpc0lPUyA/IDAgOiAxMDAwKTtcclxuICB9XHJcbn1cclxuIl19