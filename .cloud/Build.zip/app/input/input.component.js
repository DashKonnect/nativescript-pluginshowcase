Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var segmented_bar_1 = require("tns-core-modules/ui/segmented-bar");
var iqkeyboard_helper_1 = require("./helpers/iqkeyboard-helper");
var checkbox_helper_1 = require("./helpers/checkbox-helper");
var InputComponent = (function (_super) {
    __extends(InputComponent, _super);
    function InputComponent(menuComponent, vcRef, modalService, zone) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.zone = zone;
        _this.plugins = [];
        _this.selectedPlugin = "Drawing";
        _this.drawings = [];
        return _this;
    }
    InputComponent.prototype.ngOnInit = function () {
        this.addPluginToSegmentedBar("Drawing");
        this.addPluginToSegmentedBar("Checkbox");
        this.checkboxHelper = new checkbox_helper_1.CheckboxHelper();
        this.addPluginToSegmentedBar("Numeric");
        if (this.isIOS) {
            this.addPluginToSegmentedBar("IQKeyboard");
            this.iqkeyboardHelper = new iqkeyboard_helper_1.IQKeyboardHelper();
        }
    };
    InputComponent.prototype.addPluginToSegmentedBar = function (name) {
        var drawingPad = new segmented_bar_1.SegmentedBarItem();
        drawingPad.title = name;
        this.plugins.push(drawingPad);
    };
    InputComponent.prototype.pluginChanged = function (args) {
        if (args.value === null) {
            return;
        }
        this.selectedPlugin = this.plugins[args.value].title;
    };
    InputComponent.prototype.getMyDrawing = function (pad) {
        var _this = this;
        pad.getDrawing().then(function (data) {
            console.log(data);
            _this.drawings.push(data);
            _this.clearMyDrawing(pad);
        }, function (err) {
            console.log(err);
        });
    };
    InputComponent.prototype.clearMyDrawing = function (pad) {
        pad.clearDrawing();
    };
    InputComponent.prototype.getPluginInfo = function () {
        var plugins = Array.of(new plugin_info_1.PluginInfo("nativescript-drawingpad", "DrawingPad", "https://github.com/bradmartin/nativescript-texttospeech", "Want to capture a signature, or send doodles from one user to the other? Then this is the plugin for you!"), new plugin_info_1.PluginInfo("nativescript-checkbox", "Checkbox", "https://github.com/bradmartin/nativescript-checkbox", "Add checkboxes and radiobuttons to your app!"), new plugin_info_1.PluginInfo("nativescript-numeric-keyboard", "Numeric Keyboard (iOS)  🔢", "https://github.com/EddyVerbruggen/nativescript-numeric-keyboard", "Replace the meh default number/phone keyboard by this stylish one."));
        if (this.isIOS) {
            plugins.push(new plugin_info_1.PluginInfo("nativescript-IQKeyboardManager", "IQKeyboardManager (iOS)", "https://github.com/tjvantoll/nativescript-IQKeyboardManager", "Tame that wild beast  🐅  of a keyboard  ⌨️  by dropping in this library."));
        }
        return new plugin_info_wrapper_1.PluginInfoWrapper("Input is one of the hardest things on mobile to get right. Here are a few plugins that tackle problems you may encounter with your app.", plugins);
    };
    InputComponent = __decorate([
        core_1.Component({
            selector: "page-input",
            moduleId: module.id,
            templateUrl: "./input.component.html",
            styleUrls: [
                "input-common.css",
                "input.css"
            ],
            animations: [
                animations_1.trigger("from-bottom", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translateY(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translateY(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1600ms 700ms ease-out")]),
                    animations_1.transition("* => void", [animations_1.animate("600ms ease-in")])
                ]),
                animations_1.trigger("fade-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0
                    })),
                    animations_1.transition("void => *", [animations_1.animate("800ms 2000ms ease-out")])
                ]),
                animations_1.trigger("scale-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "scale(1)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "scale(0.9)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1100ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService,
            core_1.NgZone])
    ], InputComponent);
    return InputComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.InputComponent = InputComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQuY29tcG9uZW50LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaW5wdXQuY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBNEU7QUFDNUUsa0RBQWlGO0FBQ2pGLGdGQUE0RTtBQUM1RSx5REFBdUQ7QUFDdkQsNkRBQTBEO0FBQzFELHFEQUFtRDtBQUNuRCxxRUFBa0U7QUFDbEUsbUVBQXFFO0FBR3JFLGlFQUErRDtBQUMvRCw2REFBMkQ7QUE2QzNEO0lBQW9DLGtDQUF5QjtJQU8zRCx3QkFBc0IsYUFBNEIsRUFDNUIsS0FBdUIsRUFDdkIsWUFBZ0MsRUFDbEMsSUFBWTtRQUhoQyxZQUlFLGtCQUFNLGFBQWEsRUFBRSxLQUFLLEVBQUUsWUFBWSxDQUFDLFNBQzFDO1FBTHFCLG1CQUFhLEdBQWIsYUFBYSxDQUFlO1FBQzVCLFdBQUssR0FBTCxLQUFLLENBQWtCO1FBQ3ZCLGtCQUFZLEdBQVosWUFBWSxDQUFvQjtRQUNsQyxVQUFJLEdBQUosSUFBSSxDQUFRO1FBVGhDLGFBQU8sR0FBNEIsRUFBRSxDQUFDO1FBQ3RDLG9CQUFjLEdBQVcsU0FBUyxDQUFDO1FBQ25DLGNBQVEsR0FBZSxFQUFFLENBQUM7O0lBUzFCLENBQUM7SUFFRCxpQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN6QyxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksZ0NBQWMsRUFBRSxDQUFDO1FBRzNDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUd4QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUNmLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUMzQyxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxvQ0FBZ0IsRUFBRSxDQUFDO1FBQ2pELENBQUM7SUFDSCxDQUFDO0lBRU8sZ0RBQXVCLEdBQS9CLFVBQWdDLElBQVk7UUFDMUMsSUFBSSxVQUFVLEdBQUcsSUFBSSxnQ0FBZ0IsRUFBRSxDQUFDO1FBQ3hDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBQ2hDLENBQUM7SUFFRCxzQ0FBYSxHQUFiLFVBQWMsSUFBd0I7UUFDcEMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3hCLE1BQU0sQ0FBQztRQUNULENBQUM7UUFDRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEtBQUssQ0FBQztJQUN2RCxDQUFDO0lBRUQscUNBQVksR0FBWixVQUFhLEdBQWU7UUFBNUIsaUJBU0M7UUFQQyxHQUFHLENBQUMsVUFBVSxFQUFFLENBQUMsSUFBSSxDQUFDLFVBQUEsSUFBSTtZQUN4QixPQUFPLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ2xCLEtBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3pCLEtBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDM0IsQ0FBQyxFQUFFLFVBQUEsR0FBRztZQUNKLE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDbkIsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsdUNBQWMsR0FBZCxVQUFlLEdBQWU7UUFDNUIsR0FBRyxDQUFDLFlBQVksRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFUyxzQ0FBYSxHQUF2QjtRQUNFLElBQUksT0FBTyxHQUFHLEtBQUssQ0FBQyxFQUFFLENBQ2xCLElBQUksd0JBQVUsQ0FDVix5QkFBeUIsRUFDekIsWUFBWSxFQUNaLHlEQUF5RCxFQUN6RCwyR0FBMkcsQ0FBQyxFQUVoSCxJQUFJLHdCQUFVLENBQ1YsdUJBQXVCLEVBQ3ZCLFVBQVUsRUFDVixxREFBcUQsRUFDckQsOENBQThDLENBQUMsRUFFbkQsSUFBSSx3QkFBVSxDQUNWLCtCQUErQixFQUMvQiw0QkFBNEIsRUFDNUIsaUVBQWlFLEVBQ2pFLG9FQUFvRSxDQUN2RSxDQUNKLENBQUM7UUFFRixFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztZQUNmLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSx3QkFBVSxDQUN2QixnQ0FBZ0MsRUFDaEMseUJBQXlCLEVBQ3pCLDZEQUE2RCxFQUM3RCwyRUFBMkUsQ0FDOUUsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELE1BQU0sQ0FBQyxJQUFJLHVDQUFpQixDQUN4Qix5SUFBeUksRUFDekksT0FBTyxDQUNWLENBQUM7SUFDSixDQUFDO0lBNUZVLGNBQWM7UUEzQzFCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsWUFBWTtZQUN0QixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLHdCQUF3QjtZQUNyQyxTQUFTLEVBQUU7Z0JBQ1Asa0JBQWtCO2dCQUNsQixXQUFXO2FBQ2Q7WUFDRCxVQUFVLEVBQUU7Z0JBQ1Ysb0JBQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQ3JCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxlQUFlO3FCQUMzQixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLGlCQUFpQjtxQkFDN0IsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7b0JBQzNELHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO2lCQUNwRCxDQUFDO2dCQUNGLG9CQUFPLENBQUMsU0FBUyxFQUFFO29CQUNqQixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQztxQkFDYixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7cUJBQ2IsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7aUJBQzVELENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxVQUFVLEVBQUU7b0JBQ2xCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxVQUFVO3FCQUN0QixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLFlBQVk7cUJBQ3hCLENBQUMsQ0FBQztvQkFDSCx1QkFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDLG9CQUFPLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDO2lCQUN0RCxDQUFDO2FBQ0g7U0FDRixDQUFDO3lDQVFxQyw4QkFBYTtZQUNyQix1QkFBZ0I7WUFDVCx5Q0FBa0I7WUFDNUIsYUFBTTtPQVZyQixjQUFjLENBNkYxQjtJQUFELHFCQUFDO0NBQUEsQUE3RkQsQ0FBb0Msd0RBQXlCLEdBNkY1RDtBQTdGWSx3Q0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgTmdab25lLCBPbkluaXQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBhbmltYXRlLCBzdGF0ZSwgc3R5bGUsIHRyYW5zaXRpb24sIHRyaWdnZXIgfSBmcm9tIFwiQGFuZ3VsYXIvYW5pbWF0aW9uc1wiO1xyXG5pbXBvcnQgeyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IH0gZnJvbSBcIi4uL2Fic3RyYWN0LW1lbnUtcGFnZS1jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgTWVudUNvbXBvbmVudCB9IGZyb20gXCIuLi9tZW51L21lbnUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IE1vZGFsRGlhbG9nU2VydmljZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhclwiO1xyXG5pbXBvcnQgeyBQbHVnaW5JbmZvIH0gZnJvbSBcIi4uL3NoYXJlZC9wbHVnaW4taW5mb1wiO1xyXG5pbXBvcnQgeyBQbHVnaW5JbmZvV3JhcHBlciB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm8td3JhcHBlclwiO1xyXG5pbXBvcnQgeyBTZWdtZW50ZWRCYXJJdGVtIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvc2VnbWVudGVkLWJhclwiO1xyXG5pbXBvcnQgeyBQcm9wZXJ0eUNoYW5nZURhdGEgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9kYXRhL29ic2VydmFibGVcIjtcclxuaW1wb3J0IHsgRHJhd2luZ1BhZCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZHJhd2luZ3BhZFwiO1xyXG5pbXBvcnQgeyBJUUtleWJvYXJkSGVscGVyIH0gZnJvbSBcIi4vaGVscGVycy9pcWtleWJvYXJkLWhlbHBlclwiO1xyXG5pbXBvcnQgeyBDaGVja2JveEhlbHBlciB9IGZyb20gXCIuL2hlbHBlcnMvY2hlY2tib3gtaGVscGVyXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJwYWdlLWlucHV0XCIsXHJcbiAgbW9kdWxlSWQ6IG1vZHVsZS5pZCxcclxuICB0ZW1wbGF0ZVVybDogXCIuL2lucHV0LmNvbXBvbmVudC5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXHJcbiAgICAgIFwiaW5wdXQtY29tbW9uLmNzc1wiLFxyXG4gICAgICBcImlucHV0LmNzc1wiXHJcbiAgXSxcclxuICBhbmltYXRpb25zOiBbXHJcbiAgICB0cmlnZ2VyKFwiZnJvbS1ib3R0b21cIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWSgwKVwiXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMCxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWSgyMCUpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiMTYwMG1zIDcwMG1zIGVhc2Utb3V0XCIpXSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCIqID0+IHZvaWRcIiwgW2FuaW1hdGUoXCI2MDBtcyBlYXNlLWluXCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcImZhZGUtaW5cIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMVxyXG4gICAgICB9KSksXHJcbiAgICAgIHN0YXRlKFwidm9pZFwiLCBzdHlsZSh7XHJcbiAgICAgICAgXCJvcGFjaXR5XCI6IDBcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiODAwbXMgMjAwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcInNjYWxlLWluXCIsIFtcclxuICAgICAgc3RhdGUoXCJpblwiLCBzdHlsZSh7XHJcbiAgICAgICAgXCJvcGFjaXR5XCI6IDEsXHJcbiAgICAgICAgdHJhbnNmb3JtOiBcInNjYWxlKDEpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJzY2FsZSgwLjkpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiMTEwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgSW5wdXRDb21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBwbHVnaW5zOiBBcnJheTxTZWdtZW50ZWRCYXJJdGVtPiA9IFtdO1xyXG4gIHNlbGVjdGVkUGx1Z2luOiBzdHJpbmcgPSBcIkRyYXdpbmdcIjtcclxuICBkcmF3aW5nczogQXJyYXk8YW55PiA9IFtdO1xyXG4gIGlxa2V5Ym9hcmRIZWxwZXI6IElRS2V5Ym9hcmRIZWxwZXI7XHJcbiAgY2hlY2tib3hIZWxwZXI6IENoZWNrYm94SGVscGVyO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgbWVudUNvbXBvbmVudDogTWVudUNvbXBvbmVudCxcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgdmNSZWY6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgICAgICAgcHJvdGVjdGVkIG1vZGFsU2VydmljZTogTW9kYWxEaWFsb2dTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgIHByaXZhdGUgem9uZTogTmdab25lKSB7XHJcbiAgICBzdXBlcihtZW51Q29tcG9uZW50LCB2Y1JlZiwgbW9kYWxTZXJ2aWNlKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgdGhpcy5hZGRQbHVnaW5Ub1NlZ21lbnRlZEJhcihcIkRyYXdpbmdcIik7XHJcbiAgICB0aGlzLmFkZFBsdWdpblRvU2VnbWVudGVkQmFyKFwiQ2hlY2tib3hcIik7XHJcbiAgICB0aGlzLmNoZWNrYm94SGVscGVyID0gbmV3IENoZWNrYm94SGVscGVyKCk7XHJcblxyXG4gICAgLy8gdGhpcyBvbmUgaGFzIGEgZGVjZW50IGZhbGxiYWNrIG9uIEFuZHJvaWQuLlxyXG4gICAgdGhpcy5hZGRQbHVnaW5Ub1NlZ21lbnRlZEJhcihcIk51bWVyaWNcIik7XHJcblxyXG4gICAgLy8gLi4gYnV0IHRoaXMgb25lIGRvZXNuJ3RcclxuICAgIGlmICh0aGlzLmlzSU9TKSB7XHJcbiAgICAgIHRoaXMuYWRkUGx1Z2luVG9TZWdtZW50ZWRCYXIoXCJJUUtleWJvYXJkXCIpO1xyXG4gICAgICB0aGlzLmlxa2V5Ym9hcmRIZWxwZXIgPSBuZXcgSVFLZXlib2FyZEhlbHBlcigpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBhZGRQbHVnaW5Ub1NlZ21lbnRlZEJhcihuYW1lOiBzdHJpbmcpIHtcclxuICAgIGxldCBkcmF3aW5nUGFkID0gbmV3IFNlZ21lbnRlZEJhckl0ZW0oKTtcclxuICAgIGRyYXdpbmdQYWQudGl0bGUgPSBuYW1lO1xyXG4gICAgdGhpcy5wbHVnaW5zLnB1c2goZHJhd2luZ1BhZCk7XHJcbiAgfVxyXG5cclxuICBwbHVnaW5DaGFuZ2VkKGFyZ3M6IFByb3BlcnR5Q2hhbmdlRGF0YSk6IHZvaWQge1xyXG4gICAgaWYgKGFyZ3MudmFsdWUgPT09IG51bGwpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG4gICAgdGhpcy5zZWxlY3RlZFBsdWdpbiA9IHRoaXMucGx1Z2luc1thcmdzLnZhbHVlXS50aXRsZTtcclxuICB9XHJcblxyXG4gIGdldE15RHJhd2luZyhwYWQ6IERyYXdpbmdQYWQpIHtcclxuICAgIC8vIHRoZW4gZ2V0IHRoZSBkcmF3aW5nIChCaXRtYXAgb24gQW5kcm9pZCkgb2YgdGhlIGRyYXdpbmdwYWRcclxuICAgIHBhZC5nZXREcmF3aW5nKCkudGhlbihkYXRhID0+IHtcclxuICAgICAgY29uc29sZS5sb2coZGF0YSk7XHJcbiAgICAgIHRoaXMuZHJhd2luZ3MucHVzaChkYXRhKTtcclxuICAgICAgdGhpcy5jbGVhck15RHJhd2luZyhwYWQpO1xyXG4gICAgfSwgZXJyID0+IHtcclxuICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgY2xlYXJNeURyYXdpbmcocGFkOiBEcmF3aW5nUGFkKSB7XHJcbiAgICBwYWQuY2xlYXJEcmF3aW5nKCk7XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgZ2V0UGx1Z2luSW5mbygpOiBQbHVnaW5JbmZvV3JhcHBlciB7XHJcbiAgICBsZXQgcGx1Z2lucyA9IEFycmF5Lm9mKFxyXG4gICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1kcmF3aW5ncGFkXCIsXHJcbiAgICAgICAgICAgIFwiRHJhd2luZ1BhZFwiLFxyXG4gICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9icmFkbWFydGluL25hdGl2ZXNjcmlwdC10ZXh0dG9zcGVlY2hcIixcclxuICAgICAgICAgICAgXCJXYW50IHRvIGNhcHR1cmUgYSBzaWduYXR1cmUsIG9yIHNlbmQgZG9vZGxlcyBmcm9tIG9uZSB1c2VyIHRvIHRoZSBvdGhlcj8gVGhlbiB0aGlzIGlzIHRoZSBwbHVnaW4gZm9yIHlvdSFcIiksXHJcblxyXG4gICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1jaGVja2JveFwiLFxyXG4gICAgICAgICAgICBcIkNoZWNrYm94XCIsXHJcbiAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL2JyYWRtYXJ0aW4vbmF0aXZlc2NyaXB0LWNoZWNrYm94XCIsXHJcbiAgICAgICAgICAgIFwiQWRkIGNoZWNrYm94ZXMgYW5kIHJhZGlvYnV0dG9ucyB0byB5b3VyIGFwcCFcIiksXHJcblxyXG4gICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1udW1lcmljLWtleWJvYXJkXCIsXHJcbiAgICAgICAgICAgIFwiTnVtZXJpYyBLZXlib2FyZCAoaU9TKSAg7aC97bSiXCIsXHJcbiAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL0VkZHlWZXJicnVnZ2VuL25hdGl2ZXNjcmlwdC1udW1lcmljLWtleWJvYXJkXCIsXHJcbiAgICAgICAgICAgIFwiUmVwbGFjZSB0aGUgbWVoIGRlZmF1bHQgbnVtYmVyL3Bob25lIGtleWJvYXJkIGJ5IHRoaXMgc3R5bGlzaCBvbmUuXCJcclxuICAgICAgICApXHJcbiAgICApO1xyXG5cclxuICAgIGlmICh0aGlzLmlzSU9TKSB7XHJcbiAgICAgIHBsdWdpbnMucHVzaChuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgIFwibmF0aXZlc2NyaXB0LUlRS2V5Ym9hcmRNYW5hZ2VyXCIsXHJcbiAgICAgICAgICBcIklRS2V5Ym9hcmRNYW5hZ2VyIChpT1MpXCIsXHJcbiAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS90anZhbnRvbGwvbmF0aXZlc2NyaXB0LUlRS2V5Ym9hcmRNYW5hZ2VyXCIsXHJcbiAgICAgICAgICBcIlRhbWUgdGhhdCB3aWxkIGJlYXN0ICDtoL3tsIUgIG9mIGEga2V5Ym9hcmQgIOKMqO+4jyAgYnkgZHJvcHBpbmcgaW4gdGhpcyBsaWJyYXJ5LlwiXHJcbiAgICAgICkpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBuZXcgUGx1Z2luSW5mb1dyYXBwZXIoXHJcbiAgICAgICAgXCJJbnB1dCBpcyBvbmUgb2YgdGhlIGhhcmRlc3QgdGhpbmdzIG9uIG1vYmlsZSB0byBnZXQgcmlnaHQuIEhlcmUgYXJlIGEgZmV3IHBsdWdpbnMgdGhhdCB0YWNrbGUgcHJvYmxlbXMgeW91IG1heSBlbmNvdW50ZXIgd2l0aCB5b3VyIGFwcC5cIixcclxuICAgICAgICBwbHVnaW5zXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG4iXX0=