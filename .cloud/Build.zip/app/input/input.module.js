Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var input_routing_module_1 = require("./input-routing.module");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var input_component_1 = require("./input.component");
var angular_1 = require("nativescript-checkbox/angular");
var element_registry_1 = require("nativescript-angular/element-registry");
var nativescript_angular_1 = require("nativescript-angular");
element_registry_1.registerElement("DrawingPad", function () { return require("nativescript-drawingpad").DrawingPad; });
element_registry_1.registerElement("NumericKeyboard", function () { return require("nativescript-numeric-keyboard").NumericKeyboardView; });
var InputModule = (function () {
    function InputModule() {
    }
    InputModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                nativescript_angular_1.NativeScriptFormsModule,
                angular_1.TNSCheckBoxModule,
                input_routing_module_1.InputRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
            ],
            declarations: [
                input_component_1.InputComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], InputModule);
    return InputModule;
}());
exports.InputModule = InputModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5wdXQubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiaW5wdXQubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBMkQ7QUFDM0Qsc0RBQXVFO0FBRXZFLCtEQUE0RDtBQUM1RCx1RUFBOEQ7QUFDOUQscURBQW1EO0FBQ25ELHlEQUFrRTtBQUVsRSwwRUFBd0U7QUFDeEUsNkRBQStEO0FBRS9ELGtDQUFlLENBQUMsWUFBWSxFQUFFLGNBQU0sT0FBQSxPQUFPLENBQUMseUJBQXlCLENBQUMsQ0FBQyxVQUFVLEVBQTdDLENBQTZDLENBQUMsQ0FBQztBQUNuRixrQ0FBZSxDQUFDLGlCQUFpQixFQUFFLGNBQU0sT0FBQSxPQUFPLENBQUMsK0JBQStCLENBQUMsQ0FBQyxtQkFBbUIsRUFBNUQsQ0FBNEQsQ0FBQyxDQUFDO0FBaUJ2RztJQUFBO0lBQ0EsQ0FBQztJQURZLFdBQVc7UUFmdkIsZUFBUSxDQUFDO1lBQ1IsT0FBTyxFQUFFO2dCQUNQLGlDQUF3QjtnQkFDeEIsOENBQXVCO2dCQUN2QiwyQkFBaUI7Z0JBQ2pCLHlDQUFrQjtnQkFDbEIsNkNBQWlCO2FBQ2xCO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLGdDQUFjO2FBQ2Y7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsdUJBQWdCO2FBQ2pCO1NBQ0YsQ0FBQztPQUNXLFdBQVcsQ0FDdkI7SUFBRCxrQkFBQztDQUFBLEFBREQsSUFDQztBQURZLGtDQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUsIE5PX0VSUk9SU19TQ0hFTUEgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvY29tbW9uXCI7XHJcblxyXG5pbXBvcnQgeyBJbnB1dFJvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9pbnB1dC1yb3V0aW5nLm1vZHVsZVwiO1xyXG5pbXBvcnQgeyBUTlNGb250SWNvbk1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtbmd4LWZvbnRpY29uXCI7XHJcbmltcG9ydCB7IElucHV0Q29tcG9uZW50IH0gZnJvbSBcIi4vaW5wdXQuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IFROU0NoZWNrQm94TW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1jaGVja2JveC9hbmd1bGFyXCI7XHJcblxyXG5pbXBvcnQgeyByZWdpc3RlckVsZW1lbnQgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvZWxlbWVudC1yZWdpc3RyeVwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRGb3Jtc01vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhclwiO1xyXG5cclxucmVnaXN0ZXJFbGVtZW50KFwiRHJhd2luZ1BhZFwiLCAoKSA9PiByZXF1aXJlKFwibmF0aXZlc2NyaXB0LWRyYXdpbmdwYWRcIikuRHJhd2luZ1BhZCk7XHJcbnJlZ2lzdGVyRWxlbWVudChcIk51bWVyaWNLZXlib2FyZFwiLCAoKSA9PiByZXF1aXJlKFwibmF0aXZlc2NyaXB0LW51bWVyaWMta2V5Ym9hcmRcIikuTnVtZXJpY0tleWJvYXJkVmlldyk7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICAgIE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcclxuICAgIE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlLFxyXG4gICAgVE5TQ2hlY2tCb3hNb2R1bGUsXHJcbiAgICBJbnB1dFJvdXRpbmdNb2R1bGUsXHJcbiAgICBUTlNGb250SWNvbk1vZHVsZSxcclxuICBdLFxyXG4gIGRlY2xhcmF0aW9uczogW1xyXG4gICAgSW5wdXRDb21wb25lbnRcclxuICBdLFxyXG4gIHNjaGVtYXM6IFtcclxuICAgIE5PX0VSUk9SU19TQ0hFTUFcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBJbnB1dE1vZHVsZSB7XHJcbn1cclxuIl19