Object.defineProperty(exports, "__esModule", { value: true });
var RadioOption = (function () {
    function RadioOption(label) {
        this.label = label;
    }
    return RadioOption;
}());
var CheckboxHelper = (function () {
    function CheckboxHelper() {
        this.radios = [];
        this.radios.push(new RadioOption("NativeScript!"));
        this.radios.push(new RadioOption("React Native!"));
    }
    CheckboxHelper.prototype.radioOptionSelected = function (radio) {
        radio.selected = !radio.selected;
        if (!radio.selected) {
            return;
        }
        this.radios.forEach(function (option) {
            if (option.label !== radio.label) {
                option.selected = false;
            }
        });
    };
    return CheckboxHelper;
}());
exports.CheckboxHelper = CheckboxHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3gtaGVscGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY2hlY2tib3gtaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTtJQUlFLHFCQUFZLEtBQWE7UUFDdkIsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUM7SUFDckIsQ0FBQztJQUNILGtCQUFDO0FBQUQsQ0FBQyxBQVBELElBT0M7QUFFRDtJQUtFO1FBRkEsV0FBTSxHQUF1QixFQUFFLENBQUM7UUFHOUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxXQUFXLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLFdBQVcsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO0lBQ3JELENBQUM7SUFFRCw0Q0FBbUIsR0FBbkIsVUFBb0IsS0FBa0I7UUFDcEMsS0FBSyxDQUFDLFFBQVEsR0FBRyxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7UUFFakMsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNwQixNQUFNLENBQUM7UUFDVCxDQUFDO1FBR0QsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBQSxNQUFNO1lBQ3hCLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEtBQUssS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLE1BQU0sQ0FBQyxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQzFCLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDSCxxQkFBQztBQUFELENBQUMsQUF4QkQsSUF3QkM7QUF4Qlksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJjbGFzcyBSYWRpb09wdGlvbiB7XHJcbiAgbGFiZWw6IHN0cmluZztcclxuICBzZWxlY3RlZDogYm9vbGVhbjtcclxuXHJcbiAgY29uc3RydWN0b3IobGFiZWw6IHN0cmluZykge1xyXG4gICAgdGhpcy5sYWJlbCA9IGxhYmVsO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIENoZWNrYm94SGVscGVyIHtcclxuICBjaGVja2JveDE6IGJvb2xlYW47XHJcbiAgY2hlY2tib3gyOiBib29sZWFuO1xyXG4gIHJhZGlvczogQXJyYXk8UmFkaW9PcHRpb24+ID0gW107XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy5yYWRpb3MucHVzaChuZXcgUmFkaW9PcHRpb24oXCJOYXRpdmVTY3JpcHQhXCIpKTtcclxuICAgIHRoaXMucmFkaW9zLnB1c2gobmV3IFJhZGlvT3B0aW9uKFwiUmVhY3QgTmF0aXZlIVwiKSk7XHJcbiAgfVxyXG5cclxuICByYWRpb09wdGlvblNlbGVjdGVkKHJhZGlvOiBSYWRpb09wdGlvbik6IHZvaWQge1xyXG4gICAgcmFkaW8uc2VsZWN0ZWQgPSAhcmFkaW8uc2VsZWN0ZWQ7XHJcblxyXG4gICAgaWYgKCFyYWRpby5zZWxlY3RlZCkge1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgLy8gdW5jaGVjayBhbGwgb3RoZXIgb3B0aW9uc1xyXG4gICAgdGhpcy5yYWRpb3MuZm9yRWFjaChvcHRpb24gPT4ge1xyXG4gICAgICBpZiAob3B0aW9uLmxhYmVsICE9PSByYWRpby5sYWJlbCkge1xyXG4gICAgICAgIG9wdGlvbi5zZWxlY3RlZCA9IGZhbHNlO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcbn0iXX0=