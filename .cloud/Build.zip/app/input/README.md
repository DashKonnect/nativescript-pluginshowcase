## Input

- [nativescript-checkbox](https://github.com/bradmartin/nativescript-checkbox)
- [nativescript-drawingpad](https://github.com/bradmartin/nativescript-texttospeech)
- [nativescript-IQKeyboardManager](https://github.com/tjvantoll/nativescript-IQKeyboardManager)
- [nativescript-numeric-keyboard](https://github.com/EddyVerbruggen/nativescript-numeric-keyboard)

<img src="../../screenshots/themes/input.png" width="375px"/>