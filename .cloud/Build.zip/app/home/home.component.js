Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var config_1 = require("../shared/config");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var HomeComponent = (function (_super) {
    __extends(HomeComponent, _super);
    function HomeComponent(menuComponent, vcRef, modalService, routerExtensions) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.routerExtensions = routerExtensions;
        return _this;
    }
    HomeComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (!config_1.Config.isProdMode && config_1.Config.DEBUG_MODE.firstPage !== "/menu") {
            setTimeout(function () {
                _this.routerExtensions.navigate([config_1.Config.DEBUG_MODE.firstPage], {
                    animated: false
                });
            }, 200);
        }
    };
    HomeComponent.prototype.getPluginInfo = function () {
        return new plugin_info_wrapper_1.PluginInfoWrapper("This NativeScript plugin showcases app has an info-icon on every page, showing which plugins are used. Those listed below are used app-wide. Like these plugins, this app is open source as well: goo.gl/7HUAXa", Array.of(new plugin_info_1.PluginInfo("nativescript-gradient", "Gradient", "https://github.com/EddyVerbruggen/nativescript-gradient", "All pages (including the menu) have a nice top-to-bottom gradient. You obviously need to have this to be taken seriously as an app. 🤔"), new plugin_info_1.PluginInfo("nativescript-appavailability", "App Availability", "https://github.com/EddyVerbruggen/nativescript-appavailability", "Used at the bottom ↙️ of the menu to determine whether or not you have the Twitter app installed."), new plugin_info_1.PluginInfo("nativescript-pro-ui", "Progress NativeScript UI Pro", "https://www.npmjs.com/package/nativescript-pro-ui", "We're leveraging the SideDrawer of this awesome (now free!) UI library."), new plugin_info_1.PluginInfo("nativescript-ngx-fonticon", "Font icon", "https://github.com/NathanWalker/nativescript-ngx-fonticon", "Makes it easy to use font icons with NativeScript. We're using materialdesignicons.com")));
    };
    HomeComponent = __decorate([
        core_1.Component({
            selector: "page-home",
            moduleId: module.id,
            templateUrl: "./home.component.html",
            styleUrls: ["home-common.css"],
            animations: [
                animations_1.trigger("state", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "scale(1)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "scale(0.9)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1300ms ease-out")])
                ]),
                animations_1.trigger("plugincountstate", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "scale(1) rotate(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "scale(0) rotate(-1300)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("2300ms 1000ms ease-out")])
                ]),
                animations_1.trigger("fade-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1600ms 3200ms ease-out")])
                ]),
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService,
            nativescript_angular_1.RouterExtensions])
    ], HomeComponent);
    return HomeComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaG9tZS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJob21lLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQW9FO0FBQ3BFLGtEQU02QjtBQUM3QixnRkFBNEU7QUFDNUUseURBQXVEO0FBQ3ZELDJDQUEwQztBQUMxQyw2REFBNEU7QUFDNUUscURBQW1EO0FBQ25ELHFFQUFrRTtBQTBDbEU7SUFBbUMsaUNBQXlCO0lBQzFELHVCQUFzQixhQUE0QixFQUM1QixLQUF1QixFQUN2QixZQUFnQyxFQUNoQyxnQkFBa0M7UUFIeEQsWUFJRSxrQkFBTSxhQUFhLEVBQUUsS0FBSyxFQUFFLFlBQVksQ0FBQyxTQUMxQztRQUxxQixtQkFBYSxHQUFiLGFBQWEsQ0FBZTtRQUM1QixXQUFLLEdBQUwsS0FBSyxDQUFrQjtRQUN2QixrQkFBWSxHQUFaLFlBQVksQ0FBb0I7UUFDaEMsc0JBQWdCLEdBQWhCLGdCQUFnQixDQUFrQjs7SUFFeEQsQ0FBQztJQUVELGdDQUFRLEdBQVI7UUFBQSxpQkFTQztRQVBDLEVBQUUsQ0FBQyxDQUFDLENBQUMsZUFBTSxDQUFDLFVBQVUsSUFBSSxlQUFNLENBQUMsVUFBVSxDQUFDLFNBQVMsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDO1lBQ2xFLFVBQVUsQ0FBQztnQkFDVCxLQUFJLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUMsZUFBTSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsRUFBRTtvQkFDNUQsUUFBUSxFQUFFLEtBQUs7aUJBQ2hCLENBQUMsQ0FBQztZQUNMLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQztRQUNWLENBQUM7SUFDSCxDQUFDO0lBRVMscUNBQWEsR0FBdkI7UUFDRSxNQUFNLENBQUMsSUFBSSx1Q0FBaUIsQ0FDeEIsaU5BQWlOLEVBQ2pOLEtBQUssQ0FBQyxFQUFFLENBQ0osSUFBSSx3QkFBVSxDQUNWLHVCQUF1QixFQUN2QixVQUFVLEVBQ1YseURBQXlELEVBQ3pELHdJQUF3SSxDQUFDLEVBRTdJLElBQUksd0JBQVUsQ0FDViw4QkFBOEIsRUFDOUIsa0JBQWtCLEVBQ2xCLGdFQUFnRSxFQUNoRSxtR0FBbUcsQ0FDdEcsRUFFRCxJQUFJLHdCQUFVLENBQ1YscUJBQXFCLEVBQ3JCLDhCQUE4QixFQUM5QixtREFBbUQsRUFDbkQseUVBQXlFLENBQzVFLEVBRUQsSUFBSSx3QkFBVSxDQUNWLDJCQUEyQixFQUMzQixXQUFXLEVBQ1gsMkRBQTJELEVBQzNELHdGQUF3RixDQUMzRixDQUNKLENBQ0osQ0FBQztJQUNKLENBQUM7SUFuRFUsYUFBYTtRQXhDekIsZ0JBQVMsQ0FBQztZQUNULFFBQVEsRUFBRSxXQUFXO1lBQ3JCLFFBQVEsRUFBRSxNQUFNLENBQUMsRUFBRTtZQUNuQixXQUFXLEVBQUUsdUJBQXVCO1lBQ3BDLFNBQVMsRUFBRSxDQUFDLGlCQUFpQixDQUFDO1lBQzlCLFVBQVUsRUFBRTtnQkFDVixvQkFBTyxDQUFDLE9BQU8sRUFBRTtvQkFDZixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQzt3QkFDWixTQUFTLEVBQUUsVUFBVTtxQkFDdEIsQ0FBQyxDQUFDO29CQUNILGtCQUFLLENBQUMsTUFBTSxFQUFFLGtCQUFLLENBQUM7d0JBQ2xCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxZQUFZO3FCQUN4QixDQUFDLENBQUM7b0JBQ0gsdUJBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxvQkFBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztpQkFDdEQsQ0FBQztnQkFDRixvQkFBTyxDQUFDLGtCQUFrQixFQUFFO29CQUMxQixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQzt3QkFDWixTQUFTLEVBQUUsb0JBQW9CO3FCQUNoQyxDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLHdCQUF3QjtxQkFDcEMsQ0FBQyxDQUFDO29CQUVILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDLENBQUM7aUJBQzdELENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxTQUFTLEVBQUU7b0JBQ2pCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3FCQUNiLENBQUMsQ0FBQztvQkFDSCxrQkFBSyxDQUFDLE1BQU0sRUFBRSxrQkFBSyxDQUFDO3dCQUNsQixTQUFTLEVBQUUsQ0FBQztxQkFDYixDQUFDLENBQUM7b0JBQ0gsdUJBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxvQkFBTyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQztpQkFDN0QsQ0FBQzthQUNIO1NBQ0YsQ0FBQzt5Q0FFcUMsOEJBQWE7WUFDckIsdUJBQWdCO1lBQ1QseUNBQWtCO1lBQ2QsdUNBQWdCO09BSjdDLGFBQWEsQ0FvRHpCO0lBQUQsb0JBQUM7Q0FBQSxBQXBERCxDQUFtQyx3REFBeUIsR0FvRDNEO0FBcERZLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29tcG9uZW50LCBPbkluaXQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQge1xyXG4gIHRyaWdnZXIsXHJcbiAgc3RhdGUsXHJcbiAgc3R5bGUsXHJcbiAgYW5pbWF0ZSxcclxuICB0cmFuc2l0aW9uXHJcbn0gZnJvbSBcIkBhbmd1bGFyL2FuaW1hdGlvbnNcIjtcclxuaW1wb3J0IHsgQWJzdHJhY3RNZW51UGFnZUNvbXBvbmVudCB9IGZyb20gXCIuLi9hYnN0cmFjdC1tZW51LXBhZ2UtY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IE1lbnVDb21wb25lbnQgfSBmcm9tIFwiLi4vbWVudS9tZW51LmNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBDb25maWcgfSBmcm9tIFwiLi4vc2hhcmVkL2NvbmZpZ1wiO1xyXG5pbXBvcnQgeyBNb2RhbERpYWxvZ1NlcnZpY2UsIFJvdXRlckV4dGVuc2lvbnMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mbyB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm9cIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mb1dyYXBwZXIgfSBmcm9tIFwiLi4vc2hhcmVkL3BsdWdpbi1pbmZvLXdyYXBwZXJcIjtcclxuXHJcbkBDb21wb25lbnQoe1xyXG4gIHNlbGVjdG9yOiBcInBhZ2UtaG9tZVwiLFxyXG4gIG1vZHVsZUlkOiBtb2R1bGUuaWQsXHJcbiAgdGVtcGxhdGVVcmw6IFwiLi9ob21lLmNvbXBvbmVudC5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXCJob21lLWNvbW1vbi5jc3NcIl0sXHJcbiAgYW5pbWF0aW9uczogW1xyXG4gICAgdHJpZ2dlcihcInN0YXRlXCIsIFtcclxuICAgICAgc3RhdGUoXCJpblwiLCBzdHlsZSh7XHJcbiAgICAgICAgXCJvcGFjaXR5XCI6IDEsXHJcbiAgICAgICAgdHJhbnNmb3JtOiBcInNjYWxlKDEpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJzY2FsZSgwLjkpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiMTMwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcInBsdWdpbmNvdW50c3RhdGVcIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwic2NhbGUoMSkgcm90YXRlKDApXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJzY2FsZSgwKSByb3RhdGUoLTEzMDApXCJcclxuICAgICAgfSkpLFxyXG4gICAgICAvLyBcImFmdGVyIGEgZGVsYXkgb2YgMTAwMG1zLCBzaG93IGFuIGFuaW1hdGlvbiB3aXRoIGEgZHVyYXRpb24gb2YgMjMwMG1zXCJcclxuICAgICAgdHJhbnNpdGlvbihcInZvaWQgPT4gKlwiLCBbYW5pbWF0ZShcIjIzMDBtcyAxMDAwbXMgZWFzZS1vdXRcIildKVxyXG4gICAgXSksXHJcbiAgICB0cmlnZ2VyKFwiZmFkZS1pblwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAxXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMFxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCIxNjAwbXMgMzIwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gIF1cclxufSlcclxuZXhwb3J0IGNsYXNzIEhvbWVDb21wb25lbnQgZXh0ZW5kcyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IGltcGxlbWVudHMgT25Jbml0IHtcclxuICBjb25zdHJ1Y3Rvcihwcm90ZWN0ZWQgbWVudUNvbXBvbmVudDogTWVudUNvbXBvbmVudCxcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgdmNSZWY6IFZpZXdDb250YWluZXJSZWYsXHJcbiAgICAgICAgICAgICAgcHJvdGVjdGVkIG1vZGFsU2VydmljZTogTW9kYWxEaWFsb2dTZXJ2aWNlLFxyXG4gICAgICAgICAgICAgIHByb3RlY3RlZCByb3V0ZXJFeHRlbnNpb25zOiBSb3V0ZXJFeHRlbnNpb25zKSB7XHJcbiAgICBzdXBlcihtZW51Q29tcG9uZW50LCB2Y1JlZiwgbW9kYWxTZXJ2aWNlKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgLy8gZm9yIHF1aWNrIGRldi1uYXZcclxuICAgIGlmICghQ29uZmlnLmlzUHJvZE1vZGUgJiYgQ29uZmlnLkRFQlVHX01PREUuZmlyc3RQYWdlICE9PSBcIi9tZW51XCIpIHtcclxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgdGhpcy5yb3V0ZXJFeHRlbnNpb25zLm5hdmlnYXRlKFtDb25maWcuREVCVUdfTU9ERS5maXJzdFBhZ2VdLCB7XHJcbiAgICAgICAgICBhbmltYXRlZDogZmFsc2VcclxuICAgICAgICB9KTtcclxuICAgICAgfSwgMjAwKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBnZXRQbHVnaW5JbmZvKCk6IFBsdWdpbkluZm9XcmFwcGVyIHtcclxuICAgIHJldHVybiBuZXcgUGx1Z2luSW5mb1dyYXBwZXIoXHJcbiAgICAgICAgXCJUaGlzIE5hdGl2ZVNjcmlwdCBwbHVnaW4gc2hvd2Nhc2VzIGFwcCBoYXMgYW4gaW5mby1pY29uIG9uIGV2ZXJ5IHBhZ2UsIHNob3dpbmcgd2hpY2ggcGx1Z2lucyBhcmUgdXNlZC4gVGhvc2UgbGlzdGVkIGJlbG93IGFyZSB1c2VkIGFwcC13aWRlLiBMaWtlIHRoZXNlIHBsdWdpbnMsIHRoaXMgYXBwIGlzIG9wZW4gc291cmNlIGFzIHdlbGw6IGdvby5nbC83SFVBWGFcIixcclxuICAgICAgICBBcnJheS5vZihcclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1ncmFkaWVudFwiLFxyXG4gICAgICAgICAgICAgICAgXCJHcmFkaWVudFwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vbmF0aXZlc2NyaXB0LWdyYWRpZW50XCIsXHJcbiAgICAgICAgICAgICAgICBcIkFsbCBwYWdlcyAoaW5jbHVkaW5nIHRoZSBtZW51KSBoYXZlIGEgbmljZSB0b3AtdG8tYm90dG9tIGdyYWRpZW50LiBZb3Ugb2J2aW91c2x5IG5lZWQgdG8gaGF2ZSB0aGlzIHRvIGJlIHRha2VuIHNlcmlvdXNseSBhcyBhbiBhcHAuIO2gvu20lFwiKSxcclxuXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtYXBwYXZhaWxhYmlsaXR5XCIsXHJcbiAgICAgICAgICAgICAgICBcIkFwcCBBdmFpbGFiaWxpdHlcIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL0VkZHlWZXJicnVnZ2VuL25hdGl2ZXNjcmlwdC1hcHBhdmFpbGFiaWxpdHlcIixcclxuICAgICAgICAgICAgICAgIFwiVXNlZCBhdCB0aGUgYm90dG9tIOKGme+4jyBvZiB0aGUgbWVudSB0byBkZXRlcm1pbmUgd2hldGhlciBvciBub3QgeW91IGhhdmUgdGhlIFR3aXR0ZXIgYXBwIGluc3RhbGxlZC5cIlxyXG4gICAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1wcm8tdWlcIixcclxuICAgICAgICAgICAgICAgIFwiUHJvZ3Jlc3MgTmF0aXZlU2NyaXB0IFVJIFByb1wiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL3d3dy5ucG1qcy5jb20vcGFja2FnZS9uYXRpdmVzY3JpcHQtcHJvLXVpXCIsXHJcbiAgICAgICAgICAgICAgICBcIldlJ3JlIGxldmVyYWdpbmcgdGhlIFNpZGVEcmF3ZXIgb2YgdGhpcyBhd2Vzb21lIChub3cgZnJlZSEpIFVJIGxpYnJhcnkuXCJcclxuICAgICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtbmd4LWZvbnRpY29uXCIsXHJcbiAgICAgICAgICAgICAgICBcIkZvbnQgaWNvblwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vTmF0aGFuV2Fsa2VyL25hdGl2ZXNjcmlwdC1uZ3gtZm9udGljb25cIixcclxuICAgICAgICAgICAgICAgIFwiTWFrZXMgaXQgZWFzeSB0byB1c2UgZm9udCBpY29ucyB3aXRoIE5hdGl2ZVNjcmlwdC4gV2UncmUgdXNpbmcgbWF0ZXJpYWxkZXNpZ25pY29ucy5jb21cIlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgKVxyXG4gICAgKTtcclxuICB9XHJcbn1cclxuIl19