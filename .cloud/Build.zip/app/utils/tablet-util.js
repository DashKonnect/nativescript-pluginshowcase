Object.defineProperty(exports, "__esModule", { value: true });
var config_1 = require("../shared/config");
function addTabletCss(page, pagesPath) {
    if (!config_1.Config.isTablet) {
        return;
    }
    page.className = "tablet";
    var fileName = "~/" + pagesPath + "/" + pagesPath + ".tablet.css";
    page.addCssFile(fileName);
}
exports.addTabletCss = addTabletCss;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFibGV0LXV0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJ0YWJsZXQtdXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsMkNBQTBDO0FBRzFDLHNCQUE2QixJQUFVLEVBQUUsU0FBaUI7SUFDeEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxlQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztRQUNyQixNQUFNLENBQUM7SUFDVCxDQUFDO0lBRUQsSUFBSSxDQUFDLFNBQVMsR0FBRyxRQUFRLENBQUM7SUFFMUIsSUFBSSxRQUFRLEdBQVcsT0FBSyxTQUFTLFNBQUksU0FBUyxnQkFBYSxDQUFDO0lBQ2hFLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDNUIsQ0FBQztBQVRELG9DQVNDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQ29uZmlnIH0gZnJvbSBcIi4uL3NoYXJlZC9jb25maWdcIjtcclxuaW1wb3J0IHsgUGFnZSB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL3BhZ2VcIjtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBhZGRUYWJsZXRDc3MocGFnZTogUGFnZSwgcGFnZXNQYXRoOiBzdHJpbmcpOiB2b2lkIHtcclxuICBpZiAoIUNvbmZpZy5pc1RhYmxldCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuXHJcbiAgcGFnZS5jbGFzc05hbWUgPSBcInRhYmxldFwiO1xyXG5cclxuICBsZXQgZmlsZU5hbWU6IHN0cmluZyA9IGB+LyR7cGFnZXNQYXRofS8ke3BhZ2VzUGF0aH0udGFibGV0LmNzc2A7XHJcbiAgcGFnZS5hZGRDc3NGaWxlKGZpbGVOYW1lKTtcclxufSJdfQ==