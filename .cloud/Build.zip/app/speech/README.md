## Speech

- [nativescript-audio](https://github.com/bradmartin/nativescript-audio)
- [nativescript-calendar](https://github.com/EddyVerbruggen/nativescript-calendar)
- [nativescript-camera](https://github.com/NativeScript/nativescript-camera)
- [nativescript-email](https://github.com/EddyVerbruggen/nativescript-email)
- [nativescript-social-share](https://github.com/tjvantoll/nativescript-social-share)
- [nativescript-speech-recognition](https://github.com/EddyVerbruggen/nativescript-speech-recognition)
- [nativescript-texttospeech](https://github.com/bradmartin/nativescript-texttospeech)

<img src="../../screenshots/themes/speech.png" width="375px"/>