Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var nativescript_texttospeech_1 = require("nativescript-texttospeech");
var nativescript_speech_recognition_1 = require("nativescript-speech-recognition");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var nativescript_email_1 = require("nativescript-email");
var Calendar = require("nativescript-calendar");
var Camera = require("nativescript-camera");
var SocialShare = require("nativescript-social-share");
var ImagePicker = require("nativescript-imagepicker");
var nativescript_audio_1 = require("nativescript-audio");
var image_source_1 = require("tns-core-modules/image-source");
var platform_1 = require("tns-core-modules/platform");
var nativescript_drop_down_1 = require("nativescript-drop-down");
var googleTranslate = require('google-translate')("696d8f6e86f09e1525c0734c4b41b1cbd7b2bdcd");
var SpeechComponent = (function (_super) {
    __extends(SpeechComponent, _super);
    function SpeechComponent(menuComponent, vcRef, modalService, zone) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.zone = zone;
        _this.microphoneEnabled = false;
        _this.recording = false;
        _this.lastTranscription = null;
        _this.spoken = false;
        _this.showingTips = false;
        _this.pitch = 100;
        _this.speakRate = platform_1.isIOS ? 50 : 100;
        _this.maxSpeakRate = platform_1.isIOS ? 100 : 200;
        _this.config = {
            locale: "en-IN",
            returnPartialResults: true,
            onResult: function (transcription) {
                _this.zone.run(function () { return _this.recognizedText = transcription.text; });
                _this.lastTranscription = transcription.text;
                googleTranslate.translate('My name is Brandon', _this.detectLanguage(_this.lastTranscription), function (err, translation) {
                    this.lastTranscription = translation.translatedText;
                });
                if (transcription.finished) {
                    _this.spoken = true;
                    setTimeout(function () { return _this.speak(transcription.text); }, 300);
                }
            },
        };
        _this.items = new nativescript_drop_down_1.ValueList([
            { value: "en-IN", display: "English" },
            { value: "hi-IN", display: "Hindi" },
            { value: "ml-IN", display: "Malayalam" }
        ]);
        return _this;
    }
    SpeechComponent.prototype.detectLanguage = function (text) {
        googleTranslate.detectLanguage('Gracias', function (err, detection) {
            return detection.language;
        });
    };
    SpeechComponent.prototype.onchange = function (args) {
        console.log("Drop Down selected index changed from " + args.oldIndex + " to " + args.newIndex + ".  New value is " + this.items.getValue(args.newIndex));
        this.config.locale = this.items.getValue(args.newIndex);
    };
    SpeechComponent.prototype.onopen = function () {
        console.log("Drop Down opened.");
    };
    SpeechComponent.prototype.onclose = function () {
        console.log("Drop Down closed.");
    };
    SpeechComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.speech2text = new nativescript_speech_recognition_1.SpeechRecognition();
        this.speech2text.available().then(function (avail) {
            _this.recordingAvailable = avail;
        });
        this.text2speech = new nativescript_texttospeech_1.TNSTextToSpeech();
        setTimeout(function () {
            _this.speech2text.requestPermission().then(function (granted) {
                _this.microphoneEnabled = granted;
                if (!platform_1.isIOS) {
                    Camera.requestPermissions();
                }
            });
        }, 1000);
    };
    SpeechComponent.prototype.toggleRecording = function () {
        this.recording = !this.recording;
        if (this.recording) {
            this.spoken = false;
            this.lastTranscription = null;
            this.startListening();
        }
        else {
            this.stopListening();
            if (!this.spoken && this.lastTranscription !== null) {
                this.speak(this.lastTranscription);
            }
        }
    };
    SpeechComponent.prototype.startListening = function () {
        if (!this.recordingAvailable) {
            dialogs_1.alert({
                title: "Not supported",
                message: "Speech recognition not supported on this device. Try a different device please.",
                okButtonText: "Oh, bummer"
            });
            this.recognizedText = "No support, sorry ☹️";
            return;
        }
        this.recording = true;
        this.speech2text.startListening(this.config).then(function (started) {
            console.log("started listening");
        }, function (errorMessage) {
            console.log("Error: " + errorMessage);
        });
    };
    SpeechComponent.prototype.stopListening = function () {
        this.recording = false;
        this.speech2text.stopListening().then(function () {
            console.log("Stopped listening");
        });
    };
    SpeechComponent.prototype.speak = function (text) {
        var _this = this;
        var speakOptions = {
            text: text,
            speakRate: this.getSpeakRate(),
            pitch: this.getPitch(),
            locale: this.config.locale,
            finishedCallback: function () {
                _this.handleFollowUpAction(text.toLowerCase());
            }
        };
        this.text2speech.speak(speakOptions);
    };
    SpeechComponent.prototype.onSpeakRateChange = function (args) {
        var slider = args.object;
        this.speakRate = Math.floor(slider.value);
        if (this.lastTranscription) {
            this.speak(this.lastTranscription);
        }
    };
    SpeechComponent.prototype.onPitchChange = function (args) {
        var slider = args.object;
        this.pitch = Math.floor(slider.value);
        if (this.lastTranscription) {
            this.speak(this.lastTranscription);
        }
    };
    SpeechComponent.prototype.handleFollowUpAction = function (text) {
        if (text.indexOf("schedule") > -1 && text.indexOf("today") > -1) {
            this.findTodaysEvents();
        }
        else if (text.indexOf("compose") > -1 && text.indexOf("mail") > -1) {
            var subject = "";
            var body = "";
            if (text.indexOf("subject") > -1) {
                var endOfSubject = void 0;
                if (text.indexOf("an message") > -1) {
                    endOfSubject = text.indexOf("an message");
                }
                else if (text.indexOf("and message") > -1) {
                    endOfSubject = text.indexOf("and message");
                }
                else if (text.indexOf("imessage") > -1) {
                    endOfSubject = text.indexOf("imessage");
                }
                subject = text.substring(text.indexOf("subject") + 8, endOfSubject);
            }
            if (text.indexOf("message") > -1) {
                body = text.substring(text.indexOf("message") + 8);
            }
            this.composeAnEmail(subject, body);
        }
        else if (text.indexOf("share") > -1 && text.indexOf("self") > -1) {
            this.shareSelfie();
        }
        else if (text.indexOf("kilimanjaro") > -1 || text.indexOf("olympus") > -1 || text.indexOf("serengeti") > -1) {
            this.playTotoAfrica();
        }
    };
    SpeechComponent.prototype.playTotoAfrica = function () {
        var speakOptions = {
            text: "That sounds like Toto with Africa" + (platform_1.isIOS ? ', right?' : ''),
            speakRate: this.getSpeakRate(),
            pitch: this.getPitch(),
            locale: "en-US",
            finishedCallback: function () {
                var player = new nativescript_audio_1.TNSPlayer();
                player.playFromFile({
                    audioFile: "~/speech/audiofiles/toto-africa-fragment.mp3",
                    loop: false
                });
            }
        };
        this.text2speech.speak(speakOptions);
    };
    SpeechComponent.prototype.composeAnEmail = function (subject, body) {
        nativescript_email_1.available().then(function (avail) {
            if (!avail) {
                dialogs_1.alert({
                    title: "Not supported",
                    message: "There's no email client configured. Try a different device please.",
                    okButtonText: "Ah, makes sense.."
                });
                return;
            }
            nativescript_email_1.compose({
                subject: subject,
                body: body
            }).then(function (x) {
                console.log("Email result: " + x);
            });
        });
    };
    SpeechComponent.prototype.shareSelfie = function () {
        var actionOptions = [
            "Fresh pic (camera)",
            "Older pic (camera album)"
        ];
        dialogs_1.action("Do you want to take a fresh pic or select an older one?", "Cancel", actionOptions).then(function (pickedItem) {
            var pickedItemIndex = actionOptions.indexOf(pickedItem);
            if (pickedItemIndex === 0) {
                if (platform_1.isIOS) {
                    Camera.requestPermissions();
                }
                Camera.takePicture({
                    width: 1000,
                    height: 1000,
                    keepAspectRatio: true,
                    saveToGallery: false,
                    cameraFacing: "front"
                }).then(function (imageAsset) {
                    new image_source_1.ImageSource().fromAsset(imageAsset).then(function (imageSource) {
                        SocialShare.shareImage(imageSource);
                    });
                });
            }
            else if (pickedItemIndex === 1) {
                var imagePicker_1 = ImagePicker.create({
                    mode: "single",
                    newestFirst: true,
                    doneText: "Done",
                    cancelText: "Cancel"
                });
                imagePicker_1
                    .authorize()
                    .then(function () {
                    return imagePicker_1.present();
                })
                    .then(function (selection) {
                    selection.forEach(function (selected) {
                        selected.getImage({
                            maxWidth: 1000,
                            maxHeight: 1000,
                            aspectRatio: 'fit'
                        }).then(function (imageSource) {
                            SocialShare.shareImage(imageSource);
                        });
                    });
                })
                    .catch(function (e) {
                    console.log("Image Picker error: " + e);
                });
            }
        });
    };
    SpeechComponent.prototype.findTodaysEvents = function () {
        var _this = this;
        var now = new Date();
        var midnight = new Date();
        midnight.setHours(24, 0, 0, 0);
        Calendar.findEvents({
            startDate: now,
            endDate: midnight
        }).then(function (events) {
            var eventsSpoken = 0;
            events.map(function (ev) {
                if (!ev.allDay) {
                    eventsSpoken++;
                    var secondsFromNow = Math.round((ev.startDate.getTime() - new Date().getTime()) / 1000);
                    var hours = Math.floor(secondsFromNow / (60 * 60));
                    var minutes = Math.round((secondsFromNow / 60) % 60);
                    _this.text2speech.speak({
                        text: ev.title + " in " + (hours > 0 ? hours + ' hour' + (hours > 1 ? 's' : '') + ' and ' : '') + " " + minutes + " minutes",
                        speakRate: _this.getSpeakRate(),
                        pitch: _this.getPitch()
                    });
                }
            });
            if (eventsSpoken === 0) {
                _this.text2speech.speak({
                    text: "Your schedule is clear. Have a nice day.",
                    locale: "en-US",
                    speakRate: _this.getSpeakRate(),
                    pitch: _this.getPitch()
                });
            }
        }, function (error) {
            console.log("Error finding Events: " + error);
        });
    };
    SpeechComponent.prototype.getSpeakRate = function () {
        return this.speakRate / 100;
    };
    SpeechComponent.prototype.getPitch = function () {
        return this.pitch / 100;
    };
    SpeechComponent.prototype.getPluginInfo = function () {
        return new plugin_info_wrapper_1.PluginInfoWrapper("Always wanted a fully trained parrot?\n\nRecord your voice in the device language and it will be shown and read back to you.\n\nBe sure to try the tips as well!", Array.of(new plugin_info_1.PluginInfo("nativescript-texttospeech", "Text to Speech", "https://github.com/bradmartin/nativescript-texttospeech", "Make your app speak. Might be useful for disabled people 👀. Certainly useful for lazy ones."), new plugin_info_1.PluginInfo("nativescript-speech-recognition", "Speech Recognition", "https://github.com/EddyVerbruggen/nativescript-speech-recognition", "Speak to your app 👄. Useful for voice control and silly demo's 😄"), new plugin_info_1.PluginInfo("nativescript-calendar", "Calendar  🗓", "https://github.com/EddyVerbruggen/nativescript-calendar", "Create, Delete and Find Events in the native Calendar"), new plugin_info_1.PluginInfo("nativescript-email", "Email  ✉️", "https://github.com/EddyVerbruggen/nativescript-email", "Open an e-mail draft"), new plugin_info_1.PluginInfo("nativescript-social-share", "Social Share  ♻️️", "https://github.com/tjvantoll/nativescript-social-share", "Use the native sharing widget"), new plugin_info_1.PluginInfo("nativescript-audio", "Audio  🎤  🎵", "https://github.com/bradmartin/nativescript-audio", "NativeScript plugin to record and play audio"), new plugin_info_1.PluginInfo("nativescript-camera", "Camera  🎥", "https://github.com/NativeScript/nativescript-camera", "Grab pictures from the device camera"), new plugin_info_1.PluginInfo("nativescript-imagepicker", "Image Picker", "https://github.com/NativeScript/nativescript-imagepicker", "Select one or more images from the camera roll")));
    };
    SpeechComponent = __decorate([
        core_1.Component({
            selector: "page-speech",
            moduleId: module.id,
            templateUrl: "./speech.component.html",
            styleUrls: ["speech-common.css"],
            animations: [
                animations_1.trigger("from-bottom", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translateY(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translateY(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1600ms 700ms ease-out")])
                ]),
                animations_1.trigger("fade-in-1", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1100ms 2000ms ease-out")])
                ]),
                animations_1.trigger("fade-in-2", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1100ms 2500ms ease-out")])
                ]),
                animations_1.trigger("scale-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "scale(1)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "scale(0.9)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1100ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService,
            core_1.NgZone])
    ], SpeechComponent);
    return SpeechComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.SpeechComponent = SpeechComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BlZWNoLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNwZWVjaC5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUE0RTtBQUM1RSxrREFBaUY7QUFDakYsZ0ZBQTRFO0FBQzVFLHlEQUF1RDtBQUN2RCw2REFBMEQ7QUFDMUQscURBQW1EO0FBQ25ELHFFQUFrRTtBQUNsRSx1RUFBMEU7QUFDMUUsbUZBQW9HO0FBQ3BHLHVEQUE0RDtBQUM1RCx5REFBMEY7QUFDMUYsZ0RBQWtEO0FBQ2xELDRDQUE4QztBQUM5Qyx1REFBeUQ7QUFDekQsc0RBQXdEO0FBQ3hELHlEQUErQztBQUMvQyw4REFBNEQ7QUFDNUQsc0RBQWtEO0FBR2xELGlFQUFtRDtBQUVuRCxJQUFJLGVBQWUsR0FBRyxPQUFPLENBQUMsa0JBQWtCLENBQUMsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFDO0FBbUQ5RjtJQUFxQyxtQ0FBeUI7SUF1QzVELHlCQUFzQixhQUE0QixFQUM1QixLQUF1QixFQUN2QixZQUFnQyxFQUNsQyxJQUFZO1FBSGhDLFlBSUUsa0JBQU0sYUFBYSxFQUFFLEtBQUssRUFBRSxZQUFZLENBQUMsU0FNMUM7UUFWcUIsbUJBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIsV0FBSyxHQUFMLEtBQUssQ0FBa0I7UUFDdkIsa0JBQVksR0FBWixZQUFZLENBQW9CO1FBQ2xDLFVBQUksR0FBSixJQUFJLENBQVE7UUF2Q2hDLHVCQUFpQixHQUFZLEtBQUssQ0FBQztRQUNuQyxlQUFTLEdBQVksS0FBSyxDQUFDO1FBQzNCLHVCQUFpQixHQUFXLElBQUksQ0FBQztRQUNqQyxZQUFNLEdBQVksS0FBSyxDQUFDO1FBQ3hCLGlCQUFXLEdBQVksS0FBSyxDQUFDO1FBRTdCLFdBQUssR0FBVyxHQUFHLENBQUM7UUFDcEIsZUFBUyxHQUFXLGdCQUFLLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQztRQUNyQyxrQkFBWSxHQUFXLGdCQUFLLEdBQUcsR0FBRyxHQUFHLEdBQUcsQ0FBQztRQU16QyxZQUFNLEdBQUc7WUFDUCxNQUFNLEVBQUUsT0FBTztZQUVmLG9CQUFvQixFQUFFLElBQUk7WUFFMUIsUUFBUSxFQUFFLFVBQUMsYUFBNkM7Z0JBQ3RELEtBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLGNBQU0sT0FBQSxLQUFJLENBQUMsY0FBYyxHQUFHLGFBQWEsQ0FBQyxJQUFJLEVBQXhDLENBQXdDLENBQUMsQ0FBQztnQkFDOUQsS0FBSSxDQUFDLGlCQUFpQixHQUFHLGFBQWEsQ0FBQyxJQUFJLENBQUM7Z0JBRTVDLGVBQWUsQ0FBQyxTQUFTLENBQUMsb0JBQW9CLEVBQUUsS0FBSSxDQUFDLGNBQWMsQ0FBQyxLQUFJLENBQUMsaUJBQWlCLENBQUMsRUFBRSxVQUFTLEdBQUcsRUFBRSxXQUFXO29CQUNwSCxJQUFJLENBQUMsaUJBQWlCLEdBQUcsV0FBVyxDQUFDLGNBQWMsQ0FBQztnQkFDdEQsQ0FBQyxDQUFDLENBQUM7Z0JBRUgsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBQzNCLEtBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDO29CQUNuQixVQUFVLENBQUMsY0FBTSxPQUFBLEtBQUksQ0FBQyxLQUFLLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxFQUE5QixDQUE4QixFQUFFLEdBQUcsQ0FBQyxDQUFDO2dCQUN4RCxDQUFDO1lBQ0gsQ0FBQztTQUNGLENBQUE7UUFTQyxLQUFJLENBQUMsS0FBSyxHQUFHLElBQUksa0NBQVMsQ0FBUztZQUNqQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRTtZQUN0QyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRTtZQUNwQyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRTtTQUN6QyxDQUFDLENBQUM7O0lBQ0wsQ0FBQztJQUVNLHdDQUFjLEdBQXJCLFVBQXNCLElBQVk7UUFDaEMsZUFBZSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUUsVUFBUyxHQUFHLEVBQUUsU0FBUztZQUMvRCxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUU1QixDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxrQ0FBUSxHQUFmLFVBQWdCLElBQW1DO1FBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkNBQXlDLElBQUksQ0FBQyxRQUFRLFlBQU8sSUFBSSxDQUFDLFFBQVEsd0JBQW1CLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUN0SCxJQUFJLENBQUMsUUFBUSxDQUFHLENBQUMsQ0FBQztRQUN4QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVNLGdDQUFNLEdBQWI7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVNLGlDQUFPLEdBQWQ7UUFDSSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELGtDQUFRLEdBQVI7UUFBQSxpQkEwQkM7UUFmQyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksbURBQWlCLEVBQUUsQ0FBQztRQUMzQyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFBLEtBQUs7WUFDckMsS0FBSSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztRQUNsQyxDQUFDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSwyQ0FBZSxFQUFFLENBQUM7UUFFekMsVUFBVSxDQUFDO1lBQ1QsS0FBSSxDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLElBQUksQ0FBQyxVQUFDLE9BQWdCO2dCQUN6RCxLQUFJLENBQUMsaUJBQWlCLEdBQUcsT0FBTyxDQUFDO2dCQUNqQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGdCQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNYLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUM5QixDQUFDO1lBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDWCxDQUFDO0lBRUQseUNBQWUsR0FBZjtRQUNFLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ2pDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDO1lBQ25CLElBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDO1lBQ3BCLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxJQUFJLENBQUM7WUFDOUIsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNOLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQztZQUNyQixFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLElBQUksSUFBSSxDQUFDLGlCQUFpQixLQUFLLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQ3BELElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUM7WUFDckMsQ0FBQztRQUNILENBQUM7SUFDSCxDQUFDO0lBRU8sd0NBQWMsR0FBdEI7UUFDRSxFQUFFLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7WUFDN0IsZUFBSyxDQUFDO2dCQUNKLEtBQUssRUFBRSxlQUFlO2dCQUN0QixPQUFPLEVBQUUsaUZBQWlGO2dCQUMxRixZQUFZLEVBQUUsWUFBWTthQUMzQixDQUFDLENBQUM7WUFDSCxJQUFJLENBQUMsY0FBYyxHQUFHLHNCQUFzQixDQUFDO1lBQzdDLE1BQU0sQ0FBQztRQUNULENBQUM7UUFFRCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQztRQUN0QixJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxDQUM3QyxVQUFDLE9BQWdCO1lBQ2YsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ25DLENBQUMsRUFDRCxVQUFDLFlBQW9CO1lBQ25CLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBVSxZQUFjLENBQUMsQ0FBQztRQUN4QyxDQUFDLENBQ0osQ0FBQztJQUNKLENBQUM7SUFFTyx1Q0FBYSxHQUFyQjtRQUNFLElBQUksQ0FBQyxTQUFTLEdBQUcsS0FBSyxDQUFDO1FBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQ3BDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTywrQkFBSyxHQUFiLFVBQWMsSUFBWTtRQUExQixpQkFXQztRQVZDLElBQUksWUFBWSxHQUFpQjtZQUMvQixJQUFJLEVBQUUsSUFBSTtZQUNWLFNBQVMsRUFBRSxJQUFJLENBQUMsWUFBWSxFQUFFO1lBQzlCLEtBQUssRUFBRSxJQUFJLENBQUMsUUFBUSxFQUFFO1lBQ3RCLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07WUFDMUIsZ0JBQWdCLEVBQUU7Z0JBQ2hCLEtBQUksQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztZQUNoRCxDQUFDO1NBQ0YsQ0FBQztRQUNGLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFDO0lBQ3ZDLENBQUM7SUFFRCwyQ0FBaUIsR0FBakIsVUFBa0IsSUFBSTtRQUNwQixJQUFJLE1BQU0sR0FBVyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQ2pDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDMUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztZQUMzQixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1FBQ3JDLENBQUM7SUFDSCxDQUFDO0lBRUQsdUNBQWEsR0FBYixVQUFjLElBQUk7UUFDaEIsSUFBSSxNQUFNLEdBQVcsSUFBSSxDQUFDLE1BQU0sQ0FBQztRQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3RDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7WUFDM0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztRQUNyQyxDQUFDO0lBQ0gsQ0FBQztJQU1PLDhDQUFvQixHQUE1QixVQUE2QixJQUFZO1FBQ3ZDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEUsSUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUM7UUFFMUIsQ0FBQztRQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ3JFLElBQUksT0FBTyxHQUFHLEVBQUUsQ0FBQztZQUNqQixJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7WUFDZCxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakMsSUFBSSxZQUFZLFNBQVEsQ0FBQztnQkFDekIsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQ3BDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDO2dCQUM1QyxDQUFDO2dCQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDNUMsWUFBWSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUM7Z0JBQzdDLENBQUM7Z0JBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUN6QyxZQUFZLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztnQkFDMUMsQ0FBQztnQkFDRCxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztZQUN0RSxDQUFDO1lBQ0QsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2pDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDckQsQ0FBQztZQUNELElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBRXJDLENBQUM7UUFBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUNuRSxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFckIsQ0FBQztRQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFFOUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1FBQ3hCLENBQUM7SUFDSCxDQUFDO0lBRUQsd0NBQWMsR0FBZDtRQUNFLElBQUksWUFBWSxHQUFpQjtZQUMvQixJQUFJLEVBQUUsdUNBQW9DLGdCQUFLLEdBQUcsVUFBVSxHQUFHLEVBQUUsQ0FBRTtZQUNuRSxTQUFTLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRTtZQUM5QixLQUFLLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUN0QixNQUFNLEVBQUUsT0FBTztZQUNmLGdCQUFnQixFQUFFO2dCQUNoQixJQUFNLE1BQU0sR0FBRyxJQUFJLDhCQUFTLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxDQUFDLFlBQVksQ0FBQztvQkFDbEIsU0FBUyxFQUFFLDhDQUE4QztvQkFDekQsSUFBSSxFQUFFLEtBQUs7aUJBQ1osQ0FBQyxDQUFDO1lBQ0wsQ0FBQztTQUNGLENBQUM7UUFDRixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQsd0NBQWMsR0FBZCxVQUFlLE9BQWUsRUFBRSxJQUFZO1FBQzFDLDhCQUFjLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQSxLQUFLO1lBQ3pCLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztnQkFDWCxlQUFLLENBQUM7b0JBQ0osS0FBSyxFQUFFLGVBQWU7b0JBQ3RCLE9BQU8sRUFBRSxvRUFBb0U7b0JBQzdFLFlBQVksRUFBRSxtQkFBbUI7aUJBQ2xDLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUM7WUFDVCxDQUFDO1lBRUQsNEJBQVksQ0FBQztnQkFDWCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsSUFBSSxFQUFFLElBQUk7YUFDWCxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsQ0FBQztnQkFDUixPQUFPLENBQUMsR0FBRyxDQUFDLGdCQUFnQixHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ3BDLENBQUMsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQscUNBQVcsR0FBWDtRQUNFLElBQUksYUFBYSxHQUFrQjtZQUNqQyxvQkFBb0I7WUFDcEIsMEJBQTBCO1NBQzNCLENBQUM7UUFFRixnQkFBTSxDQUNGLHlEQUF5RCxFQUN6RCxRQUFRLEVBQ1IsYUFBYSxDQUNoQixDQUFDLElBQUksQ0FBQyxVQUFDLFVBQWtCO1lBQ3hCLElBQUksZUFBZSxHQUFHLGFBQWEsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDeEQsRUFBRSxDQUFDLENBQUMsZUFBZSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTFCLEVBQUUsQ0FBQyxDQUFDLGdCQUFLLENBQUMsQ0FBQyxDQUFDO29CQUNWLE1BQU0sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO2dCQUM5QixDQUFDO2dCQUVELE1BQU0sQ0FBQyxXQUFXLENBQUM7b0JBQ2pCLEtBQUssRUFBRSxJQUFJO29CQUNYLE1BQU0sRUFBRSxJQUFJO29CQUNaLGVBQWUsRUFBRSxJQUFJO29CQUNyQixhQUFhLEVBQUUsS0FBSztvQkFDcEIsWUFBWSxFQUFFLE9BQU87aUJBQ3RCLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxVQUFVO29CQUNoQixJQUFJLDBCQUFXLEVBQUUsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUEsV0FBVzt3QkFDdEQsV0FBVyxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsQ0FBQztvQkFDdEMsQ0FBQyxDQUFDLENBQUM7Z0JBQ0wsQ0FBQyxDQUFDLENBQUM7WUFDTCxDQUFDO1lBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDLGVBQWUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVqQyxJQUFNLGFBQVcsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDO29CQUNyQyxJQUFJLEVBQUUsUUFBUTtvQkFDZCxXQUFXLEVBQUUsSUFBSTtvQkFDakIsUUFBUSxFQUFFLE1BQU07b0JBQ2hCLFVBQVUsRUFBRSxRQUFRO2lCQUNyQixDQUFDLENBQUM7Z0JBQ0gsYUFBVztxQkFDTixTQUFTLEVBQUU7cUJBQ1gsSUFBSSxDQUFDO29CQUNKLE1BQU0sQ0FBQyxhQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQy9CLENBQUMsQ0FBQztxQkFDRCxJQUFJLENBQUMsVUFBQyxTQUFtRjtvQkFDeEYsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFBLFFBQVE7d0JBQ3hCLFFBQVEsQ0FBQyxRQUFRLENBQUM7NEJBQ2hCLFFBQVEsRUFBRSxJQUFJOzRCQUNkLFNBQVMsRUFBRSxJQUFJOzRCQUNmLFdBQVcsRUFBRSxLQUFLO3lCQUNuQixDQUFDLENBQUMsSUFBSSxDQUFDLFVBQUMsV0FBd0I7NEJBQy9CLFdBQVcsQ0FBQyxVQUFVLENBQUMsV0FBVyxDQUFDLENBQUM7d0JBQ3RDLENBQUMsQ0FBQyxDQUFDO29CQUNMLENBQUMsQ0FBQyxDQUFDO2dCQUNMLENBQUMsQ0FBQztxQkFDRCxLQUFLLENBQUMsVUFBQSxDQUFDO29CQUNOLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXVCLENBQUcsQ0FBQyxDQUFDO2dCQUMxQyxDQUFDLENBQUMsQ0FBQztZQUNULENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUVMLENBQUM7SUFFRCwwQ0FBZ0IsR0FBaEI7UUFBQSxpQkFvQ0M7UUFuQ0MsSUFBSSxHQUFHLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQztRQUNyQixJQUFJLFFBQVEsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDO1FBQzFCLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDL0IsUUFBUSxDQUFDLFVBQVUsQ0FBQztZQUNsQixTQUFTLEVBQUUsR0FBRztZQUNkLE9BQU8sRUFBRSxRQUFRO1NBQ2xCLENBQUMsQ0FBQyxJQUFJLENBQ0gsVUFBQSxNQUFNO1lBQ0osSUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3JCLE1BQU0sQ0FBQyxHQUFHLENBQUMsVUFBQSxFQUFFO2dCQUNYLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7b0JBQ2YsWUFBWSxFQUFFLENBQUM7b0JBQ2YsSUFBSSxjQUFjLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsT0FBTyxFQUFFLEdBQUcsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDO29CQUN4RixJQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO29CQUNuRCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsY0FBYyxHQUFHLEVBQUUsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUNyRCxLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzt3QkFDckIsSUFBSSxFQUFLLEVBQUUsQ0FBQyxLQUFLLGFBQU8sS0FBSyxHQUFHLENBQUMsR0FBRyxLQUFLLEdBQUcsT0FBTyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDLEdBQUcsT0FBTyxHQUFHLEVBQUUsVUFBSSxPQUFPLGFBQVU7d0JBQ2hILFNBQVMsRUFBRSxLQUFJLENBQUMsWUFBWSxFQUFFO3dCQUM5QixLQUFLLEVBQUUsS0FBSSxDQUFDLFFBQVEsRUFBRTtxQkFDdkIsQ0FBQyxDQUFDO2dCQUNMLENBQUM7WUFDSCxDQUFDLENBQUMsQ0FBQztZQUNILEVBQUUsQ0FBQyxDQUFDLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUN2QixLQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztvQkFDckIsSUFBSSxFQUFFLDBDQUEwQztvQkFDaEQsTUFBTSxFQUFFLE9BQU87b0JBQ2YsU0FBUyxFQUFFLEtBQUksQ0FBQyxZQUFZLEVBQUU7b0JBQzlCLEtBQUssRUFBRSxLQUFJLENBQUMsUUFBUSxFQUFFO2lCQUN2QixDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQyxFQUNELFVBQVUsS0FBSztZQUNiLE9BQU8sQ0FBQyxHQUFHLENBQUMsMkJBQXlCLEtBQU8sQ0FBQyxDQUFDO1FBQ2hELENBQUMsQ0FDSixDQUFDO0lBQ0osQ0FBQztJQUVPLHNDQUFZLEdBQXBCO1FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDO0lBQzlCLENBQUM7SUFFTyxrQ0FBUSxHQUFoQjtRQUNFLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztJQUMxQixDQUFDO0lBRVMsdUNBQWEsR0FBdkI7UUFDRSxNQUFNLENBQUMsSUFBSSx1Q0FBaUIsQ0FDeEIsa0tBQWtLLEVBQ2xLLEtBQUssQ0FBQyxFQUFFLENBQ0osSUFBSSx3QkFBVSxDQUNWLDJCQUEyQixFQUMzQixnQkFBZ0IsRUFDaEIseURBQXlELEVBQ3pELDhGQUE4RixDQUNqRyxFQUVELElBQUksd0JBQVUsQ0FDVixpQ0FBaUMsRUFDakMsb0JBQW9CLEVBQ3BCLG1FQUFtRSxFQUNuRSxvRUFBb0UsQ0FDdkUsRUFFRCxJQUFJLHdCQUFVLENBQ1YsdUJBQXVCLEVBQ3ZCLGNBQWMsRUFDZCx5REFBeUQsRUFDekQsdURBQXVELENBQzFELEVBRUQsSUFBSSx3QkFBVSxDQUNWLG9CQUFvQixFQUNwQixXQUFXLEVBQ1gsc0RBQXNELEVBQ3RELHNCQUFzQixDQUN6QixFQUVELElBQUksd0JBQVUsQ0FDViwyQkFBMkIsRUFDM0IsbUJBQW1CLEVBQ25CLHdEQUF3RCxFQUN4RCwrQkFBK0IsQ0FDbEMsRUFFRCxJQUFJLHdCQUFVLENBQ1Ysb0JBQW9CLEVBQ3BCLGVBQWUsRUFDZixrREFBa0QsRUFDbEQsOENBQThDLENBQ2pELEVBRUQsSUFBSSx3QkFBVSxDQUNWLHFCQUFxQixFQUNyQixZQUFZLEVBQ1oscURBQXFELEVBQ3JELHNDQUFzQyxDQUN6QyxFQUVELElBQUksd0JBQVUsQ0FDViwwQkFBMEIsRUFDMUIsY0FBYyxFQUNkLDBEQUEwRCxFQUMxRCxnREFBZ0QsQ0FDbkQsQ0FDSixDQUNKLENBQUM7SUFDSixDQUFDO0lBN1pVLGVBQWU7UUFoRDNCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsYUFBYTtZQUN2QixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QyxTQUFTLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQztZQUNoQyxVQUFVLEVBQUU7Z0JBQ1Ysb0JBQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQ3JCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxlQUFlO3FCQUMzQixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLGlCQUFpQjtxQkFDN0IsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7aUJBQzVELENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxXQUFXLEVBQUU7b0JBQ25CLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3FCQUNiLENBQUMsQ0FBQztvQkFDSCxrQkFBSyxDQUFDLE1BQU0sRUFBRSxrQkFBSyxDQUFDO3dCQUNsQixTQUFTLEVBQUUsQ0FBQztxQkFDYixDQUFDLENBQUM7b0JBQ0gsdUJBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxvQkFBTyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQztpQkFDN0QsQ0FBQztnQkFDRixvQkFBTyxDQUFDLFdBQVcsRUFBRTtvQkFDbkIsa0JBQUssQ0FBQyxJQUFJLEVBQUUsa0JBQUssQ0FBQzt3QkFDaEIsU0FBUyxFQUFFLENBQUM7cUJBQ2IsQ0FBQyxDQUFDO29CQUNILGtCQUFLLENBQUMsTUFBTSxFQUFFLGtCQUFLLENBQUM7d0JBQ2xCLFNBQVMsRUFBRSxDQUFDO3FCQUNiLENBQUMsQ0FBQztvQkFDSCx1QkFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDLG9CQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO2lCQUM3RCxDQUFDO2dCQUNGLG9CQUFPLENBQUMsVUFBVSxFQUFFO29CQUNsQixrQkFBSyxDQUFDLElBQUksRUFBRSxrQkFBSyxDQUFDO3dCQUNoQixTQUFTLEVBQUUsQ0FBQzt3QkFDWixTQUFTLEVBQUUsVUFBVTtxQkFDdEIsQ0FBQyxDQUFDO29CQUNILGtCQUFLLENBQUMsTUFBTSxFQUFFLGtCQUFLLENBQUM7d0JBQ2xCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxZQUFZO3FCQUN4QixDQUFDLENBQUM7b0JBQ0gsdUJBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxvQkFBTyxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQztpQkFDdEQsQ0FBQzthQUNIO1NBQ0YsQ0FBQzt5Q0F3Q3FDLDhCQUFhO1lBQ3JCLHVCQUFnQjtZQUNULHlDQUFrQjtZQUM1QixhQUFNO09BMUNyQixlQUFlLENBOFozQjtJQUFELHNCQUFDO0NBQUEsQUE5WkQsQ0FBcUMsd0RBQXlCLEdBOFo3RDtBQTlaWSwwQ0FBZSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgTmdab25lLCBPbkluaXQsIFZpZXdDb250YWluZXJSZWYgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBhbmltYXRlLCBzdGF0ZSwgc3R5bGUsIHRyYW5zaXRpb24sIHRyaWdnZXIgfSBmcm9tIFwiQGFuZ3VsYXIvYW5pbWF0aW9uc1wiO1xyXG5pbXBvcnQgeyBBYnN0cmFjdE1lbnVQYWdlQ29tcG9uZW50IH0gZnJvbSBcIi4uL2Fic3RyYWN0LW1lbnUtcGFnZS1jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgTWVudUNvbXBvbmVudCB9IGZyb20gXCIuLi9tZW51L21lbnUuY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IE1vZGFsRGlhbG9nU2VydmljZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhclwiO1xyXG5pbXBvcnQgeyBQbHVnaW5JbmZvIH0gZnJvbSBcIi4uL3NoYXJlZC9wbHVnaW4taW5mb1wiO1xyXG5pbXBvcnQgeyBQbHVnaW5JbmZvV3JhcHBlciB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm8td3JhcHBlclwiO1xyXG5pbXBvcnQgeyBTcGVha09wdGlvbnMsIFROU1RleHRUb1NwZWVjaCB9IGZyb20gXCJuYXRpdmVzY3JpcHQtdGV4dHRvc3BlZWNoXCI7XHJcbmltcG9ydCB7IFNwZWVjaFJlY29nbml0aW9uLCBTcGVlY2hSZWNvZ25pdGlvblRyYW5zY3JpcHRpb24gfSBmcm9tIFwibmF0aXZlc2NyaXB0LXNwZWVjaC1yZWNvZ25pdGlvblwiO1xyXG5pbXBvcnQgeyBhbGVydCwgYWN0aW9uIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdWkvZGlhbG9nc1wiO1xyXG5pbXBvcnQgeyBhdmFpbGFibGUgYXMgZW1haWxBdmFpbGFibGUsIGNvbXBvc2UgYXMgY29tcG9zZUVtYWlsIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1lbWFpbFwiO1xyXG5pbXBvcnQgKiBhcyBDYWxlbmRhciBmcm9tIFwibmF0aXZlc2NyaXB0LWNhbGVuZGFyXCI7XHJcbmltcG9ydCAqIGFzIENhbWVyYSBmcm9tIFwibmF0aXZlc2NyaXB0LWNhbWVyYVwiO1xyXG5pbXBvcnQgKiBhcyBTb2NpYWxTaGFyZSBmcm9tIFwibmF0aXZlc2NyaXB0LXNvY2lhbC1zaGFyZVwiO1xyXG5pbXBvcnQgKiBhcyBJbWFnZVBpY2tlciBmcm9tIFwibmF0aXZlc2NyaXB0LWltYWdlcGlja2VyXCI7XHJcbmltcG9ydCB7IFROU1BsYXllciB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYXVkaW9cIjtcclxuaW1wb3J0IHsgSW1hZ2VTb3VyY2UgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9pbWFnZS1zb3VyY2VcIjtcclxuaW1wb3J0IHsgaXNJT1MgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy9wbGF0Zm9ybVwiO1xyXG5pbXBvcnQgeyBTbGlkZXIgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9zbGlkZXJcIjtcclxuaW1wb3J0IHsgU2VsZWN0ZWRJbmRleENoYW5nZWRFdmVudERhdGEgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWRyb3AtZG93blwiO1xyXG5pbXBvcnQgeyBWYWx1ZUxpc3QgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWRyb3AtZG93blwiO1xyXG5cclxudmFyIGdvb2dsZVRyYW5zbGF0ZSA9IHJlcXVpcmUoJ2dvb2dsZS10cmFuc2xhdGUnKShcIjY5NmQ4ZjZlODZmMDllMTUyNWMwNzM0YzRiNDFiMWNiZDdiMmJkY2RcIik7XHJcblxyXG5cclxuQENvbXBvbmVudCh7XHJcbiAgc2VsZWN0b3I6IFwicGFnZS1zcGVlY2hcIixcclxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vc3BlZWNoLmNvbXBvbmVudC5odG1sXCIsXHJcbiAgc3R5bGVVcmxzOiBbXCJzcGVlY2gtY29tbW9uLmNzc1wiXSxcclxuICBhbmltYXRpb25zOiBbXHJcbiAgICB0cmlnZ2VyKFwiZnJvbS1ib3R0b21cIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWSgwKVwiXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMCxcclxuICAgICAgICB0cmFuc2Zvcm06IFwidHJhbnNsYXRlWSgyMCUpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiMTYwMG1zIDcwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcImZhZGUtaW4tMVwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAxXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMFxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCIxMTAwbXMgMjAwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcImZhZGUtaW4tMlwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAxXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMFxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCIxMTAwbXMgMjUwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pLFxyXG4gICAgdHJpZ2dlcihcInNjYWxlLWluXCIsIFtcclxuICAgICAgc3RhdGUoXCJpblwiLCBzdHlsZSh7XHJcbiAgICAgICAgXCJvcGFjaXR5XCI6IDEsXHJcbiAgICAgICAgdHJhbnNmb3JtOiBcInNjYWxlKDEpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJzY2FsZSgwLjkpXCJcclxuICAgICAgfSkpLFxyXG4gICAgICB0cmFuc2l0aW9uKFwidm9pZCA9PiAqXCIsIFthbmltYXRlKFwiMTEwMG1zIGVhc2Utb3V0XCIpXSlcclxuICAgIF0pXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgU3BlZWNoQ29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RNZW51UGFnZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgcHJpdmF0ZSB0ZXh0MnNwZWVjaDogVE5TVGV4dFRvU3BlZWNoO1xyXG4gIHByaXZhdGUgc3BlZWNoMnRleHQ6IFNwZWVjaFJlY29nbml0aW9uO1xyXG4gIG1pY3JvcGhvbmVFbmFibGVkOiBib29sZWFuID0gZmFsc2U7XHJcbiAgcmVjb3JkaW5nOiBib29sZWFuID0gZmFsc2U7XHJcbiAgbGFzdFRyYW5zY3JpcHRpb246IHN0cmluZyA9IG51bGw7XHJcbiAgc3Bva2VuOiBib29sZWFuID0gZmFsc2U7XHJcbiAgc2hvd2luZ1RpcHM6IGJvb2xlYW4gPSBmYWxzZTtcclxuICByZWNvZ25pemVkVGV4dDogc3RyaW5nO1xyXG4gIHBpdGNoOiBudW1iZXIgPSAxMDA7XHJcbiAgc3BlYWtSYXRlOiBudW1iZXIgPSBpc0lPUyA/IDUwIDogMTAwO1xyXG4gIG1heFNwZWFrUmF0ZTogbnVtYmVyID0gaXNJT1MgPyAxMDAgOiAyMDA7XHJcbiAgcHJpdmF0ZSByZWNvcmRpbmdBdmFpbGFibGU6IGJvb2xlYW47XHJcbiAgcHVibGljIGl0ZW1zOiBWYWx1ZUxpc3Q8c3RyaW5nPjtcclxuXHJcblxyXG5cclxuICBjb25maWcgPSB7XHJcbiAgICBsb2NhbGU6IFwiZW4tSU5cIiwgLy8gb3B0aW9uYWwsIHVzZXMgdGhlIGRldmljZSBsb2NhbGUgYnkgZGVmYXVsdFxyXG4gICAgLy8gc2V0IHRvIHRydWUgdG8gZ2V0IHJlc3VsdHMgYmFjayBjb250aW51b3VzbHlcclxuICAgIHJldHVyblBhcnRpYWxSZXN1bHRzOiB0cnVlLFxyXG4gICAgLy8gdGhpcyBjYWxsYmFjayB3aWxsIGJlIGludm9rZWQgcmVwZWF0ZWRseSBkdXJpbmcgcmVjb2duaXRpb25cclxuICAgIG9uUmVzdWx0OiAodHJhbnNjcmlwdGlvbjogU3BlZWNoUmVjb2duaXRpb25UcmFuc2NyaXB0aW9uKSA9PiB7XHJcbiAgICAgIHRoaXMuem9uZS5ydW4oKCkgPT4gdGhpcy5yZWNvZ25pemVkVGV4dCA9IHRyYW5zY3JpcHRpb24udGV4dCk7XHJcbiAgICAgIHRoaXMubGFzdFRyYW5zY3JpcHRpb24gPSB0cmFuc2NyaXB0aW9uLnRleHQ7XHJcblxyXG4gICAgICBnb29nbGVUcmFuc2xhdGUudHJhbnNsYXRlKCdNeSBuYW1lIGlzIEJyYW5kb24nLCB0aGlzLmRldGVjdExhbmd1YWdlKHRoaXMubGFzdFRyYW5zY3JpcHRpb24pLCBmdW5jdGlvbihlcnIsIHRyYW5zbGF0aW9uKSB7XHJcbiAgICAgICAgdGhpcy5sYXN0VHJhbnNjcmlwdGlvbiA9IHRyYW5zbGF0aW9uLnRyYW5zbGF0ZWRUZXh0O1xyXG4gICAgICB9KTtcclxuXHJcbiAgICAgIGlmICh0cmFuc2NyaXB0aW9uLmZpbmlzaGVkKSB7XHJcbiAgICAgICAgdGhpcy5zcG9rZW4gPSB0cnVlO1xyXG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4gdGhpcy5zcGVhayh0cmFuc2NyaXB0aW9uLnRleHQpLCAzMDApO1xyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gIH1cclxuXHJcbiAgLy8gQFZpZXdDaGlsZChcInJlY29yZEJ1dHRvblwiKSByZWNvcmRCdXR0b246IEVsZW1lbnRSZWY7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBtZW51Q29tcG9uZW50OiBNZW51Q29tcG9uZW50LFxyXG4gICAgICAgICAgICAgIHByb3RlY3RlZCB2Y1JlZjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgbW9kYWxTZXJ2aWNlOiBNb2RhbERpYWxvZ1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgcHJpdmF0ZSB6b25lOiBOZ1pvbmUpIHtcclxuICAgIHN1cGVyKG1lbnVDb21wb25lbnQsIHZjUmVmLCBtb2RhbFNlcnZpY2UpO1xyXG4gICAgdGhpcy5pdGVtcyA9IG5ldyBWYWx1ZUxpc3Q8c3RyaW5nPihbXHJcbiAgICAgIHsgdmFsdWU6IFwiZW4tSU5cIiwgZGlzcGxheTogXCJFbmdsaXNoXCIgfSwgXHJcbiAgICAgIHsgdmFsdWU6IFwiaGktSU5cIiwgZGlzcGxheTogXCJIaW5kaVwiIH0sXHJcbiAgICAgIHsgdmFsdWU6IFwibWwtSU5cIiwgZGlzcGxheTogXCJNYWxheWFsYW1cIiB9XHJcbiAgICBdKTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBkZXRlY3RMYW5ndWFnZSh0ZXh0OiBTdHJpbmcpe1xyXG4gICAgZ29vZ2xlVHJhbnNsYXRlLmRldGVjdExhbmd1YWdlKCdHcmFjaWFzJywgZnVuY3Rpb24oZXJyLCBkZXRlY3Rpb24pIHtcclxuICAgICAgcmV0dXJuIGRldGVjdGlvbi5sYW5ndWFnZTtcclxuICAgICAgLy8gPT4gIGVzXHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBvbmNoYW5nZShhcmdzOiBTZWxlY3RlZEluZGV4Q2hhbmdlZEV2ZW50RGF0YSkge1xyXG4gICAgICBjb25zb2xlLmxvZyhgRHJvcCBEb3duIHNlbGVjdGVkIGluZGV4IGNoYW5nZWQgZnJvbSAke2FyZ3Mub2xkSW5kZXh9IHRvICR7YXJncy5uZXdJbmRleH0uICBOZXcgdmFsdWUgaXMgJHt0aGlzLml0ZW1zLmdldFZhbHVlKFxyXG4gICAgICAgICAgICBhcmdzLm5ld0luZGV4KX1gKTtcclxuICAgICAgdGhpcy5jb25maWcubG9jYWxlID0gdGhpcy5pdGVtcy5nZXRWYWx1ZShhcmdzLm5ld0luZGV4KTtcclxuICB9XHJcblxyXG4gIHB1YmxpYyBvbm9wZW4oKSB7XHJcbiAgICAgIGNvbnNvbGUubG9nKFwiRHJvcCBEb3duIG9wZW5lZC5cIik7XHJcbiAgfVxyXG5cclxuICBwdWJsaWMgb25jbG9zZSgpIHtcclxuICAgICAgY29uc29sZS5sb2coXCJEcm9wIERvd24gY2xvc2VkLlwiKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gICAgLy8gdGhpcyBjcmVhdGVzIGEgdG91Y2ggJiBob2xkIGdlc3R1cmUgZm9yIHRoZSBtaWNyb3Bob25lIGJ1dHRvblxyXG4gICAgLy8gY29uc3QgcmVjb3JkQnV0dG9uOiBMYWJlbCA9IHRoaXMucmVjb3JkQnV0dG9uLm5hdGl2ZUVsZW1lbnQ7XHJcbiAgICAvLyByZWNvcmRCdXR0b24ub24oXCJ0YXBcIiwgKGFyZ3M6IEdlc3R1cmVFdmVudERhdGEpID0+IHtcclxuICAgIC8vICAgaWYgKGFyZ3NbXCJhY3Rpb25cIl0gPT09IFwiZG93blwiKSB7XHJcbiAgICAvLyAgICAgdGhpcy56b25lLnJ1bigoKSA9PiB0aGlzLnN0YXJ0TGlzdGVuaW5nKCkpO1xyXG4gICAgLy8gICB9IGVsc2UgaWYgKGFyZ3NbXCJhY3Rpb25cIl0gPT09IFwidXBcIikge1xyXG4gICAgLy8gICAgIHRoaXMuem9uZS5ydW4oKCkgPT4gdGhpcy5zdG9wTGlzdGVuaW5nKCkpO1xyXG4gICAgLy8gICB9XHJcbiAgICAvLyB9KTtcclxuXHJcbiAgICB0aGlzLnNwZWVjaDJ0ZXh0ID0gbmV3IFNwZWVjaFJlY29nbml0aW9uKCk7XHJcbiAgICB0aGlzLnNwZWVjaDJ0ZXh0LmF2YWlsYWJsZSgpLnRoZW4oYXZhaWwgPT4ge1xyXG4gICAgICB0aGlzLnJlY29yZGluZ0F2YWlsYWJsZSA9IGF2YWlsO1xyXG4gICAgfSk7XHJcblxyXG4gICAgdGhpcy50ZXh0MnNwZWVjaCA9IG5ldyBUTlNUZXh0VG9TcGVlY2goKTtcclxuXHJcbiAgICBzZXRUaW1lb3V0KCgpID0+IHtcclxuICAgICAgdGhpcy5zcGVlY2gydGV4dC5yZXF1ZXN0UGVybWlzc2lvbigpLnRoZW4oKGdyYW50ZWQ6IGJvb2xlYW4pID0+IHtcclxuICAgICAgICB0aGlzLm1pY3JvcGhvbmVFbmFibGVkID0gZ3JhbnRlZDtcclxuICAgICAgICBpZiAoIWlzSU9TKSB7XHJcbiAgICAgICAgICBDYW1lcmEucmVxdWVzdFBlcm1pc3Npb25zKCk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuICAgIH0sIDEwMDApO1xyXG4gIH1cclxuXHJcbiAgdG9nZ2xlUmVjb3JkaW5nKCk6IHZvaWQge1xyXG4gICAgdGhpcy5yZWNvcmRpbmcgPSAhdGhpcy5yZWNvcmRpbmc7XHJcbiAgICBpZiAodGhpcy5yZWNvcmRpbmcpIHtcclxuICAgICAgdGhpcy5zcG9rZW4gPSBmYWxzZTtcclxuICAgICAgdGhpcy5sYXN0VHJhbnNjcmlwdGlvbiA9IG51bGw7XHJcbiAgICAgIHRoaXMuc3RhcnRMaXN0ZW5pbmcoKTtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHRoaXMuc3RvcExpc3RlbmluZygpO1xyXG4gICAgICBpZiAoIXRoaXMuc3Bva2VuICYmIHRoaXMubGFzdFRyYW5zY3JpcHRpb24gIT09IG51bGwpIHtcclxuICAgICAgICB0aGlzLnNwZWFrKHRoaXMubGFzdFRyYW5zY3JpcHRpb24pO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHN0YXJ0TGlzdGVuaW5nKCk6IHZvaWQge1xyXG4gICAgaWYgKCF0aGlzLnJlY29yZGluZ0F2YWlsYWJsZSkge1xyXG4gICAgICBhbGVydCh7XHJcbiAgICAgICAgdGl0bGU6IFwiTm90IHN1cHBvcnRlZFwiLFxyXG4gICAgICAgIG1lc3NhZ2U6IFwiU3BlZWNoIHJlY29nbml0aW9uIG5vdCBzdXBwb3J0ZWQgb24gdGhpcyBkZXZpY2UuIFRyeSBhIGRpZmZlcmVudCBkZXZpY2UgcGxlYXNlLlwiLFxyXG4gICAgICAgIG9rQnV0dG9uVGV4dDogXCJPaCwgYnVtbWVyXCJcclxuICAgICAgfSk7XHJcbiAgICAgIHRoaXMucmVjb2duaXplZFRleHQgPSBcIk5vIHN1cHBvcnQsIHNvcnJ5IOKYue+4j1wiO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5yZWNvcmRpbmcgPSB0cnVlO1xyXG4gICAgdGhpcy5zcGVlY2gydGV4dC5zdGFydExpc3RlbmluZyh0aGlzLmNvbmZpZykudGhlbihcclxuICAgICAgICAoc3RhcnRlZDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coXCJzdGFydGVkIGxpc3RlbmluZ1wiKTtcclxuICAgICAgICB9LFxyXG4gICAgICAgIChlcnJvck1lc3NhZ2U6IHN0cmluZykgPT4ge1xyXG4gICAgICAgICAgY29uc29sZS5sb2coYEVycm9yOiAke2Vycm9yTWVzc2FnZX1gKTtcclxuICAgICAgICB9XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBzdG9wTGlzdGVuaW5nKCk6IHZvaWQge1xyXG4gICAgdGhpcy5yZWNvcmRpbmcgPSBmYWxzZTtcclxuICAgIHRoaXMuc3BlZWNoMnRleHQuc3RvcExpc3RlbmluZygpLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIlN0b3BwZWQgbGlzdGVuaW5nXCIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcml2YXRlIHNwZWFrKHRleHQ6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgbGV0IHNwZWFrT3B0aW9uczogU3BlYWtPcHRpb25zID0ge1xyXG4gICAgICB0ZXh0OiB0ZXh0LFxyXG4gICAgICBzcGVha1JhdGU6IHRoaXMuZ2V0U3BlYWtSYXRlKCksXHJcbiAgICAgIHBpdGNoOiB0aGlzLmdldFBpdGNoKCksXHJcbiAgICAgIGxvY2FsZTogdGhpcy5jb25maWcubG9jYWxlLCAvLyBvcHRpb25hbCwgdXNlcyB0aGUgZGV2aWNlIGxvY2FsZSBieSBkZWZhdWx0XHJcbiAgICAgIGZpbmlzaGVkQ2FsbGJhY2s6ICgpID0+IHtcclxuICAgICAgICB0aGlzLmhhbmRsZUZvbGxvd1VwQWN0aW9uKHRleHQudG9Mb3dlckNhc2UoKSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICB0aGlzLnRleHQyc3BlZWNoLnNwZWFrKHNwZWFrT3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICBvblNwZWFrUmF0ZUNoYW5nZShhcmdzKTogdm9pZCB7XHJcbiAgICBsZXQgc2xpZGVyID0gPFNsaWRlcj5hcmdzLm9iamVjdDtcclxuICAgIHRoaXMuc3BlYWtSYXRlID0gTWF0aC5mbG9vcihzbGlkZXIudmFsdWUpO1xyXG4gICAgaWYgKHRoaXMubGFzdFRyYW5zY3JpcHRpb24pIHtcclxuICAgICAgdGhpcy5zcGVhayh0aGlzLmxhc3RUcmFuc2NyaXB0aW9uKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIG9uUGl0Y2hDaGFuZ2UoYXJncyk6IHZvaWQge1xyXG4gICAgbGV0IHNsaWRlciA9IDxTbGlkZXI+YXJncy5vYmplY3Q7XHJcbiAgICB0aGlzLnBpdGNoID0gTWF0aC5mbG9vcihzbGlkZXIudmFsdWUpO1xyXG4gICAgaWYgKHRoaXMubGFzdFRyYW5zY3JpcHRpb24pIHtcclxuICAgICAgdGhpcy5zcGVhayh0aGlzLmxhc3RUcmFuc2NyaXB0aW9uKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFBvb3IgbWFuJ3MgU2lyaSA6KVxyXG4gICAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0IChsb3dlcmNhc2UpXHJcbiAgICovXHJcbiAgcHJpdmF0ZSBoYW5kbGVGb2xsb3dVcEFjdGlvbih0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcclxuICAgIGlmICh0ZXh0LmluZGV4T2YoXCJzY2hlZHVsZVwiKSA+IC0xICYmIHRleHQuaW5kZXhPZihcInRvZGF5XCIpID4gLTEpIHtcclxuICAgICAgdGhpcy5maW5kVG9kYXlzRXZlbnRzKCk7XHJcblxyXG4gICAgfSBlbHNlIGlmICh0ZXh0LmluZGV4T2YoXCJjb21wb3NlXCIpID4gLTEgJiYgdGV4dC5pbmRleE9mKFwibWFpbFwiKSA+IC0xKSB7XHJcbiAgICAgIGxldCBzdWJqZWN0ID0gXCJcIjtcclxuICAgICAgbGV0IGJvZHkgPSBcIlwiO1xyXG4gICAgICBpZiAodGV4dC5pbmRleE9mKFwic3ViamVjdFwiKSA+IC0xKSB7XHJcbiAgICAgICAgbGV0IGVuZE9mU3ViamVjdDogbnVtYmVyO1xyXG4gICAgICAgIGlmICh0ZXh0LmluZGV4T2YoXCJhbiBtZXNzYWdlXCIpID4gLTEpIHtcclxuICAgICAgICAgIGVuZE9mU3ViamVjdCA9IHRleHQuaW5kZXhPZihcImFuIG1lc3NhZ2VcIik7XHJcbiAgICAgICAgfSBlbHNlIGlmICh0ZXh0LmluZGV4T2YoXCJhbmQgbWVzc2FnZVwiKSA+IC0xKSB7XHJcbiAgICAgICAgICBlbmRPZlN1YmplY3QgPSB0ZXh0LmluZGV4T2YoXCJhbmQgbWVzc2FnZVwiKTtcclxuICAgICAgICB9IGVsc2UgaWYgKHRleHQuaW5kZXhPZihcImltZXNzYWdlXCIpID4gLTEpIHtcclxuICAgICAgICAgIGVuZE9mU3ViamVjdCA9IHRleHQuaW5kZXhPZihcImltZXNzYWdlXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBzdWJqZWN0ID0gdGV4dC5zdWJzdHJpbmcodGV4dC5pbmRleE9mKFwic3ViamVjdFwiKSArIDgsIGVuZE9mU3ViamVjdCk7XHJcbiAgICAgIH1cclxuICAgICAgaWYgKHRleHQuaW5kZXhPZihcIm1lc3NhZ2VcIikgPiAtMSkge1xyXG4gICAgICAgIGJvZHkgPSB0ZXh0LnN1YnN0cmluZyh0ZXh0LmluZGV4T2YoXCJtZXNzYWdlXCIpICsgOCk7XHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5jb21wb3NlQW5FbWFpbChzdWJqZWN0LCBib2R5KTtcclxuXHJcbiAgICB9IGVsc2UgaWYgKHRleHQuaW5kZXhPZihcInNoYXJlXCIpID4gLTEgJiYgdGV4dC5pbmRleE9mKFwic2VsZlwiKSA+IC0xKSB7XHJcbiAgICAgIHRoaXMuc2hhcmVTZWxmaWUoKTtcclxuXHJcbiAgICB9IGVsc2UgaWYgKHRleHQuaW5kZXhPZihcImtpbGltYW5qYXJvXCIpID4gLTEgfHwgdGV4dC5pbmRleE9mKFwib2x5bXB1c1wiKSA+IC0xIHx8IHRleHQuaW5kZXhPZihcInNlcmVuZ2V0aVwiKSA+IC0xKSB7XHJcbiAgICAgIC8vICh2ZXJ5KSBsb29zZWx5IG1hdGNoaW5nIHRoZSBzZW50ZW5jZSBcImFzIHN1cmUgYXMga2lsaW1hbm5qYXJvIHJpc2VzIGxpa2Ugb2x5bXB1cyBhYm92ZSB0aGUgc2VyZW5nZXRpXCIgOilcclxuICAgICAgdGhpcy5wbGF5VG90b0FmcmljYSgpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcGxheVRvdG9BZnJpY2EoKTogdm9pZCB7XHJcbiAgICBsZXQgc3BlYWtPcHRpb25zOiBTcGVha09wdGlvbnMgPSB7XHJcbiAgICAgIHRleHQ6IGBUaGF0IHNvdW5kcyBsaWtlIFRvdG8gd2l0aCBBZnJpY2Eke2lzSU9TID8gJywgcmlnaHQ/JyA6ICcnfWAsIC8vIGxhc3QgYml0IHNvdW5kcyB3ZWlyZCBvbiBBbmRyb2lkXHJcbiAgICAgIHNwZWFrUmF0ZTogdGhpcy5nZXRTcGVha1JhdGUoKSxcclxuICAgICAgcGl0Y2g6IHRoaXMuZ2V0UGl0Y2goKSxcclxuICAgICAgbG9jYWxlOiBcImVuLVVTXCIsXHJcbiAgICAgIGZpbmlzaGVkQ2FsbGJhY2s6ICgpID0+IHtcclxuICAgICAgICBjb25zdCBwbGF5ZXIgPSBuZXcgVE5TUGxheWVyKCk7XHJcbiAgICAgICAgcGxheWVyLnBsYXlGcm9tRmlsZSh7XHJcbiAgICAgICAgICBhdWRpb0ZpbGU6IFwifi9zcGVlY2gvYXVkaW9maWxlcy90b3RvLWFmcmljYS1mcmFnbWVudC5tcDNcIiwgLy8gfiA9IGFwcCBkaXJlY3RvcnlcclxuICAgICAgICAgIGxvb3A6IGZhbHNlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcbiAgICB0aGlzLnRleHQyc3BlZWNoLnNwZWFrKHNwZWFrT3B0aW9ucyk7XHJcbiAgfVxyXG5cclxuICBjb21wb3NlQW5FbWFpbChzdWJqZWN0OiBzdHJpbmcsIGJvZHk6IHN0cmluZyk6IHZvaWQge1xyXG4gICAgZW1haWxBdmFpbGFibGUoKS50aGVuKGF2YWlsID0+IHtcclxuICAgICAgaWYgKCFhdmFpbCkge1xyXG4gICAgICAgIGFsZXJ0KHtcclxuICAgICAgICAgIHRpdGxlOiBcIk5vdCBzdXBwb3J0ZWRcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiVGhlcmUncyBubyBlbWFpbCBjbGllbnQgY29uZmlndXJlZC4gVHJ5IGEgZGlmZmVyZW50IGRldmljZSBwbGVhc2UuXCIsXHJcbiAgICAgICAgICBva0J1dHRvblRleHQ6IFwiQWgsIG1ha2VzIHNlbnNlLi5cIlxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIHJldHVybjtcclxuICAgICAgfVxyXG5cclxuICAgICAgY29tcG9zZUVtYWlsKHtcclxuICAgICAgICBzdWJqZWN0OiBzdWJqZWN0LFxyXG4gICAgICAgIGJvZHk6IGJvZHlcclxuICAgICAgfSkudGhlbigoeCkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiRW1haWwgcmVzdWx0OiBcIiArIHgpO1xyXG4gICAgICB9KTtcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgc2hhcmVTZWxmaWUoKTogdm9pZCB7XHJcbiAgICBsZXQgYWN0aW9uT3B0aW9uczogQXJyYXk8c3RyaW5nPiA9IFtcclxuICAgICAgXCJGcmVzaCBwaWMgKGNhbWVyYSlcIixcclxuICAgICAgXCJPbGRlciBwaWMgKGNhbWVyYSBhbGJ1bSlcIlxyXG4gICAgXTtcclxuXHJcbiAgICBhY3Rpb24oXHJcbiAgICAgICAgXCJEbyB5b3Ugd2FudCB0byB0YWtlIGEgZnJlc2ggcGljIG9yIHNlbGVjdCBhbiBvbGRlciBvbmU/XCIsXHJcbiAgICAgICAgXCJDYW5jZWxcIixcclxuICAgICAgICBhY3Rpb25PcHRpb25zXHJcbiAgICApLnRoZW4oKHBpY2tlZEl0ZW06IHN0cmluZykgPT4ge1xyXG4gICAgICBsZXQgcGlja2VkSXRlbUluZGV4ID0gYWN0aW9uT3B0aW9ucy5pbmRleE9mKHBpY2tlZEl0ZW0pO1xyXG4gICAgICBpZiAocGlja2VkSXRlbUluZGV4ID09PSAwKSB7XHJcbiAgICAgICAgLy8gQ2FtZXJhIHBsdWdpblxyXG4gICAgICAgIGlmIChpc0lPUykge1xyXG4gICAgICAgICAgQ2FtZXJhLnJlcXVlc3RQZXJtaXNzaW9ucygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgQ2FtZXJhLnRha2VQaWN0dXJlKHtcclxuICAgICAgICAgIHdpZHRoOiAxMDAwLFxyXG4gICAgICAgICAgaGVpZ2h0OiAxMDAwLFxyXG4gICAgICAgICAga2VlcEFzcGVjdFJhdGlvOiB0cnVlLFxyXG4gICAgICAgICAgc2F2ZVRvR2FsbGVyeTogZmFsc2UsXHJcbiAgICAgICAgICBjYW1lcmFGYWNpbmc6IFwiZnJvbnRcIlxyXG4gICAgICAgIH0pLnRoZW4oaW1hZ2VBc3NldCA9PiB7XHJcbiAgICAgICAgICBuZXcgSW1hZ2VTb3VyY2UoKS5mcm9tQXNzZXQoaW1hZ2VBc3NldCkudGhlbihpbWFnZVNvdXJjZSA9PiB7XHJcbiAgICAgICAgICAgIFNvY2lhbFNoYXJlLnNoYXJlSW1hZ2UoaW1hZ2VTb3VyY2UpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH0gZWxzZSBpZiAocGlja2VkSXRlbUluZGV4ID09PSAxKSB7XHJcbiAgICAgICAgLy8gSW1hZ2UgUGlja2VyIHBsdWdpblxyXG4gICAgICAgIGNvbnN0IGltYWdlUGlja2VyID0gSW1hZ2VQaWNrZXIuY3JlYXRlKHtcclxuICAgICAgICAgIG1vZGU6IFwic2luZ2xlXCIsXHJcbiAgICAgICAgICBuZXdlc3RGaXJzdDogdHJ1ZSwgLy8gaU9TXHJcbiAgICAgICAgICBkb25lVGV4dDogXCJEb25lXCIsXHJcbiAgICAgICAgICBjYW5jZWxUZXh0OiBcIkNhbmNlbFwiXHJcbiAgICAgICAgfSk7XHJcbiAgICAgICAgaW1hZ2VQaWNrZXJcclxuICAgICAgICAgICAgLmF1dGhvcml6ZSgpXHJcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICByZXR1cm4gaW1hZ2VQaWNrZXIucHJlc2VudCgpO1xyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAudGhlbigoc2VsZWN0aW9uOiBBcnJheTxJbWFnZVBpY2tlci5TZWxlY3RlZEFzc2V0IC8qIHdoaWNoIGlzIGEgc3ViY2xhc3Mgb2YgSW1hZ2VBc3NldCAqLz4pID0+IHtcclxuICAgICAgICAgICAgICBzZWxlY3Rpb24uZm9yRWFjaChzZWxlY3RlZCA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZWxlY3RlZC5nZXRJbWFnZSh7XHJcbiAgICAgICAgICAgICAgICAgIG1heFdpZHRoOiAxMDAwLFxyXG4gICAgICAgICAgICAgICAgICBtYXhIZWlnaHQ6IDEwMDAsXHJcbiAgICAgICAgICAgICAgICAgIGFzcGVjdFJhdGlvOiAnZml0J1xyXG4gICAgICAgICAgICAgICAgfSkudGhlbigoaW1hZ2VTb3VyY2U6IEltYWdlU291cmNlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIFNvY2lhbFNoYXJlLnNoYXJlSW1hZ2UoaW1hZ2VTb3VyY2UpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5jYXRjaChlID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgSW1hZ2UgUGlja2VyIGVycm9yOiAke2V9YCk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgfVxyXG5cclxuICBmaW5kVG9kYXlzRXZlbnRzKCk6IHZvaWQge1xyXG4gICAgbGV0IG5vdyA9IG5ldyBEYXRlKCk7XHJcbiAgICBsZXQgbWlkbmlnaHQgPSBuZXcgRGF0ZSgpO1xyXG4gICAgbWlkbmlnaHQuc2V0SG91cnMoMjQsIDAsIDAsIDApO1xyXG4gICAgQ2FsZW5kYXIuZmluZEV2ZW50cyh7XHJcbiAgICAgIHN0YXJ0RGF0ZTogbm93LFxyXG4gICAgICBlbmREYXRlOiBtaWRuaWdodFxyXG4gICAgfSkudGhlbihcclxuICAgICAgICBldmVudHMgPT4ge1xyXG4gICAgICAgICAgbGV0IGV2ZW50c1Nwb2tlbiA9IDA7XHJcbiAgICAgICAgICBldmVudHMubWFwKGV2ID0+IHtcclxuICAgICAgICAgICAgaWYgKCFldi5hbGxEYXkpIHtcclxuICAgICAgICAgICAgICBldmVudHNTcG9rZW4rKztcclxuICAgICAgICAgICAgICBsZXQgc2Vjb25kc0Zyb21Ob3cgPSBNYXRoLnJvdW5kKChldi5zdGFydERhdGUuZ2V0VGltZSgpIC0gbmV3IERhdGUoKS5nZXRUaW1lKCkpIC8gMTAwMCk7XHJcbiAgICAgICAgICAgICAgbGV0IGhvdXJzID0gTWF0aC5mbG9vcihzZWNvbmRzRnJvbU5vdyAvICg2MCAqIDYwKSk7XHJcbiAgICAgICAgICAgICAgbGV0IG1pbnV0ZXMgPSBNYXRoLnJvdW5kKChzZWNvbmRzRnJvbU5vdyAvIDYwKSAlIDYwKTtcclxuICAgICAgICAgICAgICB0aGlzLnRleHQyc3BlZWNoLnNwZWFrKHtcclxuICAgICAgICAgICAgICAgIHRleHQ6IGAke2V2LnRpdGxlfSBpbiAke2hvdXJzID4gMCA/IGhvdXJzICsgJyBob3VyJyArIChob3VycyA+IDEgPyAncycgOiAnJykgKyAnIGFuZCAnIDogJyd9ICR7bWludXRlc30gbWludXRlc2AsXHJcbiAgICAgICAgICAgICAgICBzcGVha1JhdGU6IHRoaXMuZ2V0U3BlYWtSYXRlKCksXHJcbiAgICAgICAgICAgICAgICBwaXRjaDogdGhpcy5nZXRQaXRjaCgpXHJcbiAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgaWYgKGV2ZW50c1Nwb2tlbiA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLnRleHQyc3BlZWNoLnNwZWFrKHtcclxuICAgICAgICAgICAgICB0ZXh0OiBgWW91ciBzY2hlZHVsZSBpcyBjbGVhci4gSGF2ZSBhIG5pY2UgZGF5LmAsXHJcbiAgICAgICAgICAgICAgbG9jYWxlOiBcImVuLVVTXCIsXHJcbiAgICAgICAgICAgICAgc3BlYWtSYXRlOiB0aGlzLmdldFNwZWFrUmF0ZSgpLFxyXG4gICAgICAgICAgICAgIHBpdGNoOiB0aGlzLmdldFBpdGNoKClcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBmdW5jdGlvbiAoZXJyb3IpIHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGBFcnJvciBmaW5kaW5nIEV2ZW50czogJHtlcnJvcn1gKTtcclxuICAgICAgICB9XHJcbiAgICApO1xyXG4gIH1cclxuXHJcbiAgcHJpdmF0ZSBnZXRTcGVha1JhdGUoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLnNwZWFrUmF0ZSAvIDEwMDtcclxuICB9XHJcblxyXG4gIHByaXZhdGUgZ2V0UGl0Y2goKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLnBpdGNoIC8gMTAwO1xyXG4gIH1cclxuXHJcbiAgcHJvdGVjdGVkIGdldFBsdWdpbkluZm8oKTogUGx1Z2luSW5mb1dyYXBwZXIge1xyXG4gICAgcmV0dXJuIG5ldyBQbHVnaW5JbmZvV3JhcHBlcihcclxuICAgICAgICBcIkFsd2F5cyB3YW50ZWQgYSBmdWxseSB0cmFpbmVkIHBhcnJvdD9cXG5cXG5SZWNvcmQgeW91ciB2b2ljZSBpbiB0aGUgZGV2aWNlIGxhbmd1YWdlIGFuZCBpdCB3aWxsIGJlIHNob3duIGFuZCByZWFkIGJhY2sgdG8geW91LlxcblxcbkJlIHN1cmUgdG8gdHJ5IHRoZSB0aXBzIGFzIHdlbGwhXCIsXHJcbiAgICAgICAgQXJyYXkub2YoXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtdGV4dHRvc3BlZWNoXCIsXHJcbiAgICAgICAgICAgICAgICBcIlRleHQgdG8gU3BlZWNoXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9icmFkbWFydGluL25hdGl2ZXNjcmlwdC10ZXh0dG9zcGVlY2hcIixcclxuICAgICAgICAgICAgICAgIFwiTWFrZSB5b3VyIGFwcCBzcGVhay4gTWlnaHQgYmUgdXNlZnVsIGZvciBkaXNhYmxlZCBwZW9wbGUg7aC97bGALiBDZXJ0YWlubHkgdXNlZnVsIGZvciBsYXp5IG9uZXMuXCJcclxuICAgICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtc3BlZWNoLXJlY29nbml0aW9uXCIsXHJcbiAgICAgICAgICAgICAgICBcIlNwZWVjaCBSZWNvZ25pdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vbmF0aXZlc2NyaXB0LXNwZWVjaC1yZWNvZ25pdGlvblwiLFxyXG4gICAgICAgICAgICAgICAgXCJTcGVhayB0byB5b3VyIGFwcCDtoL3tsYQuIFVzZWZ1bCBmb3Igdm9pY2UgY29udHJvbCBhbmQgc2lsbHkgZGVtbydzIO2gve24hFwiXHJcbiAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICBuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgICAgICAgIFwibmF0aXZlc2NyaXB0LWNhbGVuZGFyXCIsXHJcbiAgICAgICAgICAgICAgICBcIkNhbGVuZGFyICDtoL3tt5NcIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL0VkZHlWZXJicnVnZ2VuL25hdGl2ZXNjcmlwdC1jYWxlbmRhclwiLFxyXG4gICAgICAgICAgICAgICAgXCJDcmVhdGUsIERlbGV0ZSBhbmQgRmluZCBFdmVudHMgaW4gdGhlIG5hdGl2ZSBDYWxlbmRhclwiXHJcbiAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICBuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgICAgICAgIFwibmF0aXZlc2NyaXB0LWVtYWlsXCIsXHJcbiAgICAgICAgICAgICAgICBcIkVtYWlsICDinInvuI9cIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL0VkZHlWZXJicnVnZ2VuL25hdGl2ZXNjcmlwdC1lbWFpbFwiLFxyXG4gICAgICAgICAgICAgICAgXCJPcGVuIGFuIGUtbWFpbCBkcmFmdFwiXHJcbiAgICAgICAgICAgICksXHJcblxyXG4gICAgICAgICAgICBuZXcgUGx1Z2luSW5mbyhcclxuICAgICAgICAgICAgICAgIFwibmF0aXZlc2NyaXB0LXNvY2lhbC1zaGFyZVwiLFxyXG4gICAgICAgICAgICAgICAgXCJTb2NpYWwgU2hhcmUgIOKZu++4j++4j1wiLFxyXG4gICAgICAgICAgICAgICAgXCJodHRwczovL2dpdGh1Yi5jb20vdGp2YW50b2xsL25hdGl2ZXNjcmlwdC1zb2NpYWwtc2hhcmVcIixcclxuICAgICAgICAgICAgICAgIFwiVXNlIHRoZSBuYXRpdmUgc2hhcmluZyB3aWRnZXRcIlxyXG4gICAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1hdWRpb1wiLFxyXG4gICAgICAgICAgICAgICAgXCJBdWRpbyAg7aC87b6kICDtoLztvrVcIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL2JyYWRtYXJ0aW4vbmF0aXZlc2NyaXB0LWF1ZGlvXCIsXHJcbiAgICAgICAgICAgICAgICBcIk5hdGl2ZVNjcmlwdCBwbHVnaW4gdG8gcmVjb3JkIGFuZCBwbGF5IGF1ZGlvXCJcclxuICAgICAgICAgICAgKSxcclxuXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtY2FtZXJhXCIsXHJcbiAgICAgICAgICAgICAgICBcIkNhbWVyYSAg7aC87b6lXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9OYXRpdmVTY3JpcHQvbmF0aXZlc2NyaXB0LWNhbWVyYVwiLFxyXG4gICAgICAgICAgICAgICAgXCJHcmFiIHBpY3R1cmVzIGZyb20gdGhlIGRldmljZSBjYW1lcmFcIlxyXG4gICAgICAgICAgICApLFxyXG5cclxuICAgICAgICAgICAgbmV3IFBsdWdpbkluZm8oXHJcbiAgICAgICAgICAgICAgICBcIm5hdGl2ZXNjcmlwdC1pbWFnZXBpY2tlclwiLFxyXG4gICAgICAgICAgICAgICAgXCJJbWFnZSBQaWNrZXJcIixcclxuICAgICAgICAgICAgICAgIFwiaHR0cHM6Ly9naXRodWIuY29tL05hdGl2ZVNjcmlwdC9uYXRpdmVzY3JpcHQtaW1hZ2VwaWNrZXJcIixcclxuICAgICAgICAgICAgICAgIFwiU2VsZWN0IG9uZSBvciBtb3JlIGltYWdlcyBmcm9tIHRoZSBjYW1lcmEgcm9sbFwiXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICApXHJcbiAgICApO1xyXG4gIH1cclxufVxyXG4iXX0=