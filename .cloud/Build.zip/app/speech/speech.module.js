Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var speech_routing_module_1 = require("./speech-routing.module");
var speech_component_1 = require("./speech.component");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var SpeechModule = (function () {
    function SpeechModule() {
    }
    SpeechModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                speech_routing_module_1.SpeechRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
            ],
            declarations: [
                speech_component_1.SpeechComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], SpeechModule);
    return SpeechModule;
}());
exports.SpeechModule = SpeechModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3BlZWNoLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInNwZWVjaC5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHNDQUEyRDtBQUMzRCxzREFBdUU7QUFFdkUsaUVBQThEO0FBQzlELHVEQUFxRDtBQUNyRCx1RUFBOEQ7QUFlOUQ7SUFBQTtJQUE0QixDQUFDO0lBQWhCLFlBQVk7UUFieEIsZUFBUSxDQUFDO1lBQ1IsT0FBTyxFQUFFO2dCQUNQLGlDQUF3QjtnQkFDeEIsMkNBQW1CO2dCQUNuQiw2Q0FBaUI7YUFDbEI7WUFDRCxZQUFZLEVBQUU7Z0JBQ1osa0NBQWU7YUFDaEI7WUFDRCxPQUFPLEVBQUU7Z0JBQ1AsdUJBQWdCO2FBQ2pCO1NBQ0YsQ0FBQztPQUNXLFlBQVksQ0FBSTtJQUFELG1CQUFDO0NBQUEsQUFBN0IsSUFBNkI7QUFBaEIsb0NBQVkiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSwgTk9fRVJST1JTX1NDSEVNQSB9IGZyb20gXCJAYW5ndWxhci9jb3JlXCI7XHJcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtYW5ndWxhci9jb21tb25cIjtcclxuXHJcbmltcG9ydCB7IFNwZWVjaFJvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9zcGVlY2gtcm91dGluZy5tb2R1bGVcIjtcclxuaW1wb3J0IHsgU3BlZWNoQ29tcG9uZW50IH0gZnJvbSBcIi4vc3BlZWNoLmNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBUTlNGb250SWNvbk1vZHVsZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtbmd4LWZvbnRpY29uXCI7XHJcblxyXG5ATmdNb2R1bGUoe1xyXG4gIGltcG9ydHM6IFtcclxuICAgIE5hdGl2ZVNjcmlwdENvbW1vbk1vZHVsZSxcclxuICAgIFNwZWVjaFJvdXRpbmdNb2R1bGUsXHJcbiAgICBUTlNGb250SWNvbk1vZHVsZSxcclxuICBdLFxyXG4gIGRlY2xhcmF0aW9uczogW1xyXG4gICAgU3BlZWNoQ29tcG9uZW50XHJcbiAgXSxcclxuICBzY2hlbWFzOiBbXHJcbiAgICBOT19FUlJPUlNfU0NIRU1BXHJcbiAgXVxyXG59KVxyXG5leHBvcnQgY2xhc3MgU3BlZWNoTW9kdWxlIHsgfVxyXG4iXX0=