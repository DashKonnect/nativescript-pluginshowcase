Object.defineProperty(exports, "__esModule", { value: true });
var Config = (function () {
    function Config() {
    }
    Config.isProdMode = false;
    Config.isTablet = false;
    Config.DEBUG_MODE = {
        firstPage: "/menu"
    };
    return Config;
}());
exports.Config = Config;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTtJQUFBO0lBT0EsQ0FBQztJQU5RLGlCQUFVLEdBQVksS0FBSyxDQUFDO0lBQzVCLGVBQVEsR0FBWSxLQUFLLENBQUM7SUFFMUIsaUJBQVUsR0FBRztRQUNsQixTQUFTLEVBQUUsT0FBTztLQUNuQixDQUFDO0lBQ0osYUFBQztDQUFBLEFBUEQsSUFPQztBQVBZLHdCQUFNIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIENvbmZpZyB7XHJcbiAgc3RhdGljIGlzUHJvZE1vZGU6IGJvb2xlYW4gPSBmYWxzZTtcclxuICBzdGF0aWMgaXNUYWJsZXQ6IGJvb2xlYW4gPSBmYWxzZTsgLy8gc2V0IGluIGFwcC5tb2R1bGUudHNcclxuXHJcbiAgc3RhdGljIERFQlVHX01PREUgPSB7XHJcbiAgICBmaXJzdFBhZ2U6IFwiL21lbnVcIlxyXG4gIH07XHJcbn0iXX0=