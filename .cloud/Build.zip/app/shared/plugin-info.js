Object.defineProperty(exports, "__esModule", { value: true });
var PluginInfo = (function () {
    function PluginInfo(id, name, url, description) {
        this.id = id;
        this.name = name;
        this.url = url;
        this.description = description;
    }
    return PluginInfo;
}());
exports.PluginInfo = PluginInfo;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGx1Z2luLWluZm8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJwbHVnaW4taW5mby50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7SUFNRSxvQkFBWSxFQUFVLEVBQUUsSUFBWSxFQUFFLEdBQVcsRUFBRSxXQUFvQjtRQUNyRSxJQUFJLENBQUMsRUFBRSxHQUFHLEVBQUUsQ0FBQztRQUNiLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1FBQ2pCLElBQUksQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDO1FBQ2YsSUFBSSxDQUFDLFdBQVcsR0FBRyxXQUFXLENBQUM7SUFDakMsQ0FBQztJQUNILGlCQUFDO0FBQUQsQ0FBQyxBQVpELElBWUM7QUFaWSxnQ0FBVSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBQbHVnaW5JbmZvIHtcclxuICBpZDogc3RyaW5nO1xyXG4gIG5hbWU6IHN0cmluZztcclxuICB1cmw6IHN0cmluZztcclxuICBkZXNjcmlwdGlvbj86IHN0cmluZztcclxuXHJcbiAgY29uc3RydWN0b3IoaWQ6IHN0cmluZywgbmFtZTogc3RyaW5nLCB1cmw6IHN0cmluZywgZGVzY3JpcHRpb24/OiBzdHJpbmcpIHtcclxuICAgIHRoaXMuaWQgPSBpZDtcclxuICAgIHRoaXMubmFtZSA9IG5hbWU7XHJcbiAgICB0aGlzLnVybCA9IHVybDtcclxuICAgIHRoaXMuZGVzY3JpcHRpb24gPSBkZXNjcmlwdGlvbjtcclxuICB9XHJcbn0iXX0=