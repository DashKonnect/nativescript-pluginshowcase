Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var angular_1 = require("nativescript-pro-ui/sidedrawer/angular");
var router_1 = require("@angular/router");
var platform_1 = require("tns-core-modules/platform");
var nativescript_appavailability_1 = require("nativescript-appavailability");
var utils_1 = require("tns-core-modules/utils/utils");
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var config_1 = require("../shared/config");
var MenuComponent = (function () {
    function MenuComponent(_changeDetectionRef, _router) {
        this._changeDetectionRef = _changeDetectionRef;
        this._router = _router;
        this.isIOS = platform_1.isIOS;
        this.isTablet = config_1.Config.isTablet;
    }
    MenuComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.routerSubscription = this._router.events.subscribe(function (e) {
            if (e instanceof router_1.NavigationEnd && _this._drawer) {
                _this._drawer.closeDrawer();
            }
        });
    };
    MenuComponent.prototype.ngAfterViewInit = function () {
        this._drawer = this.drawerComponent.sideDrawer;
        this._changeDetectionRef.detectChanges();
        if (this._drawer.ios) {
            var sideDrawer = this._drawer.ios.defaultSideDrawer;
            sideDrawer.style.shadowMode = 1;
            sideDrawer.style.shadowOpacity = 0.75;
            sideDrawer.style.shadowRadius = 5;
            sideDrawer.transitionDuration = 0.25;
        }
    };
    MenuComponent.prototype.ngOnDestroy = function () {
        this._changeDetectionRef.detach();
        this._changeDetectionRef = null;
        if (this.routerSubscription) {
            this.routerSubscription.unsubscribe();
        }
        this._drawer = null;
        this.drawerComponent = null;
    };
    MenuComponent.prototype.toggleMenu = function () {
        this._drawer.toggleDrawerState();
    };
    MenuComponent.prototype.isMenuOpen = function () {
        return this._drawer.getIsOpen();
    };
    MenuComponent.prototype.closeMenuIfOpen = function () {
        if (this._drawer.getIsOpen()) {
            this._drawer.closeDrawer();
        }
    };
    MenuComponent.prototype.getDrawer = function () {
        return this._drawer;
    };
    MenuComponent.prototype.openTwitter = function () {
        var url, message;
        if (nativescript_appavailability_1.availableSync("twitter://")) {
            message = "With nativescript-appavailability we determined you have the Twitter app installed, now opening it!";
            url = "twitter://" + (platform_1.isIOS ? "/user?screen_name=" : "user?user_id=") + "eddyverbruggen";
        }
        else {
            message = "With nativescript-appavailability we determined you don't have the Twitter app installed, so we're now loading Twitter in a browser instead.";
            url = "https://twitter.com/eddyverbruggen";
        }
        dialogs_1.alert({
            title: "App Availability plugin FTW!",
            message: message,
            okButtonText: "Honestly I can't wait",
            cancelable: false
        }).then(function () {
            utils_1.openUrl(url);
        });
    };
    __decorate([
        core_1.ViewChild(angular_1.RadSideDrawerComponent),
        __metadata("design:type", angular_1.RadSideDrawerComponent)
    ], MenuComponent.prototype, "drawerComponent", void 0);
    MenuComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'menu-contents',
            templateUrl: 'menu.component.html',
            styleUrls: ['menu.css']
        }),
        __metadata("design:paramtypes", [core_1.ChangeDetectorRef,
            router_1.Router])
    ], MenuComponent);
    return MenuComponent;
}());
exports.MenuComponent = MenuComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWVudS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJtZW51LmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQTBHO0FBQzFHLGtFQUFnRztBQUNoRywwQ0FBd0Q7QUFFeEQsc0RBQWtEO0FBQ2xELDZFQUE2RDtBQUM3RCxzREFBdUQ7QUFDdkQsdURBQW9EO0FBQ3BELDJDQUEwQztBQVMxQztJQVFFLHVCQUFvQixtQkFBc0MsRUFDdEMsT0FBZTtRQURmLHdCQUFtQixHQUFuQixtQkFBbUIsQ0FBbUI7UUFDdEMsWUFBTyxHQUFQLE9BQU8sQ0FBUTtRQVJuQyxVQUFLLEdBQVksZ0JBQUssQ0FBQztRQUN2QixhQUFRLEdBQVksZUFBTSxDQUFDLFFBQVEsQ0FBQztJQVFwQyxDQUFDO0lBRUQsZ0NBQVEsR0FBUjtRQUFBLGlCQU1DO1FBTEMsSUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFDLENBQUM7WUFDeEQsRUFBRSxDQUFDLENBQUMsQ0FBQyxZQUFZLHNCQUFhLElBQUksS0FBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Z0JBQy9DLEtBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7WUFDN0IsQ0FBQztRQUNILENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHVDQUFlLEdBQWY7UUFFRSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsVUFBVSxDQUFDO1FBQy9DLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQztRQUN6QyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDckIsSUFBTSxVQUFVLEdBQWlCLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO1lBQ3BFLFVBQVUsQ0FBQyxLQUFLLENBQUMsVUFBVSxJQUFrQyxDQUFDO1lBQzlELFVBQVUsQ0FBQyxLQUFLLENBQUMsYUFBYSxHQUFHLElBQUksQ0FBQztZQUN0QyxVQUFVLENBQUMsS0FBSyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUM7WUFDbEMsVUFBVSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELG1DQUFXLEdBQVg7UUFDRSxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLENBQUM7UUFDbEMsSUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQztRQUNoQyxFQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDO1lBQzVCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN4QyxDQUFDO1FBQ0QsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUM7UUFDcEIsSUFBSSxDQUFDLGVBQWUsR0FBRyxJQUFJLENBQUM7SUFDOUIsQ0FBQztJQUVELGtDQUFVLEdBQVY7UUFDRSxJQUFJLENBQUMsT0FBTyxDQUFDLGlCQUFpQixFQUFFLENBQUM7SUFDbkMsQ0FBQztJQUVELGtDQUFVLEdBQVY7UUFDRSxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztJQUNsQyxDQUFDO0lBRUQsdUNBQWUsR0FBZjtRQUNFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQyxDQUFDO1lBQzdCLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDN0IsQ0FBQztJQUNILENBQUM7SUFFRCxpQ0FBUyxHQUFUO1FBQ0UsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDdEIsQ0FBQztJQUVELG1DQUFXLEdBQVg7UUFDRSxJQUFJLEdBQUcsRUFBRSxPQUFPLENBQUM7UUFFakIsRUFBRSxDQUFDLENBQUMsNENBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDaEMsT0FBTyxHQUFHLHFHQUFxRyxDQUFDO1lBQ2hILEdBQUcsR0FBRyxZQUFZLEdBQUcsQ0FBQyxnQkFBSyxHQUFHLG9CQUFvQixHQUFHLGVBQWUsQ0FBQyxHQUFHLGdCQUFnQixDQUFDO1FBQzNGLENBQUM7UUFBQyxJQUFJLENBQUMsQ0FBQztZQUNOLE9BQU8sR0FBRyw4SUFBOEksQ0FBQztZQUN6SixHQUFHLEdBQUcsb0NBQW9DLENBQUM7UUFDN0MsQ0FBQztRQUVELGVBQUssQ0FBQztZQUNKLEtBQUssRUFBRSw4QkFBOEI7WUFDckMsT0FBTyxFQUFFLE9BQU87WUFDaEIsWUFBWSxFQUFFLHVCQUF1QjtZQUNyQyxVQUFVLEVBQUUsS0FBSztTQUNsQixDQUFDLENBQUMsSUFBSSxDQUFDO1lBRU4sZUFBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ2YsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBN0VrQztRQUFsQyxnQkFBUyxDQUFDLGdDQUFzQixDQUFDO2tDQUF5QixnQ0FBc0I7MERBQUM7SUFKdkUsYUFBYTtRQVB6QixnQkFBUyxDQUFDO1lBQ1QsUUFBUSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ25CLFFBQVEsRUFBRSxlQUFlO1lBQ3pCLFdBQVcsRUFBRSxxQkFBcUI7WUFDbEMsU0FBUyxFQUFFLENBQUMsVUFBVSxDQUFDO1NBQ3hCLENBQUM7eUNBVXlDLHdCQUFpQjtZQUM3QixlQUFNO09BVHhCLGFBQWEsQ0FrRnpCO0lBQUQsb0JBQUM7Q0FBQSxBQWxGRCxJQWtGQztBQWxGWSxzQ0FBYSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEFmdGVyVmlld0luaXQsIENoYW5nZURldGVjdG9yUmVmLCBDb21wb25lbnQsIE9uRGVzdHJveSwgT25Jbml0LCBWaWV3Q2hpbGQgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBSYWRTaWRlRHJhd2VyQ29tcG9uZW50LCBTaWRlRHJhd2VyVHlwZSB9IGZyb20gXCJuYXRpdmVzY3JpcHQtcHJvLXVpL3NpZGVkcmF3ZXIvYW5ndWxhclwiO1xyXG5pbXBvcnQgeyBOYXZpZ2F0aW9uRW5kLCBSb3V0ZXIgfSBmcm9tIFwiQGFuZ3VsYXIvcm91dGVyXCI7XHJcbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gXCJyeGpzL1N1YnNjcmlwdGlvblwiO1xyXG5pbXBvcnQgeyBpc0lPUyB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3BsYXRmb3JtXCI7XHJcbmltcG9ydCB7IGF2YWlsYWJsZVN5bmMgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFwcGF2YWlsYWJpbGl0eVwiO1xyXG5pbXBvcnQgeyBvcGVuVXJsIH0gZnJvbSBcInRucy1jb3JlLW1vZHVsZXMvdXRpbHMvdXRpbHNcIjtcclxuaW1wb3J0IHsgYWxlcnQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XHJcbmltcG9ydCB7IENvbmZpZyB9IGZyb20gXCIuLi9zaGFyZWQvY29uZmlnXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gIHNlbGVjdG9yOiAnbWVudS1jb250ZW50cycsXHJcbiAgdGVtcGxhdGVVcmw6ICdtZW51LmNvbXBvbmVudC5odG1sJyxcclxuICBzdHlsZVVybHM6IFsnbWVudS5jc3MnXVxyXG59KVxyXG5cclxuZXhwb3J0IGNsYXNzIE1lbnVDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIEFmdGVyVmlld0luaXQsIE9uRGVzdHJveSB7XHJcbiAgaXNJT1M6IGJvb2xlYW4gPSBpc0lPUztcclxuICBpc1RhYmxldDogYm9vbGVhbiA9IENvbmZpZy5pc1RhYmxldDtcclxuXHJcbiAgQFZpZXdDaGlsZChSYWRTaWRlRHJhd2VyQ29tcG9uZW50KSBwdWJsaWMgZHJhd2VyQ29tcG9uZW50OiBSYWRTaWRlRHJhd2VyQ29tcG9uZW50O1xyXG4gIHByaXZhdGUgX2RyYXdlcjogU2lkZURyYXdlclR5cGU7XHJcbiAgcHJpdmF0ZSByb3V0ZXJTdWJzY3JpcHRpb246IFN1YnNjcmlwdGlvbjtcclxuXHJcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBfY2hhbmdlRGV0ZWN0aW9uUmVmOiBDaGFuZ2VEZXRlY3RvclJlZixcclxuICAgICAgICAgICAgICBwcml2YXRlIF9yb3V0ZXI6IFJvdXRlcikge1xyXG4gIH1cclxuXHJcbiAgbmdPbkluaXQoKTogdm9pZCB7XHJcbiAgICB0aGlzLnJvdXRlclN1YnNjcmlwdGlvbiA9IHRoaXMuX3JvdXRlci5ldmVudHMuc3Vic2NyaWJlKChlKSA9PiB7XHJcbiAgICAgIGlmIChlIGluc3RhbmNlb2YgTmF2aWdhdGlvbkVuZCAmJiB0aGlzLl9kcmF3ZXIpIHtcclxuICAgICAgICB0aGlzLl9kcmF3ZXIuY2xvc2VEcmF3ZXIoKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBuZ0FmdGVyVmlld0luaXQoKTogdm9pZCB7XHJcbiAgICAvLyBhZGQgYSBuaWNlIHNoYWRvdyB0byB0aGUgaU9TIGRyYXdlciAodGhlcmUgYWxyZWFkeSBpcyBvbmUgb24gQW5kcm9pZClcclxuICAgIHRoaXMuX2RyYXdlciA9IHRoaXMuZHJhd2VyQ29tcG9uZW50LnNpZGVEcmF3ZXI7XHJcbiAgICB0aGlzLl9jaGFuZ2VEZXRlY3Rpb25SZWYuZGV0ZWN0Q2hhbmdlcygpO1xyXG4gICAgaWYgKHRoaXMuX2RyYXdlci5pb3MpIHtcclxuICAgICAgY29uc3Qgc2lkZURyYXdlcjogVEtTaWRlRHJhd2VyID0gdGhpcy5fZHJhd2VyLmlvcy5kZWZhdWx0U2lkZURyYXdlcjtcclxuICAgICAgc2lkZURyYXdlci5zdHlsZS5zaGFkb3dNb2RlID0gVEtTaWRlRHJhd2VyU2hhZG93TW9kZS5Ib3N0dmlldztcclxuICAgICAgc2lkZURyYXdlci5zdHlsZS5zaGFkb3dPcGFjaXR5ID0gMC43NTtcclxuICAgICAgc2lkZURyYXdlci5zdHlsZS5zaGFkb3dSYWRpdXMgPSA1O1xyXG4gICAgICBzaWRlRHJhd2VyLnRyYW5zaXRpb25EdXJhdGlvbiA9IDAuMjU7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcclxuICAgIHRoaXMuX2NoYW5nZURldGVjdGlvblJlZi5kZXRhY2goKTtcclxuICAgIHRoaXMuX2NoYW5nZURldGVjdGlvblJlZiA9IG51bGw7XHJcbiAgICBpZiAodGhpcy5yb3V0ZXJTdWJzY3JpcHRpb24pIHtcclxuICAgICAgdGhpcy5yb3V0ZXJTdWJzY3JpcHRpb24udW5zdWJzY3JpYmUoKTtcclxuICAgIH1cclxuICAgIHRoaXMuX2RyYXdlciA9IG51bGw7XHJcbiAgICB0aGlzLmRyYXdlckNvbXBvbmVudCA9IG51bGw7XHJcbiAgfVxyXG5cclxuICB0b2dnbGVNZW51KCk6IHZvaWQge1xyXG4gICAgdGhpcy5fZHJhd2VyLnRvZ2dsZURyYXdlclN0YXRlKCk7XHJcbiAgfVxyXG5cclxuICBpc01lbnVPcGVuKCk6IGJvb2xlYW4ge1xyXG4gICAgcmV0dXJuIHRoaXMuX2RyYXdlci5nZXRJc09wZW4oKTtcclxuICB9XHJcblxyXG4gIGNsb3NlTWVudUlmT3BlbigpOiB2b2lkIHtcclxuICAgIGlmICh0aGlzLl9kcmF3ZXIuZ2V0SXNPcGVuKCkpIHtcclxuICAgICAgdGhpcy5fZHJhd2VyLmNsb3NlRHJhd2VyKCk7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXREcmF3ZXIoKTogU2lkZURyYXdlclR5cGUge1xyXG4gICAgcmV0dXJuIHRoaXMuX2RyYXdlcjtcclxuICB9XHJcblxyXG4gIG9wZW5Ud2l0dGVyKCk6IHZvaWQge1xyXG4gICAgbGV0IHVybCwgbWVzc2FnZTtcclxuXHJcbiAgICBpZiAoYXZhaWxhYmxlU3luYyhcInR3aXR0ZXI6Ly9cIikpIHtcclxuICAgICAgbWVzc2FnZSA9IFwiV2l0aCBuYXRpdmVzY3JpcHQtYXBwYXZhaWxhYmlsaXR5IHdlIGRldGVybWluZWQgeW91IGhhdmUgdGhlIFR3aXR0ZXIgYXBwIGluc3RhbGxlZCwgbm93IG9wZW5pbmcgaXQhXCI7XHJcbiAgICAgIHVybCA9IFwidHdpdHRlcjovL1wiICsgKGlzSU9TID8gXCIvdXNlcj9zY3JlZW5fbmFtZT1cIiA6IFwidXNlcj91c2VyX2lkPVwiKSArIFwiZWRkeXZlcmJydWdnZW5cIjtcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIG1lc3NhZ2UgPSBcIldpdGggbmF0aXZlc2NyaXB0LWFwcGF2YWlsYWJpbGl0eSB3ZSBkZXRlcm1pbmVkIHlvdSBkb24ndCBoYXZlIHRoZSBUd2l0dGVyIGFwcCBpbnN0YWxsZWQsIHNvIHdlJ3JlIG5vdyBsb2FkaW5nIFR3aXR0ZXIgaW4gYSBicm93c2VyIGluc3RlYWQuXCI7XHJcbiAgICAgIHVybCA9IFwiaHR0cHM6Ly90d2l0dGVyLmNvbS9lZGR5dmVyYnJ1Z2dlblwiO1xyXG4gICAgfVxyXG5cclxuICAgIGFsZXJ0KHtcclxuICAgICAgdGl0bGU6IFwiQXBwIEF2YWlsYWJpbGl0eSBwbHVnaW4gRlRXIVwiLFxyXG4gICAgICBtZXNzYWdlOiBtZXNzYWdlLFxyXG4gICAgICBva0J1dHRvblRleHQ6IFwiSG9uZXN0bHkgSSBjYW4ndCB3YWl0XCIsXHJcbiAgICAgIGNhbmNlbGFibGU6IGZhbHNlXHJcbiAgICB9KS50aGVuKCgpID0+IHtcclxuICAgICAgLy8gb3BlbiBpbiB0aGUgYXBwXHJcbiAgICAgIG9wZW5VcmwodXJsKTtcclxuICAgIH0pO1xyXG4gIH1cclxufSJdfQ==