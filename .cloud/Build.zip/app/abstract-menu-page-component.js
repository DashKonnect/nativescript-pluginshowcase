Object.defineProperty(exports, "__esModule", { value: true });
var platform_1 = require("platform");
var info_modal_1 = require("./info-modal/info-modal");
var config_1 = require("./shared/config");
var AbstractMenuPageComponent = (function () {
    function AbstractMenuPageComponent(menuComponent, vcRef, modalService) {
        this.menuComponent = menuComponent;
        this.vcRef = vcRef;
        this.modalService = modalService;
        this.isIOS = platform_1.isIOS;
        this.isTablet = config_1.Config.isTablet;
    }
    AbstractMenuPageComponent.prototype.toggleTheMenu = function () {
        this.menuComponent.toggleMenu();
    };
    AbstractMenuPageComponent.prototype.closeMenuIfOpen = function () {
        this.menuComponent.closeMenuIfOpen();
    };
    AbstractMenuPageComponent.prototype.showPluginInfo = function () {
        var info = this.getPluginInfo();
        if (info === null) {
            return;
        }
        var drawer = this.menuComponent.getDrawer();
        if (drawer.ios) {
            drawer.ios.detachDrawerFromWindow();
        }
        var options = {
            viewContainerRef: this.vcRef,
            context: info,
            fullscreen: false,
        };
        this.modalService.showModal(info_modal_1.InfoModalComponent, options).then(function () {
            if (drawer.ios) {
                drawer.ios.attachDrawerToWindow();
            }
        });
    };
    return AbstractMenuPageComponent;
}());
exports.AbstractMenuPageComponent = AbstractMenuPageComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWJzdHJhY3QtbWVudS1wYWdlLWNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImFic3RyYWN0LW1lbnUtcGFnZS1jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUNBLHFDQUFpQztBQUdqQyxzREFBNkQ7QUFFN0QsMENBQXlDO0FBRXpDO0lBSUUsbUNBQXNCLGFBQTRCLEVBQzVCLEtBQXVCLEVBQ3ZCLFlBQWdDO1FBRmhDLGtCQUFhLEdBQWIsYUFBYSxDQUFlO1FBQzVCLFVBQUssR0FBTCxLQUFLLENBQWtCO1FBQ3ZCLGlCQUFZLEdBQVosWUFBWSxDQUFvQjtRQUx0RCxVQUFLLEdBQVksZ0JBQUssQ0FBQztRQUN2QixhQUFRLEdBQVksZUFBTSxDQUFDLFFBQVEsQ0FBQztJQUtwQyxDQUFDO0lBSUQsaURBQWEsR0FBYjtRQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxFQUFFLENBQUM7SUFDbEMsQ0FBQztJQUVELG1EQUFlLEdBQWY7UUFDRSxJQUFJLENBQUMsYUFBYSxDQUFDLGVBQWUsRUFBRSxDQUFDO0lBQ3ZDLENBQUM7SUFFRCxrREFBYyxHQUFkO1FBQ0UsSUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBQ2xDLEVBQUUsQ0FBQyxDQUFDLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ2xCLE1BQU0sQ0FBQztRQUNULENBQUM7UUFFRCxJQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxDQUFDO1FBRTlDLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO1lBQ2YsTUFBTSxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsRUFBRSxDQUFDO1FBQ3RDLENBQUM7UUFFRCxJQUFNLE9BQU8sR0FBdUI7WUFDbEMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLEtBQUs7WUFDNUIsT0FBTyxFQUFFLElBQUk7WUFDYixVQUFVLEVBQUUsS0FBSztTQUNsQixDQUFDO1FBRUYsSUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLENBQUMsK0JBQWtCLEVBQUUsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDO1lBRTVELEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUNmLE1BQU0sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztZQUNwQyxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBQ0gsZ0NBQUM7QUFBRCxDQUFDLEFBNUNELElBNENDO0FBNUNxQiw4REFBeUIiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBWaWV3Q29udGFpbmVyUmVmIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgaXNJT1MgfSBmcm9tIFwicGxhdGZvcm1cIjtcclxuaW1wb3J0IHsgTWVudUNvbXBvbmVudCB9IGZyb20gXCIuL21lbnUvbWVudS5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgTW9kYWxEaWFsb2dPcHRpb25zLCBNb2RhbERpYWxvZ1NlcnZpY2UgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgSW5mb01vZGFsQ29tcG9uZW50IH0gZnJvbSBcIi4vaW5mby1tb2RhbC9pbmZvLW1vZGFsXCI7XHJcbmltcG9ydCB7IFBsdWdpbkluZm9XcmFwcGVyIH0gZnJvbSBcIi4vc2hhcmVkL3BsdWdpbi1pbmZvLXdyYXBwZXJcIjtcclxuaW1wb3J0IHsgQ29uZmlnIH0gZnJvbSBcIi4vc2hhcmVkL2NvbmZpZ1wiO1xyXG5cclxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFic3RyYWN0TWVudVBhZ2VDb21wb25lbnQge1xyXG4gIGlzSU9TOiBib29sZWFuID0gaXNJT1M7XHJcbiAgaXNUYWJsZXQ6IGJvb2xlYW4gPSBDb25maWcuaXNUYWJsZXQ7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBtZW51Q29tcG9uZW50OiBNZW51Q29tcG9uZW50LFxyXG4gICAgICAgICAgICAgIHByb3RlY3RlZCB2Y1JlZjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgbW9kYWxTZXJ2aWNlOiBNb2RhbERpYWxvZ1NlcnZpY2UpIHtcclxuICB9XHJcblxyXG4gIHByb3RlY3RlZCBhYnN0cmFjdCBnZXRQbHVnaW5JbmZvKCk6IFBsdWdpbkluZm9XcmFwcGVyO1xyXG5cclxuICB0b2dnbGVUaGVNZW51KCk6IHZvaWQge1xyXG4gICAgdGhpcy5tZW51Q29tcG9uZW50LnRvZ2dsZU1lbnUoKTtcclxuICB9XHJcblxyXG4gIGNsb3NlTWVudUlmT3BlbigpOiB2b2lkIHtcclxuICAgIHRoaXMubWVudUNvbXBvbmVudC5jbG9zZU1lbnVJZk9wZW4oKTtcclxuICB9XHJcblxyXG4gIHNob3dQbHVnaW5JbmZvKCk6IHZvaWQge1xyXG4gICAgY29uc3QgaW5mbyA9IHRoaXMuZ2V0UGx1Z2luSW5mbygpO1xyXG4gICAgaWYgKGluZm8gPT09IG51bGwpIHtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGRyYXdlciA9IHRoaXMubWVudUNvbXBvbmVudC5nZXREcmF3ZXIoKTtcclxuICAgIC8vIHRoaXMgZWZmZWN0aXZlbHkgZGlzYWJsZXMgdGhlIGJhY2sgZ2VzdHVyZVxyXG4gICAgaWYgKGRyYXdlci5pb3MpIHtcclxuICAgICAgZHJhd2VyLmlvcy5kZXRhY2hEcmF3ZXJGcm9tV2luZG93KCk7XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3Qgb3B0aW9uczogTW9kYWxEaWFsb2dPcHRpb25zID0ge1xyXG4gICAgICB2aWV3Q29udGFpbmVyUmVmOiB0aGlzLnZjUmVmLFxyXG4gICAgICBjb250ZXh0OiBpbmZvLFxyXG4gICAgICBmdWxsc2NyZWVuOiBmYWxzZSxcclxuICAgIH07XHJcblxyXG4gICAgdGhpcy5tb2RhbFNlcnZpY2Uuc2hvd01vZGFsKEluZm9Nb2RhbENvbXBvbmVudCwgb3B0aW9ucykudGhlbigoKSA9PiB7XHJcbiAgICAgIC8vIG1vZGFsIGNsb3NlZCwgcmUtZW5hYmxlIHRoZSBiYWNrIGdlc3R1cmVcclxuICAgICAgaWYgKGRyYXdlci5pb3MpIHtcclxuICAgICAgICBkcmF3ZXIuaW9zLmF0dGFjaERyYXdlclRvV2luZG93KCk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxufSJdfQ==