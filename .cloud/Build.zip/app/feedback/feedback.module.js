Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var feedback_routing_module_1 = require("./feedback-routing.module");
var feedback_component_1 = require("./feedback.component");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var FeedbackModule = (function () {
    function FeedbackModule() {
    }
    FeedbackModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                feedback_routing_module_1.FeedbackRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
            ],
            declarations: [
                feedback_component_1.FeedbackComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], FeedbackModule);
    return FeedbackModule;
}());
exports.FeedbackModule = FeedbackModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmVlZGJhY2subW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmVlZGJhY2subW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSxzQ0FBMkQ7QUFDM0Qsc0RBQXVFO0FBRXZFLHFFQUFrRTtBQUNsRSwyREFBeUQ7QUFDekQsdUVBQThEO0FBZTlEO0lBQUE7SUFBOEIsQ0FBQztJQUFsQixjQUFjO1FBYjFCLGVBQVEsQ0FBQztZQUNSLE9BQU8sRUFBRTtnQkFDUCxpQ0FBd0I7Z0JBQ3hCLCtDQUFxQjtnQkFDckIsNkNBQWlCO2FBQ2xCO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLHNDQUFpQjthQUNsQjtZQUNELE9BQU8sRUFBRTtnQkFDUCx1QkFBZ0I7YUFDakI7U0FDRixDQUFDO09BQ1csY0FBYyxDQUFJO0lBQUQscUJBQUM7Q0FBQSxBQUEvQixJQUErQjtBQUFsQix3Q0FBYyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nTW9kdWxlLCBOT19FUlJPUlNfU0NIRU1BIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgTmF0aXZlU2NyaXB0Q29tbW9uTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2NvbW1vblwiO1xyXG5cclxuaW1wb3J0IHsgRmVlZGJhY2tSb3V0aW5nTW9kdWxlIH0gZnJvbSBcIi4vZmVlZGJhY2stcm91dGluZy5tb2R1bGVcIjtcclxuaW1wb3J0IHsgRmVlZGJhY2tDb21wb25lbnQgfSBmcm9tIFwiLi9mZWVkYmFjay5jb21wb25lbnRcIjtcclxuaW1wb3J0IHsgVE5TRm9udEljb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LW5neC1mb250aWNvblwiO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXHJcbiAgICBGZWVkYmFja1JvdXRpbmdNb2R1bGUsXHJcbiAgICBUTlNGb250SWNvbk1vZHVsZSxcclxuICBdLFxyXG4gIGRlY2xhcmF0aW9uczogW1xyXG4gICAgRmVlZGJhY2tDb21wb25lbnRcclxuICBdLFxyXG4gIHNjaGVtYXM6IFtcclxuICAgIE5PX0VSUk9SU19TQ0hFTUFcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBGZWVkYmFja01vZHVsZSB7IH1cclxuIl19