Object.defineProperty(exports, "__esModule", { value: true });
var nativescript_feedback_1 = require("nativescript-feedback");
var color_1 = require("tns-core-modules/color");
var FeedbackHelper = (function () {
    function FeedbackHelper() {
        this.feedback = new nativescript_feedback_1.Feedback();
    }
    FeedbackHelper.prototype.showSuccess = function () {
        this.feedback.success({
            title: "Peek-a-boo!",
            message: "Sorry. I will dismiss myself after 2.5 seconds.",
            duration: 2500,
            onTap: function () {
                console.log("showSuccess tapped");
            }
        });
    };
    FeedbackHelper.prototype.showSuccessAltColors = function () {
        this.feedback.show({
            title: "Custom colors :)",
            titleColor: new color_1.Color("black"),
            message: "Custom text colors and background color.",
            messageColor: new color_1.Color("#e5f5f8"),
            duration: 2500,
            type: nativescript_feedback_1.FeedbackType.Success,
            backgroundColor: new color_1.Color("lightskyblue"),
            onTap: function () {
                console.log("showSuccessAltColor tapped");
            }
        });
    };
    FeedbackHelper.prototype.showInfo = function () {
        this.feedback.show({
            title: "Public Service Announcement",
            message: "{N}ativeScript ROCKS!",
            duration: 2500,
            type: nativescript_feedback_1.FeedbackType.Info,
            onTap: function () {
                console.log("showInfo tapped");
            }
        });
    };
    FeedbackHelper.prototype.showWarning = function () {
        this.feedback.show({
            message: "This one doesn't have a title, but a very long message so this baby will wrap. Showing off multi-line feedback. Woohoo!",
            duration: 4000,
            position: nativescript_feedback_1.FeedbackPosition.Top,
            type: nativescript_feedback_1.FeedbackType.Warning,
            onTap: function () {
                console.log("showWarning tapped");
            }
        });
    };
    FeedbackHelper.prototype.showTitleOnly = function () {
        this.feedback.show({
            title: "Title only, not even an icon. Sad.",
            duration: 2000,
            onTap: function () {
                console.log("showMessageOnly tapped");
            }
        });
    };
    FeedbackHelper.prototype.showCustomIcon = function () {
        this.feedback.show({
            title: "Thumbs up!",
            message: "Custom colors and icon. Loaded from the App_Resources folder. And this one has a lot of text as well, so the duration needs to be a bit longer and stuff.",
            duration: 6000,
            backgroundColor: new color_1.Color("yellowgreen"),
            icon: "thumbsup",
            onTap: function () {
                console.log("showCustomIcon tapped");
            }
        });
    };
    FeedbackHelper.prototype.showError = function () {
        this.feedback.show({
            title: "The error title",
            message: "Not too long a text here. But it could be..",
            duration: 1000,
            type: nativescript_feedback_1.FeedbackType.Error,
            onTap: function () {
                console.log("showError tapped");
            }
        });
    };
    FeedbackHelper.prototype.showErrorBottom = function () {
        this.feedback.show({
            title: "The title",
            message: "A very long message so this baby will wrap. Showing off multi-line feedback. Woohoo!",
            duration: 5000,
            position: nativescript_feedback_1.FeedbackPosition.Bottom,
            type: nativescript_feedback_1.FeedbackType.Error,
            onTap: function () {
                console.log("showErrorBottom tapped");
            }
        });
    };
    FeedbackHelper.prototype.dismiss = function () {
        this.feedback.hide();
    };
    return FeedbackHelper;
}());
exports.FeedbackHelper = FeedbackHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmVlZGJhY2staGVscGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmVlZGJhY2staGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSwrREFBaUY7QUFDakYsZ0RBQStDO0FBRS9DO0lBR0U7UUFDRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksZ0NBQVEsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCxvQ0FBVyxHQUFYO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7WUFDcEIsS0FBSyxFQUFFLGFBQWE7WUFDcEIsT0FBTyxFQUFFLGlEQUFpRDtZQUMxRCxRQUFRLEVBQUUsSUFBSTtZQUVkLEtBQUssRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDcEMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCw2Q0FBb0IsR0FBcEI7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztZQUNqQixLQUFLLEVBQUUsa0JBQWtCO1lBQ3pCLFVBQVUsRUFBRSxJQUFJLGFBQUssQ0FBQyxPQUFPLENBQUM7WUFDOUIsT0FBTyxFQUFFLDBDQUEwQztZQUNuRCxZQUFZLEVBQUUsSUFBSSxhQUFLLENBQUMsU0FBUyxDQUFDO1lBQ2xDLFFBQVEsRUFBRSxJQUFJO1lBQ2QsSUFBSSxFQUFFLG9DQUFZLENBQUMsT0FBTztZQUMxQixlQUFlLEVBQUUsSUFBSSxhQUFLLENBQUMsY0FBYyxDQUFDO1lBQzFDLEtBQUssRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixDQUFDLENBQUM7WUFDNUMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxpQ0FBUSxHQUFSO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDakIsS0FBSyxFQUFFLDZCQUE2QjtZQUNwQyxPQUFPLEVBQUUsdUJBQXVCO1lBQ2hDLFFBQVEsRUFBRSxJQUFJO1lBQ2QsSUFBSSxFQUFFLG9DQUFZLENBQUMsSUFBSTtZQUN2QixLQUFLLEVBQUU7Z0JBQ0wsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQ2pDLENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsb0NBQVcsR0FBWDtRQUNFLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDO1lBRWpCLE9BQU8sRUFBRSx5SEFBeUg7WUFDbEksUUFBUSxFQUFFLElBQUk7WUFDZCxRQUFRLEVBQUUsd0NBQWdCLENBQUMsR0FBRztZQUM5QixJQUFJLEVBQUUsb0NBQVksQ0FBQyxPQUFPO1lBQzFCLEtBQUssRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUM7WUFDcEMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxzQ0FBYSxHQUFiO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDakIsS0FBSyxFQUFFLG9DQUFvQztZQUMzQyxRQUFRLEVBQUUsSUFBSTtZQUNkLEtBQUssRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7WUFDeEMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCx1Q0FBYyxHQUFkO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDakIsS0FBSyxFQUFFLFlBQVk7WUFDbkIsT0FBTyxFQUFFLDJKQUEySjtZQUNwSyxRQUFRLEVBQUUsSUFBSTtZQUNkLGVBQWUsRUFBRSxJQUFJLGFBQUssQ0FBQyxhQUFhLENBQUM7WUFDekMsSUFBSSxFQUFFLFVBQVU7WUFDaEIsS0FBSyxFQUFFO2dCQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQztZQUN2QyxDQUFDO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGtDQUFTLEdBQVQ7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQztZQUNqQixLQUFLLEVBQUUsaUJBQWlCO1lBQ3hCLE9BQU8sRUFBRSw2Q0FBNkM7WUFDdEQsUUFBUSxFQUFFLElBQUk7WUFDZCxJQUFJLEVBQUUsb0NBQVksQ0FBQyxLQUFLO1lBQ3hCLEtBQUssRUFBRTtnQkFDTCxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDbEMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCx3Q0FBZSxHQUFmO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDakIsS0FBSyxFQUFFLFdBQVc7WUFDbEIsT0FBTyxFQUFFLHNGQUFzRjtZQUMvRixRQUFRLEVBQUUsSUFBSTtZQUNkLFFBQVEsRUFBRSx3Q0FBZ0IsQ0FBQyxNQUFNO1lBQ2pDLElBQUksRUFBRSxvQ0FBWSxDQUFDLEtBQUs7WUFDeEIsS0FBSyxFQUFFO2dCQUNMLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztZQUN4QyxDQUFDO1NBQ0YsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELGdDQUFPLEdBQVA7UUFDRSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ3ZCLENBQUM7SUFDSCxxQkFBQztBQUFELENBQUMsQUE5R0QsSUE4R0M7QUE5R1ksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBGZWVkYmFjaywgRmVlZGJhY2tQb3NpdGlvbiwgRmVlZGJhY2tUeXBlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1mZWVkYmFja1wiO1xyXG5pbXBvcnQgeyBDb2xvciB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL2NvbG9yXCI7XHJcblxyXG5leHBvcnQgY2xhc3MgRmVlZGJhY2tIZWxwZXIge1xyXG4gIHByaXZhdGUgZmVlZGJhY2s6IEZlZWRiYWNrO1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMuZmVlZGJhY2sgPSBuZXcgRmVlZGJhY2soKTtcclxuICB9XHJcblxyXG4gIHNob3dTdWNjZXNzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5mZWVkYmFjay5zdWNjZXNzKHtcclxuICAgICAgdGl0bGU6IFwiUGVlay1hLWJvbyFcIixcclxuICAgICAgbWVzc2FnZTogXCJTb3JyeS4gSSB3aWxsIGRpc21pc3MgbXlzZWxmIGFmdGVyIDIuNSBzZWNvbmRzLlwiLFxyXG4gICAgICBkdXJhdGlvbjogMjUwMCxcclxuICAgICAgLy8gdHlwZTogRmVlZGJhY2tUeXBlLlN1Y2Nlc3MsIC8vIG5vIG5lZWQgdG8gc3BlY2lmeSB3aGVuIHVzaW5nICdzdWNjZXNzJyBpbnN0ZWFkIG9mICdzaG93J1xyXG4gICAgICBvblRhcDogKCkgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwic2hvd1N1Y2Nlc3MgdGFwcGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHNob3dTdWNjZXNzQWx0Q29sb3JzKCk6IHZvaWQge1xyXG4gICAgdGhpcy5mZWVkYmFjay5zaG93KHtcclxuICAgICAgdGl0bGU6IFwiQ3VzdG9tIGNvbG9ycyA6KVwiLFxyXG4gICAgICB0aXRsZUNvbG9yOiBuZXcgQ29sb3IoXCJibGFja1wiKSxcclxuICAgICAgbWVzc2FnZTogXCJDdXN0b20gdGV4dCBjb2xvcnMgYW5kIGJhY2tncm91bmQgY29sb3IuXCIsXHJcbiAgICAgIG1lc3NhZ2VDb2xvcjogbmV3IENvbG9yKFwiI2U1ZjVmOFwiKSxcclxuICAgICAgZHVyYXRpb246IDI1MDAsXHJcbiAgICAgIHR5cGU6IEZlZWRiYWNrVHlwZS5TdWNjZXNzLFxyXG4gICAgICBiYWNrZ3JvdW5kQ29sb3I6IG5ldyBDb2xvcihcImxpZ2h0c2t5Ymx1ZVwiKSxcclxuICAgICAgb25UYXA6ICgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcInNob3dTdWNjZXNzQWx0Q29sb3IgdGFwcGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHNob3dJbmZvKCk6IHZvaWQge1xyXG4gICAgdGhpcy5mZWVkYmFjay5zaG93KHtcclxuICAgICAgdGl0bGU6IFwiUHVibGljIFNlcnZpY2UgQW5ub3VuY2VtZW50XCIsXHJcbiAgICAgIG1lc3NhZ2U6IFwie059YXRpdmVTY3JpcHQgUk9DS1MhXCIsXHJcbiAgICAgIGR1cmF0aW9uOiAyNTAwLFxyXG4gICAgICB0eXBlOiBGZWVkYmFja1R5cGUuSW5mbyxcclxuICAgICAgb25UYXA6ICgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcInNob3dJbmZvIHRhcHBlZFwiKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzaG93V2FybmluZygpOiB2b2lkIHtcclxuICAgIHRoaXMuZmVlZGJhY2suc2hvdyh7XHJcbiAgICAgIC8vIHRpdGxlOiBcIlRoZSB3YXJuaW5nIHRpdGxlXCIsXHJcbiAgICAgIG1lc3NhZ2U6IFwiVGhpcyBvbmUgZG9lc24ndCBoYXZlIGEgdGl0bGUsIGJ1dCBhIHZlcnkgbG9uZyBtZXNzYWdlIHNvIHRoaXMgYmFieSB3aWxsIHdyYXAuIFNob3dpbmcgb2ZmIG11bHRpLWxpbmUgZmVlZGJhY2suIFdvb2hvbyFcIixcclxuICAgICAgZHVyYXRpb246IDQwMDAsXHJcbiAgICAgIHBvc2l0aW9uOiBGZWVkYmFja1Bvc2l0aW9uLlRvcCxcclxuICAgICAgdHlwZTogRmVlZGJhY2tUeXBlLldhcm5pbmcsXHJcbiAgICAgIG9uVGFwOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzaG93V2FybmluZyB0YXBwZWRcIik7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgc2hvd1RpdGxlT25seSgpOiB2b2lkIHtcclxuICAgIHRoaXMuZmVlZGJhY2suc2hvdyh7XHJcbiAgICAgIHRpdGxlOiBcIlRpdGxlIG9ubHksIG5vdCBldmVuIGFuIGljb24uIFNhZC5cIixcclxuICAgICAgZHVyYXRpb246IDIwMDAsXHJcbiAgICAgIG9uVGFwOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzaG93TWVzc2FnZU9ubHkgdGFwcGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHNob3dDdXN0b21JY29uKCk6IHZvaWQge1xyXG4gICAgdGhpcy5mZWVkYmFjay5zaG93KHtcclxuICAgICAgdGl0bGU6IFwiVGh1bWJzIHVwIVwiLFxyXG4gICAgICBtZXNzYWdlOiBcIkN1c3RvbSBjb2xvcnMgYW5kIGljb24uIExvYWRlZCBmcm9tIHRoZSBBcHBfUmVzb3VyY2VzIGZvbGRlci4gQW5kIHRoaXMgb25lIGhhcyBhIGxvdCBvZiB0ZXh0IGFzIHdlbGwsIHNvIHRoZSBkdXJhdGlvbiBuZWVkcyB0byBiZSBhIGJpdCBsb25nZXIgYW5kIHN0dWZmLlwiLFxyXG4gICAgICBkdXJhdGlvbjogNjAwMCxcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBuZXcgQ29sb3IoXCJ5ZWxsb3dncmVlblwiKSxcclxuICAgICAgaWNvbjogXCJ0aHVtYnN1cFwiLCAvLyBpbiBBcHBfUmVzb3VyY2VzL3BsYXRmb3JtIGZvbGRlcnNcclxuICAgICAgb25UYXA6ICgpID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcInNob3dDdXN0b21JY29uIHRhcHBlZFwiKTtcclxuICAgICAgfVxyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBzaG93RXJyb3IoKTogdm9pZCB7XHJcbiAgICB0aGlzLmZlZWRiYWNrLnNob3coe1xyXG4gICAgICB0aXRsZTogXCJUaGUgZXJyb3IgdGl0bGVcIixcclxuICAgICAgbWVzc2FnZTogXCJOb3QgdG9vIGxvbmcgYSB0ZXh0IGhlcmUuIEJ1dCBpdCBjb3VsZCBiZS4uXCIsXHJcbiAgICAgIGR1cmF0aW9uOiAxMDAwLFxyXG4gICAgICB0eXBlOiBGZWVkYmFja1R5cGUuRXJyb3IsXHJcbiAgICAgIG9uVGFwOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzaG93RXJyb3IgdGFwcGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHNob3dFcnJvckJvdHRvbSgpOiB2b2lkIHtcclxuICAgIHRoaXMuZmVlZGJhY2suc2hvdyh7XHJcbiAgICAgIHRpdGxlOiBcIlRoZSB0aXRsZVwiLFxyXG4gICAgICBtZXNzYWdlOiBcIkEgdmVyeSBsb25nIG1lc3NhZ2Ugc28gdGhpcyBiYWJ5IHdpbGwgd3JhcC4gU2hvd2luZyBvZmYgbXVsdGktbGluZSBmZWVkYmFjay4gV29vaG9vIVwiLFxyXG4gICAgICBkdXJhdGlvbjogNTAwMCxcclxuICAgICAgcG9zaXRpb246IEZlZWRiYWNrUG9zaXRpb24uQm90dG9tLFxyXG4gICAgICB0eXBlOiBGZWVkYmFja1R5cGUuRXJyb3IsXHJcbiAgICAgIG9uVGFwOiAoKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJzaG93RXJyb3JCb3R0b20gdGFwcGVkXCIpO1xyXG4gICAgICB9XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIGRpc21pc3MoKTogdm9pZCB7XHJcbiAgICB0aGlzLmZlZWRiYWNrLmhpZGUoKTtcclxuICB9XHJcbn0iXX0=