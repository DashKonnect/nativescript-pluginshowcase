Object.defineProperty(exports, "__esModule", { value: true });
var ToastHelper = (function () {
    function ToastHelper(toastService) {
        this.toastService = toastService;
    }
    ToastHelper.prototype.showShort = function () {
        this.toastService.show("This message disappears quickly");
    };
    ToastHelper.prototype.showLong = function () {
        this.toastService.show("This message sticks a bit longer", true);
    };
    return ToastHelper;
}());
exports.ToastHelper = ToastHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3QtaGVscGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsidG9hc3QtaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFFQTtJQUVFLHFCQUFvQixZQUEwQjtRQUExQixpQkFBWSxHQUFaLFlBQVksQ0FBYztJQUM5QyxDQUFDO0lBRUQsK0JBQVMsR0FBVDtRQUNFLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUM7SUFDNUQsQ0FBQztJQUVELDhCQUFRLEdBQVI7UUFDRSxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxrQ0FBa0MsRUFBRSxJQUFJLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBQ0gsa0JBQUM7QUFBRCxDQUFDLEFBWkQsSUFZQztBQVpZLGtDQUFXIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVG9hc3RTZXJ2aWNlIH0gZnJvbSBcIi4uLy4uL3NlcnZpY2VzL3RvYXN0LnNlcnZpY2VcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBUb2FzdEhlbHBlciB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgdG9hc3RTZXJ2aWNlOiBUb2FzdFNlcnZpY2UpIHtcclxuICB9XHJcblxyXG4gIHNob3dTaG9ydCgpOiB2b2lkIHtcclxuICAgIHRoaXMudG9hc3RTZXJ2aWNlLnNob3coXCJUaGlzIG1lc3NhZ2UgZGlzYXBwZWFycyBxdWlja2x5XCIpO1xyXG4gIH1cclxuXHJcbiAgc2hvd0xvbmcoKTogdm9pZCB7XHJcbiAgICB0aGlzLnRvYXN0U2VydmljZS5zaG93KFwiVGhpcyBtZXNzYWdlIHN0aWNrcyBhIGJpdCBsb25nZXJcIiwgdHJ1ZSk7XHJcbiAgfVxyXG59Il19