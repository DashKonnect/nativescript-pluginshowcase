Object.defineProperty(exports, "__esModule", { value: true });
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var LocalNotifications = require("nativescript-local-notifications");
var LocalNotificationsHelper = (function () {
    function LocalNotificationsHelper() {
    }
    LocalNotificationsHelper.prototype.showWithSound = function () {
        LocalNotifications.schedule([{
                id: 1,
                title: 'Sound & Badge',
                body: 'Who needs a push service anyway?',
                badge: 1,
                at: new Date(new Date().getTime() + (5 * 1000))
            }]);
        LocalNotifications.addOnMessageReceivedCallback(function (data) {
            dialogs_1.alert({
                title: "Local Notificartion received",
                message: "id: '" + data.id + "', title: '" + data.title + "'.",
                okButtonText: "Roger that"
            });
        });
    };
    LocalNotificationsHelper.prototype.continuous = function () {
        LocalNotifications.schedule([{
                id: 2,
                title: 'Cancel me, quickly!',
                body: 'Who thought this would be a good idea!?',
                interval: 'minute',
                sound: null,
                at: new Date(new Date().getTime() + (5 * 1000)),
            }]);
    };
    LocalNotificationsHelper.prototype.cancelAll = function () {
        LocalNotifications.cancelAll();
    };
    return LocalNotificationsHelper;
}());
exports.LocalNotificationsHelper = LocalNotificationsHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9jYWxub3RpZmljYXRpb25zLWhlbHBlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbImxvY2Fsbm90aWZpY2F0aW9ucy1oZWxwZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBLHVEQUFvRDtBQUNwRCxxRUFBdUU7QUFFdkU7SUFFRTtJQUNBLENBQUM7SUFFRCxnREFBYSxHQUFiO1FBQ0Usa0JBQWtCLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQzNCLEVBQUUsRUFBRSxDQUFDO2dCQUNMLEtBQUssRUFBRSxlQUFlO2dCQUN0QixJQUFJLEVBQUUsa0NBQWtDO2dCQUN4QyxLQUFLLEVBQUUsQ0FBQztnQkFDUixFQUFFLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQzthQUNoRCxDQUFDLENBQUMsQ0FBQztRQUdKLGtCQUFrQixDQUFDLDRCQUE0QixDQUFDLFVBQUEsSUFBSTtZQUNsRCxlQUFLLENBQUM7Z0JBQ0osS0FBSyxFQUFFLDhCQUE4QjtnQkFDckMsT0FBTyxFQUFFLFVBQVEsSUFBSSxDQUFDLEVBQUUsbUJBQWMsSUFBSSxDQUFDLEtBQUssT0FBSTtnQkFDcEQsWUFBWSxFQUFFLFlBQVk7YUFDM0IsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsNkNBQVUsR0FBVjtRQUNFLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMzQixFQUFFLEVBQUUsQ0FBQztnQkFDTCxLQUFLLEVBQUUscUJBQXFCO2dCQUM1QixJQUFJLEVBQUUseUNBQXlDO2dCQUMvQyxRQUFRLEVBQUUsUUFBUTtnQkFDbEIsS0FBSyxFQUFFLElBQUk7Z0JBQ1gsRUFBRSxFQUFFLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxFQUFFLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUM7YUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFDTixDQUFDO0lBRUQsNENBQVMsR0FBVDtRQUNFLGtCQUFrQixDQUFDLFNBQVMsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFDSCwrQkFBQztBQUFELENBQUMsQUF0Q0QsSUFzQ0M7QUF0Q1ksNERBQXdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYWxlcnQgfSBmcm9tIFwidG5zLWNvcmUtbW9kdWxlcy91aS9kaWFsb2dzXCI7XHJcbmltcG9ydCAqIGFzIExvY2FsTm90aWZpY2F0aW9ucyBmcm9tIFwibmF0aXZlc2NyaXB0LWxvY2FsLW5vdGlmaWNhdGlvbnNcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBMb2NhbE5vdGlmaWNhdGlvbnNIZWxwZXIge1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICB9XHJcblxyXG4gIHNob3dXaXRoU291bmQoKTogdm9pZCB7XHJcbiAgICBMb2NhbE5vdGlmaWNhdGlvbnMuc2NoZWR1bGUoW3tcclxuICAgICAgaWQ6IDEsXHJcbiAgICAgIHRpdGxlOiAnU291bmQgJiBCYWRnZScsXHJcbiAgICAgIGJvZHk6ICdXaG8gbmVlZHMgYSBwdXNoIHNlcnZpY2UgYW55d2F5PycsXHJcbiAgICAgIGJhZGdlOiAxLFxyXG4gICAgICBhdDogbmV3IERhdGUobmV3IERhdGUoKS5nZXRUaW1lKCkgKyAoNSAqIDEwMDApKSAvLyA1IHNlY29uZHMgZnJvbSBub3dcclxuICAgIH1dKTtcclxuXHJcbiAgICAvLyBhZGRpbmcgYSBoYW5kbGVyLCBzbyB3ZSBjYW4gZG8gc29tZXRoaW5nIHdpdGggdGhlIHJlY2VpdmVkIG5vdGlmaWNhdGlvbi4uIGluIHRoaXMgY2FzZSBhbiBhbGVydFxyXG4gICAgTG9jYWxOb3RpZmljYXRpb25zLmFkZE9uTWVzc2FnZVJlY2VpdmVkQ2FsbGJhY2soZGF0YSA9PiB7XHJcbiAgICAgIGFsZXJ0KHtcclxuICAgICAgICB0aXRsZTogXCJMb2NhbCBOb3RpZmljYXJ0aW9uIHJlY2VpdmVkXCIsXHJcbiAgICAgICAgbWVzc2FnZTogYGlkOiAnJHtkYXRhLmlkfScsIHRpdGxlOiAnJHtkYXRhLnRpdGxlfScuYCxcclxuICAgICAgICBva0J1dHRvblRleHQ6IFwiUm9nZXIgdGhhdFwiXHJcbiAgICAgIH0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjb250aW51b3VzKCk6IHZvaWQge1xyXG4gICAgTG9jYWxOb3RpZmljYXRpb25zLnNjaGVkdWxlKFt7XHJcbiAgICAgIGlkOiAyLFxyXG4gICAgICB0aXRsZTogJ0NhbmNlbCBtZSwgcXVpY2tseSEnLFxyXG4gICAgICBib2R5OiAnV2hvIHRob3VnaHQgdGhpcyB3b3VsZCBiZSBhIGdvb2QgaWRlYSE/JyxcclxuICAgICAgaW50ZXJ2YWw6ICdtaW51dGUnLFxyXG4gICAgICBzb3VuZDogbnVsbCxcclxuICAgICAgYXQ6IG5ldyBEYXRlKG5ldyBEYXRlKCkuZ2V0VGltZSgpICsgKDUgKiAxMDAwKSksIC8vIDUgc2Vjb25kcyBmcm9tIG5vd1xyXG4gICAgfV0pO1xyXG4gIH1cclxuXHJcbiAgY2FuY2VsQWxsKCk6IHZvaWQge1xyXG4gICAgTG9jYWxOb3RpZmljYXRpb25zLmNhbmNlbEFsbCgpO1xyXG4gIH1cclxufSJdfQ==