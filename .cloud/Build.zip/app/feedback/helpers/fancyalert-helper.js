Object.defineProperty(exports, "__esModule", { value: true });
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var nativescript_fancyalert_1 = require("nativescript-fancyalert");
var FancyalertHelper = (function () {
    function FancyalertHelper() {
    }
    FancyalertHelper.prototype.showSuccess = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showSuccess("Success!", "You were able to press a button. Impressive stuff mate!", "Thanks :)");
    };
    FancyalertHelper.prototype.showInfo = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showInfo("Info", "1 + 1 = 2", "Correct!");
    };
    FancyalertHelper.prototype.showNotice = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showNotice("Notice", "This year Christmas is december 25 & 26.", "Well duh!");
    };
    FancyalertHelper.prototype.showWarning = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showError("Warning!", "There's something between your teeth.", "Uhm, thanks..");
    };
    FancyalertHelper.prototype.showError = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showError("Uh oh!", "Somebody made a boo-boo..", "I'll clean it up..");
    };
    FancyalertHelper.prototype.showWaiting = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showWaiting("Hang on", "This only takes 5 seconds..", "I can't wait!", 5);
    };
    FancyalertHelper.prototype.showTimer = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showCustomButtonTimer(0, true, undefined, undefined, 'Mission Impossible', "This will self-destruct in 5 seconds.", 'Ok');
    };
    FancyalertHelper.prototype.showTextField = function () {
        var initialValue = null;
        nativescript_fancyalert_1.TNSFancyAlert.showTextField('Enter your name', initialValue, new nativescript_fancyalert_1.TNSFancyAlertButton({
            label: "Done",
            action: function (value) {
                dialogs_1.alert({
                    title: "User entered:",
                    message: value,
                    okButtonText: "Correct ;)"
                });
            }
        }), undefined, undefined, "What's you name", ".. if you have one", "Dismiss");
    };
    FancyalertHelper.prototype.showSwitch = function () {
        nativescript_fancyalert_1.TNSFancyAlert.showSwitch("Don't ask me again", '#58B136', new nativescript_fancyalert_1.TNSFancyAlertButton({
            label: "Save",
            action: function (isSelected) {
                console.log("Don't ask again was selected? " + isSelected);
            }
        }), 'switch.png', '#B3714F', 'Need a switch?', "It can be useful.", 'Got it.');
    };
    return FancyalertHelper;
}());
exports.FancyalertHelper = FancyalertHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZmFuY3lhbGVydC1oZWxwZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJmYW5jeWFsZXJ0LWhlbHBlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsdURBQW9EO0FBQ3BELG1FQUE2RTtBQUU3RTtJQUVFO0lBQ0EsQ0FBQztJQUVELHNDQUFXLEdBQVg7UUFDRSx1Q0FBYSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUseURBQXlELEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDaEgsQ0FBQztJQUVELG1DQUFRLEdBQVI7UUFDRSx1Q0FBYSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0lBQzFELENBQUM7SUFFRCxxQ0FBVSxHQUFWO1FBQ0UsdUNBQWEsQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLDBDQUEwQyxFQUFFLFdBQVcsQ0FBQyxDQUFDO0lBQzlGLENBQUM7SUFFRCxzQ0FBVyxHQUFYO1FBQ0UsdUNBQWEsQ0FBQyxTQUFTLENBQUMsVUFBVSxFQUFFLHVDQUF1QyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQ2hHLENBQUM7SUFFRCxvQ0FBUyxHQUFUO1FBQ0UsdUNBQWEsQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLDJCQUEyQixFQUFFLG9CQUFvQixDQUFDLENBQUM7SUFDdkYsQ0FBQztJQUVELHNDQUFXLEdBQVg7UUFDRSx1Q0FBYSxDQUFDLFdBQVcsQ0FBQyxTQUFTLEVBQUUsNkJBQTZCLEVBQUUsZUFBZSxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQzFGLENBQUM7SUFFRCxvQ0FBUyxHQUFUO1FBQ0UsdUNBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsb0JBQW9CLEVBQUUsdUNBQXVDLEVBQUUsSUFBSSxDQUFDLENBQUM7SUFDMUksQ0FBQztJQUVELHdDQUFhLEdBQWI7UUFDRSxJQUFJLFlBQVksR0FBRyxJQUFJLENBQUM7UUFDeEIsdUNBQWEsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsWUFBWSxFQUFFLElBQUksNkNBQW1CLENBQUM7WUFDbkYsS0FBSyxFQUFFLE1BQU07WUFDYixNQUFNLEVBQUUsVUFBQyxLQUFVO2dCQUNqQixlQUFLLENBQUM7b0JBQ0osS0FBSyxFQUFFLGVBQWU7b0JBQ3RCLE9BQU8sRUFBRSxLQUFLO29CQUNkLFlBQVksRUFBRSxZQUFZO2lCQUMzQixDQUFDLENBQUM7WUFDTCxDQUFDO1NBQ0YsQ0FBQyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsaUJBQWlCLEVBQUUsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDaEYsQ0FBQztJQUVELHFDQUFVLEdBQVY7UUFDRSx1Q0FBYSxDQUFDLFVBQVUsQ0FBQyxvQkFBb0IsRUFBRSxTQUFTLEVBQUUsSUFBSSw2Q0FBbUIsQ0FBQztZQUNoRixLQUFLLEVBQUUsTUFBTTtZQUNiLE1BQU0sRUFBRSxVQUFDLFVBQW1CO2dCQUMxQixPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFpQyxVQUFZLENBQUMsQ0FBQztZQUM3RCxDQUFDO1NBQ0YsQ0FBQyxFQUFFLFlBQVksRUFBRSxTQUFTLEVBQUUsZ0JBQWdCLEVBQUUsbUJBQW1CLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDakYsQ0FBQztJQUNILHVCQUFDO0FBQUQsQ0FBQyxBQXZERCxJQXVEQztBQXZEWSw0Q0FBZ0IiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhbGVydCB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2RpYWxvZ3NcIjtcclxuaW1wb3J0IHsgVE5TRmFuY3lBbGVydCwgVE5TRmFuY3lBbGVydEJ1dHRvbiB9IGZyb20gXCJuYXRpdmVzY3JpcHQtZmFuY3lhbGVydFwiO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZhbmN5YWxlcnRIZWxwZXIge1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICB9XHJcblxyXG4gIHNob3dTdWNjZXNzKCk6IHZvaWQge1xyXG4gICAgVE5TRmFuY3lBbGVydC5zaG93U3VjY2VzcyhcIlN1Y2Nlc3MhXCIsIFwiWW91IHdlcmUgYWJsZSB0byBwcmVzcyBhIGJ1dHRvbi4gSW1wcmVzc2l2ZSBzdHVmZiBtYXRlIVwiLCBcIlRoYW5rcyA6KVwiKTtcclxuICB9XHJcblxyXG4gIHNob3dJbmZvKCk6IHZvaWQge1xyXG4gICAgVE5TRmFuY3lBbGVydC5zaG93SW5mbyhcIkluZm9cIiwgXCIxICsgMSA9IDJcIiwgXCJDb3JyZWN0IVwiKTtcclxuICB9XHJcblxyXG4gIHNob3dOb3RpY2UoKTogdm9pZCB7XHJcbiAgICBUTlNGYW5jeUFsZXJ0LnNob3dOb3RpY2UoXCJOb3RpY2VcIiwgXCJUaGlzIHllYXIgQ2hyaXN0bWFzIGlzIGRlY2VtYmVyIDI1ICYgMjYuXCIsIFwiV2VsbCBkdWghXCIpO1xyXG4gIH1cclxuXHJcbiAgc2hvd1dhcm5pbmcoKTogdm9pZCB7XHJcbiAgICBUTlNGYW5jeUFsZXJ0LnNob3dFcnJvcihcIldhcm5pbmchXCIsIFwiVGhlcmUncyBzb21ldGhpbmcgYmV0d2VlbiB5b3VyIHRlZXRoLlwiLCBcIlVobSwgdGhhbmtzLi5cIik7XHJcbiAgfVxyXG5cclxuICBzaG93RXJyb3IoKTogdm9pZCB7XHJcbiAgICBUTlNGYW5jeUFsZXJ0LnNob3dFcnJvcihcIlVoIG9oIVwiLCBcIlNvbWVib2R5IG1hZGUgYSBib28tYm9vLi5cIiwgXCJJJ2xsIGNsZWFuIGl0IHVwLi5cIik7XHJcbiAgfVxyXG5cclxuICBzaG93V2FpdGluZygpOiB2b2lkIHtcclxuICAgIFROU0ZhbmN5QWxlcnQuc2hvd1dhaXRpbmcoXCJIYW5nIG9uXCIsIFwiVGhpcyBvbmx5IHRha2VzIDUgc2Vjb25kcy4uXCIsIFwiSSBjYW4ndCB3YWl0IVwiLCA1KTtcclxuICB9XHJcblxyXG4gIHNob3dUaW1lcigpOiB2b2lkIHtcclxuICAgIFROU0ZhbmN5QWxlcnQuc2hvd0N1c3RvbUJ1dHRvblRpbWVyKDAsIHRydWUsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCAnTWlzc2lvbiBJbXBvc3NpYmxlJywgYFRoaXMgd2lsbCBzZWxmLWRlc3RydWN0IGluIDUgc2Vjb25kcy5gLCAnT2snKTtcclxuICB9XHJcblxyXG4gIHNob3dUZXh0RmllbGQoKTogdm9pZCB7XHJcbiAgICBsZXQgaW5pdGlhbFZhbHVlID0gbnVsbDtcclxuICAgIFROU0ZhbmN5QWxlcnQuc2hvd1RleHRGaWVsZCgnRW50ZXIgeW91ciBuYW1lJywgaW5pdGlhbFZhbHVlLCBuZXcgVE5TRmFuY3lBbGVydEJ1dHRvbih7XHJcbiAgICAgIGxhYmVsOiBcIkRvbmVcIixcclxuICAgICAgYWN0aW9uOiAodmFsdWU6IGFueSkgPT4ge1xyXG4gICAgICAgIGFsZXJ0KHtcclxuICAgICAgICAgIHRpdGxlOiBcIlVzZXIgZW50ZXJlZDpcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IHZhbHVlLFxyXG4gICAgICAgICAgb2tCdXR0b25UZXh0OiBcIkNvcnJlY3QgOylcIlxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICB9KSwgdW5kZWZpbmVkLCB1bmRlZmluZWQsIFwiV2hhdCdzIHlvdSBuYW1lXCIsIFwiLi4gaWYgeW91IGhhdmUgb25lXCIsIFwiRGlzbWlzc1wiKTtcclxuICB9XHJcblxyXG4gIHNob3dTd2l0Y2goKTogdm9pZCB7XHJcbiAgICBUTlNGYW5jeUFsZXJ0LnNob3dTd2l0Y2goXCJEb24ndCBhc2sgbWUgYWdhaW5cIiwgJyM1OEIxMzYnLCBuZXcgVE5TRmFuY3lBbGVydEJ1dHRvbih7XHJcbiAgICAgIGxhYmVsOiBcIlNhdmVcIixcclxuICAgICAgYWN0aW9uOiAoaXNTZWxlY3RlZDogYm9vbGVhbikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGBEb24ndCBhc2sgYWdhaW4gd2FzIHNlbGVjdGVkPyAke2lzU2VsZWN0ZWR9YCk7XHJcbiAgICAgIH1cclxuICAgIH0pLCAnc3dpdGNoLnBuZycsICcjQjM3MTRGJywgJ05lZWQgYSBzd2l0Y2g/JywgYEl0IGNhbiBiZSB1c2VmdWwuYCwgJ0dvdCBpdC4nKTtcclxuICB9XHJcbn0iXX0=