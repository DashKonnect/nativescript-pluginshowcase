Object.defineProperty(exports, "__esModule", { value: true });
var dialogs_1 = require("tns-core-modules/ui/dialogs");
var nativescript_snackbar_1 = require("nativescript-snackbar");
var SnackbarHelper = (function () {
    function SnackbarHelper() {
        this.snackbar = new nativescript_snackbar_1.SnackBar();
    }
    SnackbarHelper.prototype.showMessage = function () {
        this.snackbar.simple("Have a snack(bar)!");
    };
    SnackbarHelper.prototype.showAction = function () {
        var options = {
            actionText: "OK",
            actionTextColor: "#ff4081",
            snackText: "Press 'OK' to show a plain old alert",
            hideDelay: 5000
        };
        this.snackbar.action(options).then(function (args) {
            if (args.command === "Action") {
                dialogs_1.alert({
                    title: "Well hello there!",
                    message: "That Snackbar seems useful, right?",
                    okButtonText: "Uhm, I guess..",
                    cancelable: true
                });
            }
        });
    };
    SnackbarHelper.prototype.dismiss = function () {
        this.snackbar.dismiss().then(function () {
            console.log("Snackbar dimissed");
        });
    };
    return SnackbarHelper;
}());
exports.SnackbarHelper = SnackbarHelper;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic25hY2tiYXItaGVscGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsic25hY2tiYXItaGVscGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQSx1REFBb0Q7QUFDcEQsK0RBQWtFO0FBRWxFO0lBR0U7UUFDRSxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksZ0NBQVEsRUFBRSxDQUFDO0lBQ2pDLENBQUM7SUFFRCxvQ0FBVyxHQUFYO1FBQ0UsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBRUQsbUNBQVUsR0FBVjtRQUNFLElBQUksT0FBTyxHQUFvQjtZQUM3QixVQUFVLEVBQUUsSUFBSTtZQUNoQixlQUFlLEVBQUUsU0FBUztZQUMxQixTQUFTLEVBQUUsc0NBQXNDO1lBQ2pELFNBQVMsRUFBRSxJQUFJO1NBQ2hCLENBQUM7UUFFRixJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBQSxJQUFJO1lBQ3JDLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDOUIsZUFBSyxDQUFDO29CQUNKLEtBQUssRUFBRSxtQkFBbUI7b0JBQzFCLE9BQU8sRUFBRSxvQ0FBb0M7b0JBQzdDLFlBQVksRUFBRSxnQkFBZ0I7b0JBQzlCLFVBQVUsRUFBRSxJQUFJO2lCQUNqQixDQUFDLENBQUM7WUFDTCxDQUFDO1FBQ0gsQ0FBQyxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsZ0NBQU8sR0FBUDtRQUNFLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUMsSUFBSSxDQUFDO1lBQzNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUNuQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFDSCxxQkFBQztBQUFELENBQUMsQUFwQ0QsSUFvQ0M7QUFwQ1ksd0NBQWMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBhbGVydCB9IGZyb20gXCJ0bnMtY29yZS1tb2R1bGVzL3VpL2RpYWxvZ3NcIjtcclxuaW1wb3J0IHsgU25hY2tCYXIsIFNuYWNrQmFyT3B0aW9ucyB9IGZyb20gXCJuYXRpdmVzY3JpcHQtc25hY2tiYXJcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBTbmFja2JhckhlbHBlciB7XHJcbiAgcHJpdmF0ZSBzbmFja2JhcjogU25hY2tCYXI7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy5zbmFja2JhciA9IG5ldyBTbmFja0JhcigpO1xyXG4gIH1cclxuXHJcbiAgc2hvd01lc3NhZ2UoKTogdm9pZCB7XHJcbiAgICB0aGlzLnNuYWNrYmFyLnNpbXBsZShcIkhhdmUgYSBzbmFjayhiYXIpIVwiKTtcclxuICB9XHJcblxyXG4gIHNob3dBY3Rpb24oKSB7XHJcbiAgICBsZXQgb3B0aW9uczogU25hY2tCYXJPcHRpb25zID0ge1xyXG4gICAgICBhY3Rpb25UZXh0OiBcIk9LXCIsXHJcbiAgICAgIGFjdGlvblRleHRDb2xvcjogXCIjZmY0MDgxXCIsIC8vIEFuZHJvaWQgb25seVxyXG4gICAgICBzbmFja1RleHQ6IFwiUHJlc3MgJ09LJyB0byBzaG93IGEgcGxhaW4gb2xkIGFsZXJ0XCIsXHJcbiAgICAgIGhpZGVEZWxheTogNTAwMFxyXG4gICAgfTtcclxuXHJcbiAgICB0aGlzLnNuYWNrYmFyLmFjdGlvbihvcHRpb25zKS50aGVuKGFyZ3MgPT4ge1xyXG4gICAgICBpZiAoYXJncy5jb21tYW5kID09PSBcIkFjdGlvblwiKSB7XHJcbiAgICAgICAgYWxlcnQoe1xyXG4gICAgICAgICAgdGl0bGU6IFwiV2VsbCBoZWxsbyB0aGVyZSFcIixcclxuICAgICAgICAgIG1lc3NhZ2U6IFwiVGhhdCBTbmFja2JhciBzZWVtcyB1c2VmdWwsIHJpZ2h0P1wiLFxyXG4gICAgICAgICAgb2tCdXR0b25UZXh0OiBcIlVobSwgSSBndWVzcy4uXCIsXHJcbiAgICAgICAgICBjYW5jZWxhYmxlOiB0cnVlXHJcbiAgICAgICAgfSk7XHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgZGlzbWlzcygpIHtcclxuICAgIHRoaXMuc25hY2tiYXIuZGlzbWlzcygpLnRoZW4oKCkgPT4ge1xyXG4gICAgICBjb25zb2xlLmxvZyhcIlNuYWNrYmFyIGRpbWlzc2VkXCIpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59Il19