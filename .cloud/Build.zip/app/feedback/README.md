## Feedback

- [nativescript-fancyalert](https://github.com/NathanWalker/nativescript-fancyalert)
- [nativescript-feedback](https://github.com/EddyVerbruggen/nativescript-feedback)
- [nativescript-local-notifications](https://github.com/EddyVerbruggen/nativescript-local-notifications)
- [nativescript-snackbar](https://github.com/bradmartin/nativescript-snackbar)
- [nativescript-toast](https://github.com/TobiasHennig/nativescript-toast)

<img src="../../screenshots/themes/feedback.png" width="375px"/>