## App Icon

- [nativescript-app-icon-changer](https://github.com/EddyVerbruggen/nativescript-app-icon-changer)
- [nativescript-app-shortcuts](https://github.com/EddyVerbruggen/nativescript-app-shortcuts)

<img src="../../screenshots/themes/appicon.png" width="375px"/>