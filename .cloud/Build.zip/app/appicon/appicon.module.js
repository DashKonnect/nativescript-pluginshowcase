Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var common_1 = require("nativescript-angular/common");
var forms_1 = require("nativescript-angular/forms");
var nativescript_ngx_fonticon_1 = require("nativescript-ngx-fonticon");
var appicon_routing_module_1 = require("./appicon-routing.module");
var appicon_component_1 = require("./appicon.component");
var AppIconModule = (function () {
    function AppIconModule() {
    }
    AppIconModule = __decorate([
        core_1.NgModule({
            imports: [
                common_1.NativeScriptCommonModule,
                forms_1.NativeScriptFormsModule,
                appicon_routing_module_1.AppIconRoutingModule,
                nativescript_ngx_fonticon_1.TNSFontIconModule,
            ],
            declarations: [
                appicon_component_1.AppIconComponent
            ],
            schemas: [
                core_1.NO_ERRORS_SCHEMA
            ]
        })
    ], AppIconModule);
    return AppIconModule;
}());
exports.AppIconModule = AppIconModule;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwaWNvbi5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBpY29uLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQTJEO0FBQzNELHNEQUF1RTtBQUN2RSxvREFBcUU7QUFDckUsdUVBQThEO0FBQzlELG1FQUFnRTtBQUNoRSx5REFBdUQ7QUFnQnZEO0lBQUE7SUFBNkIsQ0FBQztJQUFqQixhQUFhO1FBZHpCLGVBQVEsQ0FBQztZQUNSLE9BQU8sRUFBRTtnQkFDUCxpQ0FBd0I7Z0JBQ3hCLCtCQUF1QjtnQkFDdkIsNkNBQW9CO2dCQUNwQiw2Q0FBaUI7YUFDbEI7WUFDRCxZQUFZLEVBQUU7Z0JBQ1osb0NBQWdCO2FBQ2pCO1lBQ0QsT0FBTyxFQUFFO2dCQUNQLHVCQUFnQjthQUNqQjtTQUNGLENBQUM7T0FDVyxhQUFhLENBQUk7SUFBRCxvQkFBQztDQUFBLEFBQTlCLElBQThCO0FBQWpCLHNDQUFhIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUsIE5PX0VSUk9SU19TQ0hFTUEgfSBmcm9tIFwiQGFuZ3VsYXIvY29yZVwiO1xyXG5pbXBvcnQgeyBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXIvY29tbW9uXCI7XHJcbmltcG9ydCB7IE5hdGl2ZVNjcmlwdEZvcm1zTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hbmd1bGFyL2Zvcm1zXCI7XHJcbmltcG9ydCB7IFROU0ZvbnRJY29uTW9kdWxlIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1uZ3gtZm9udGljb25cIjtcclxuaW1wb3J0IHsgQXBwSWNvblJvdXRpbmdNb2R1bGUgfSBmcm9tIFwiLi9hcHBpY29uLXJvdXRpbmcubW9kdWxlXCI7XHJcbmltcG9ydCB7IEFwcEljb25Db21wb25lbnQgfSBmcm9tIFwiLi9hcHBpY29uLmNvbXBvbmVudFwiO1xyXG5cclxuQE5nTW9kdWxlKHtcclxuICBpbXBvcnRzOiBbXHJcbiAgICBOYXRpdmVTY3JpcHRDb21tb25Nb2R1bGUsXHJcbiAgICBOYXRpdmVTY3JpcHRGb3Jtc01vZHVsZSxcclxuICAgIEFwcEljb25Sb3V0aW5nTW9kdWxlLFxyXG4gICAgVE5TRm9udEljb25Nb2R1bGUsXHJcbiAgXSxcclxuICBkZWNsYXJhdGlvbnM6IFtcclxuICAgIEFwcEljb25Db21wb25lbnRcclxuICBdLFxyXG4gIHNjaGVtYXM6IFtcclxuICAgIE5PX0VSUk9SU19TQ0hFTUFcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHBJY29uTW9kdWxlIHsgfVxyXG4iXX0=