Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var animations_1 = require("@angular/animations");
var abstract_menu_page_component_1 = require("../abstract-menu-page-component");
var menu_component_1 = require("../menu/menu.component");
var nativescript_angular_1 = require("nativescript-angular");
var plugin_info_1 = require("../shared/plugin-info");
var plugin_info_wrapper_1 = require("../shared/plugin-info-wrapper");
var nativescript_app_icon_changer_1 = require("nativescript-app-icon-changer");
var toast_service_1 = require("../services/toast.service");
var nativescript_app_shortcuts_1 = require("nativescript-app-shortcuts");
var AppIconComponent = (function (_super) {
    __extends(AppIconComponent, _super);
    function AppIconComponent(menuComponent, vcRef, modalService, toastService) {
        var _this = _super.call(this, menuComponent, vcRef, modalService) || this;
        _this.menuComponent = menuComponent;
        _this.vcRef = vcRef;
        _this.modalService = modalService;
        _this.toastService = toastService;
        _this.suppressAppIconChangedNotification = false;
        _this.appIconChanger = new nativescript_app_icon_changer_1.AppIconChanger();
        _this.appShortcuts = new nativescript_app_shortcuts_1.AppShortcuts();
        _this.appShortcuts.available().then(function (avail) { return _this.supportsAppShortcuts = avail; });
        return _this;
    }
    AppIconComponent.prototype.ngOnInit = function () {
    };
    AppIconComponent.prototype.addDeeplink = function () {
        var _this = this;
        this.appShortcuts.configureQuickActions([
            {
                type: "mapping",
                title: "Mapping",
                subtitle: "Deeplink to Mapping",
                iconType: this.isIOS ? 4 : null,
                iconTemplate: "maps"
            }
        ]).then(function () {
            _this.toastService.show("Close the app and press the app icon hard to see the new deeplink!", true);
        }, function (err) {
            _this.toastService.show("Error: " + err);
        });
    };
    AppIconComponent.prototype.removeDeeplink = function () {
        var _this = this;
        this.appShortcuts.configureQuickActions([]).then(function () {
            _this.toastService.show("Dynamic deeplink removed");
        }, function (err) {
            _this.toastService.show("Error: " + err);
        });
    };
    AppIconComponent.prototype.changeAppIcon = function (name) {
        var _this = this;
        this.appIconChanger.changeIcon({
            iconName: name,
            suppressUserNotification: this.suppressAppIconChangedNotification
        }).then(function () {
        }, function (error) {
            _this.toastService.show("Error code: " + error.code + ", Error message: " + error.message, true);
        });
    };
    AppIconComponent.prototype.getPluginInfo = function () {
        return new plugin_info_wrapper_1.PluginInfoWrapper("Fiddle with your app's home icon. Currently for iOS only.", Array.of(new plugin_info_1.PluginInfo("nativescript-app-shortcuts", "App Shortcuts", "https://github.com/EddyVerbruggen/nativescript-app-shortcuts", "Home Icon Actions for your NativeScript app."), new plugin_info_1.PluginInfo("nativescript-app-icon-changer", "App Icon Changer  🏠 🔁", "https://github.com/EddyVerbruggen/nativescript-app-icon-changer", "Change the homescreen icon of your NativeScript iOS app at runtime!")));
    };
    AppIconComponent = __decorate([
        core_1.Component({
            selector: "page-appicon",
            moduleId: module.id,
            templateUrl: "./appicon.component.html",
            styleUrls: ["appicon-common.css"],
            animations: [
                animations_1.trigger("from-bottom", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "translateY(0)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "translateY(20%)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1600ms 700ms ease-out")])
                ]),
                animations_1.trigger("fade-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0
                    })),
                    animations_1.transition("void => *", [animations_1.animate("800ms 2000ms ease-out")])
                ]),
                animations_1.trigger("scale-in", [
                    animations_1.state("in", animations_1.style({
                        "opacity": 1,
                        transform: "scale(1)"
                    })),
                    animations_1.state("void", animations_1.style({
                        "opacity": 0,
                        transform: "scale(0.9)"
                    })),
                    animations_1.transition("void => *", [animations_1.animate("1100ms ease-out")])
                ])
            ]
        }),
        __metadata("design:paramtypes", [menu_component_1.MenuComponent,
            core_1.ViewContainerRef,
            nativescript_angular_1.ModalDialogService,
            toast_service_1.ToastService])
    ], AppIconComponent);
    return AppIconComponent;
}(abstract_menu_page_component_1.AbstractMenuPageComponent));
exports.AppIconComponent = AppIconComponent;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBwaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJhcHBpY29uLmNvbXBvbmVudC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUEsc0NBQW9FO0FBQ3BFLGtEQUFpRjtBQUNqRixnRkFBNEU7QUFDNUUseURBQXVEO0FBQ3ZELDZEQUEwRDtBQUMxRCxxREFBbUQ7QUFDbkQscUVBQWtFO0FBQ2xFLCtFQUErRDtBQUMvRCwyREFBeUQ7QUFDekQseUVBQTBEO0FBeUMxRDtJQUFzQyxvQ0FBeUI7SUFNN0QsMEJBQXNCLGFBQTRCLEVBQzVCLEtBQXVCLEVBQ3ZCLFlBQWdDLEVBQ2xDLFlBQTBCO1FBSDlDLFlBSUUsa0JBQU0sYUFBYSxFQUFFLEtBQUssRUFBRSxZQUFZLENBQUMsU0FJMUM7UUFScUIsbUJBQWEsR0FBYixhQUFhLENBQWU7UUFDNUIsV0FBSyxHQUFMLEtBQUssQ0FBa0I7UUFDdkIsa0JBQVksR0FBWixZQUFZLENBQW9CO1FBQ2xDLGtCQUFZLEdBQVosWUFBWSxDQUFjO1FBUjlDLHdDQUFrQyxHQUFZLEtBQUssQ0FBQztRQVVsRCxLQUFJLENBQUMsY0FBYyxHQUFHLElBQUksOENBQWMsRUFBRSxDQUFDO1FBQzNDLEtBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSx5Q0FBWSxFQUFFLENBQUM7UUFDdkMsS0FBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxJQUFJLENBQUMsVUFBQSxLQUFLLElBQUksT0FBQSxLQUFJLENBQUMsb0JBQW9CLEdBQUcsS0FBSyxFQUFqQyxDQUFpQyxDQUFDLENBQUM7O0lBQ2pGLENBQUM7SUFFRCxtQ0FBUSxHQUFSO0lBQ0EsQ0FBQztJQUVELHNDQUFXLEdBQVg7UUFBQSxpQkFjQztRQWJDLElBQUksQ0FBQyxZQUFZLENBQUMscUJBQXFCLENBQUM7WUFDdEM7Z0JBQ0UsSUFBSSxFQUFFLFNBQVM7Z0JBQ2YsS0FBSyxFQUFFLFNBQVM7Z0JBQ2hCLFFBQVEsRUFBRSxxQkFBcUI7Z0JBQy9CLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxPQUE0QyxJQUFJO2dCQUNwRSxZQUFZLEVBQUUsTUFBTTthQUNyQjtTQUNGLENBQUMsQ0FBQyxJQUFJLENBQUM7WUFDTixLQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxvRUFBb0UsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNyRyxDQUFDLEVBQUUsVUFBQSxHQUFHO1lBQ0osS0FBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsWUFBVSxHQUFLLENBQUMsQ0FBQztRQUMxQyxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCx5Q0FBYyxHQUFkO1FBQUEsaUJBUUM7UUFQQyxJQUFJLENBQUMsWUFBWSxDQUFDLHFCQUFxQixDQUNuQyxFQUFFLENBQ0wsQ0FBQyxJQUFJLENBQUM7WUFDTCxLQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1FBQ3JELENBQUMsRUFBRSxVQUFBLEdBQUc7WUFDSixLQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxZQUFVLEdBQUssQ0FBQyxDQUFDO1FBQzFDLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELHdDQUFhLEdBQWIsVUFBYyxJQUFtQjtRQUFqQyxpQkFTQztRQVJDLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDO1lBQzdCLFFBQVEsRUFBRSxJQUFJO1lBQ2Qsd0JBQXdCLEVBQUUsSUFBSSxDQUFDLGtDQUFrQztTQUNsRSxDQUFDLENBQUMsSUFBSSxDQUFDO1FBRVIsQ0FBQyxFQUFFLFVBQUMsS0FBVTtZQUNaLEtBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGlCQUFlLEtBQUssQ0FBQyxJQUFJLHlCQUFvQixLQUFLLENBQUMsT0FBUyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQzdGLENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVTLHdDQUFhLEdBQXZCO1FBQ0UsTUFBTSxDQUFDLElBQUksdUNBQWlCLENBQ3hCLDJEQUEyRCxFQUMzRCxLQUFLLENBQUMsRUFBRSxDQUNKLElBQUksd0JBQVUsQ0FDViw0QkFBNEIsRUFDNUIsZUFBZSxFQUNmLDhEQUE4RCxFQUM5RCw4Q0FBOEMsQ0FBQyxFQUVuRCxJQUFJLHdCQUFVLENBQ1YsK0JBQStCLEVBQy9CLHlCQUF5QixFQUN6QixpRUFBaUUsRUFDakUscUVBQXFFLENBQ3hFLENBQ0osQ0FDSixDQUFDO0lBQ0osQ0FBQztJQTFFVSxnQkFBZ0I7UUF2QzVCLGdCQUFTLENBQUM7WUFDVCxRQUFRLEVBQUUsY0FBYztZQUN4QixRQUFRLEVBQUUsTUFBTSxDQUFDLEVBQUU7WUFDbkIsV0FBVyxFQUFFLDBCQUEwQjtZQUN2QyxTQUFTLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQztZQUNqQyxVQUFVLEVBQUU7Z0JBQ1Ysb0JBQU8sQ0FBQyxhQUFhLEVBQUU7b0JBQ3JCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3dCQUNaLFNBQVMsRUFBRSxlQUFlO3FCQUMzQixDQUFDLENBQUM7b0JBQ0gsa0JBQUssQ0FBQyxNQUFNLEVBQUUsa0JBQUssQ0FBQzt3QkFDbEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLGlCQUFpQjtxQkFDN0IsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDLENBQUM7aUJBQzVELENBQUM7Z0JBQ0Ysb0JBQU8sQ0FBQyxTQUFTLEVBQUU7b0JBQ2pCLGtCQUFLLENBQUMsSUFBSSxFQUFFLGtCQUFLLENBQUM7d0JBQ2hCLFNBQVMsRUFBRSxDQUFDO3FCQUNiLENBQUMsQ0FBQztvQkFDSCxrQkFBSyxDQUFDLE1BQU0sRUFBRSxrQkFBSyxDQUFDO3dCQUNsQixTQUFTLEVBQUUsQ0FBQztxQkFDYixDQUFDLENBQUM7b0JBQ0gsdUJBQVUsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxvQkFBTyxDQUFDLHVCQUF1QixDQUFDLENBQUMsQ0FBQztpQkFDNUQsQ0FBQztnQkFDRixvQkFBTyxDQUFDLFVBQVUsRUFBRTtvQkFDbEIsa0JBQUssQ0FBQyxJQUFJLEVBQUUsa0JBQUssQ0FBQzt3QkFDaEIsU0FBUyxFQUFFLENBQUM7d0JBQ1osU0FBUyxFQUFFLFVBQVU7cUJBQ3RCLENBQUMsQ0FBQztvQkFDSCxrQkFBSyxDQUFDLE1BQU0sRUFBRSxrQkFBSyxDQUFDO3dCQUNsQixTQUFTLEVBQUUsQ0FBQzt3QkFDWixTQUFTLEVBQUUsWUFBWTtxQkFDeEIsQ0FBQyxDQUFDO29CQUNILHVCQUFVLENBQUMsV0FBVyxFQUFFLENBQUMsb0JBQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUM7aUJBQ3RELENBQUM7YUFDSDtTQUNGLENBQUM7eUNBT3FDLDhCQUFhO1lBQ3JCLHVCQUFnQjtZQUNULHlDQUFrQjtZQUNwQiw0QkFBWTtPQVRuQyxnQkFBZ0IsQ0E0RTVCO0lBQUQsdUJBQUM7Q0FBQSxBQTVFRCxDQUFzQyx3REFBeUIsR0E0RTlEO0FBNUVZLDRDQUFnQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbXBvbmVudCwgT25Jbml0LCBWaWV3Q29udGFpbmVyUmVmIH0gZnJvbSBcIkBhbmd1bGFyL2NvcmVcIjtcclxuaW1wb3J0IHsgYW5pbWF0ZSwgc3RhdGUsIHN0eWxlLCB0cmFuc2l0aW9uLCB0cmlnZ2VyIH0gZnJvbSBcIkBhbmd1bGFyL2FuaW1hdGlvbnNcIjtcclxuaW1wb3J0IHsgQWJzdHJhY3RNZW51UGFnZUNvbXBvbmVudCB9IGZyb20gXCIuLi9hYnN0cmFjdC1tZW51LXBhZ2UtY29tcG9uZW50XCI7XHJcbmltcG9ydCB7IE1lbnVDb21wb25lbnQgfSBmcm9tIFwiLi4vbWVudS9tZW51LmNvbXBvbmVudFwiO1xyXG5pbXBvcnQgeyBNb2RhbERpYWxvZ1NlcnZpY2UgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFuZ3VsYXJcIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mbyB9IGZyb20gXCIuLi9zaGFyZWQvcGx1Z2luLWluZm9cIjtcclxuaW1wb3J0IHsgUGx1Z2luSW5mb1dyYXBwZXIgfSBmcm9tIFwiLi4vc2hhcmVkL3BsdWdpbi1pbmZvLXdyYXBwZXJcIjtcclxuaW1wb3J0IHsgQXBwSWNvbkNoYW5nZXIgfSBmcm9tIFwibmF0aXZlc2NyaXB0LWFwcC1pY29uLWNoYW5nZXJcIjtcclxuaW1wb3J0IHsgVG9hc3RTZXJ2aWNlIH0gZnJvbSBcIi4uL3NlcnZpY2VzL3RvYXN0LnNlcnZpY2VcIjtcclxuaW1wb3J0IHsgQXBwU2hvcnRjdXRzIH0gZnJvbSBcIm5hdGl2ZXNjcmlwdC1hcHAtc2hvcnRjdXRzXCI7XHJcblxyXG5AQ29tcG9uZW50KHtcclxuICBzZWxlY3RvcjogXCJwYWdlLWFwcGljb25cIixcclxuICBtb2R1bGVJZDogbW9kdWxlLmlkLFxyXG4gIHRlbXBsYXRlVXJsOiBcIi4vYXBwaWNvbi5jb21wb25lbnQuaHRtbFwiLFxyXG4gIHN0eWxlVXJsczogW1wiYXBwaWNvbi1jb21tb24uY3NzXCJdLFxyXG4gIGFuaW1hdGlvbnM6IFtcclxuICAgIHRyaWdnZXIoXCJmcm9tLWJvdHRvbVwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAxLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGVZKDApXCJcclxuICAgICAgfSkpLFxyXG4gICAgICBzdGF0ZShcInZvaWRcIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAwLFxyXG4gICAgICAgIHRyYW5zZm9ybTogXCJ0cmFuc2xhdGVZKDIwJSlcIlxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCIxNjAwbXMgNzAwbXMgZWFzZS1vdXRcIildKVxyXG4gICAgXSksXHJcbiAgICB0cmlnZ2VyKFwiZmFkZS1pblwiLCBbXHJcbiAgICAgIHN0YXRlKFwiaW5cIiwgc3R5bGUoe1xyXG4gICAgICAgIFwib3BhY2l0eVwiOiAxXHJcbiAgICAgIH0pKSxcclxuICAgICAgc3RhdGUoXCJ2b2lkXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMFxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCI4MDBtcyAyMDAwbXMgZWFzZS1vdXRcIildKVxyXG4gICAgXSksXHJcbiAgICB0cmlnZ2VyKFwic2NhbGUtaW5cIiwgW1xyXG4gICAgICBzdGF0ZShcImluXCIsIHN0eWxlKHtcclxuICAgICAgICBcIm9wYWNpdHlcIjogMSxcclxuICAgICAgICB0cmFuc2Zvcm06IFwic2NhbGUoMSlcIlxyXG4gICAgICB9KSksXHJcbiAgICAgIHN0YXRlKFwidm9pZFwiLCBzdHlsZSh7XHJcbiAgICAgICAgXCJvcGFjaXR5XCI6IDAsXHJcbiAgICAgICAgdHJhbnNmb3JtOiBcInNjYWxlKDAuOSlcIlxyXG4gICAgICB9KSksXHJcbiAgICAgIHRyYW5zaXRpb24oXCJ2b2lkID0+ICpcIiwgW2FuaW1hdGUoXCIxMTAwbXMgZWFzZS1vdXRcIildKVxyXG4gICAgXSlcclxuICBdXHJcbn0pXHJcbmV4cG9ydCBjbGFzcyBBcHBJY29uQ29tcG9uZW50IGV4dGVuZHMgQWJzdHJhY3RNZW51UGFnZUNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCB7XHJcbiAgc3VwcHJlc3NBcHBJY29uQ2hhbmdlZE5vdGlmaWNhdGlvbjogYm9vbGVhbiA9IGZhbHNlO1xyXG4gIHN1cHBvcnRzQXBwU2hvcnRjdXRzOiBib29sZWFuO1xyXG4gIHByaXZhdGUgYXBwSWNvbkNoYW5nZXI6IEFwcEljb25DaGFuZ2VyO1xyXG4gIHByaXZhdGUgYXBwU2hvcnRjdXRzOiBBcHBTaG9ydGN1dHM7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb3RlY3RlZCBtZW51Q29tcG9uZW50OiBNZW51Q29tcG9uZW50LFxyXG4gICAgICAgICAgICAgIHByb3RlY3RlZCB2Y1JlZjogVmlld0NvbnRhaW5lclJlZixcclxuICAgICAgICAgICAgICBwcm90ZWN0ZWQgbW9kYWxTZXJ2aWNlOiBNb2RhbERpYWxvZ1NlcnZpY2UsXHJcbiAgICAgICAgICAgICAgcHJpdmF0ZSB0b2FzdFNlcnZpY2U6IFRvYXN0U2VydmljZSkge1xyXG4gICAgc3VwZXIobWVudUNvbXBvbmVudCwgdmNSZWYsIG1vZGFsU2VydmljZSk7XHJcbiAgICB0aGlzLmFwcEljb25DaGFuZ2VyID0gbmV3IEFwcEljb25DaGFuZ2VyKCk7XHJcbiAgICB0aGlzLmFwcFNob3J0Y3V0cyA9IG5ldyBBcHBTaG9ydGN1dHMoKTtcclxuICAgIHRoaXMuYXBwU2hvcnRjdXRzLmF2YWlsYWJsZSgpLnRoZW4oYXZhaWwgPT4gdGhpcy5zdXBwb3J0c0FwcFNob3J0Y3V0cyA9IGF2YWlsKTtcclxuICB9XHJcblxyXG4gIG5nT25Jbml0KCk6IHZvaWQge1xyXG4gIH1cclxuXHJcbiAgYWRkRGVlcGxpbmsoKTogdm9pZCB7XHJcbiAgICB0aGlzLmFwcFNob3J0Y3V0cy5jb25maWd1cmVRdWlja0FjdGlvbnMoW1xyXG4gICAgICB7XHJcbiAgICAgICAgdHlwZTogXCJtYXBwaW5nXCIsXHJcbiAgICAgICAgdGl0bGU6IFwiTWFwcGluZ1wiLFxyXG4gICAgICAgIHN1YnRpdGxlOiBcIkRlZXBsaW5rIHRvIE1hcHBpbmdcIixcclxuICAgICAgICBpY29uVHlwZTogdGhpcy5pc0lPUyA/IFVJQXBwbGljYXRpb25TaG9ydGN1dEljb25UeXBlLkxvY2F0aW9uIDogbnVsbCxcclxuICAgICAgICBpY29uVGVtcGxhdGU6IFwibWFwc1wiIC8vIHJlZmVycyB0byBBcHBfUmVzb3VyY2VzL0FuZHJvaWQvZHJhd2FibGUtbm9kcGkvbWFwcy5wbmcgKG5vdCB1c2VkIG9uIGlPUyBzaW5jZSAnaWNvblR5cGUnIHdhcyBzZXQgYXMgd2VsbClcclxuICAgICAgfVxyXG4gICAgXSkudGhlbigoKSA9PiB7XHJcbiAgICAgIHRoaXMudG9hc3RTZXJ2aWNlLnNob3coXCJDbG9zZSB0aGUgYXBwIGFuZCBwcmVzcyB0aGUgYXBwIGljb24gaGFyZCB0byBzZWUgdGhlIG5ldyBkZWVwbGluayFcIiwgdHJ1ZSk7XHJcbiAgICB9LCBlcnIgPT4ge1xyXG4gICAgICB0aGlzLnRvYXN0U2VydmljZS5zaG93KGBFcnJvcjogJHtlcnJ9YCk7XHJcbiAgICB9KTtcclxuICB9XHJcblxyXG4gIHJlbW92ZURlZXBsaW5rKCk6IHZvaWQge1xyXG4gICAgdGhpcy5hcHBTaG9ydGN1dHMuY29uZmlndXJlUXVpY2tBY3Rpb25zKFxyXG4gICAgICAgIFtdXHJcbiAgICApLnRoZW4oKCkgPT4ge1xyXG4gICAgICB0aGlzLnRvYXN0U2VydmljZS5zaG93KFwiRHluYW1pYyBkZWVwbGluayByZW1vdmVkXCIpO1xyXG4gICAgfSwgZXJyID0+IHtcclxuICAgICAgdGhpcy50b2FzdFNlcnZpY2Uuc2hvdyhgRXJyb3I6ICR7ZXJyfWApO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBjaGFuZ2VBcHBJY29uKG5hbWU6IHN0cmluZyB8IG51bGwpOiB2b2lkIHtcclxuICAgIHRoaXMuYXBwSWNvbkNoYW5nZXIuY2hhbmdlSWNvbih7XHJcbiAgICAgIGljb25OYW1lOiBuYW1lLFxyXG4gICAgICBzdXBwcmVzc1VzZXJOb3RpZmljYXRpb246IHRoaXMuc3VwcHJlc3NBcHBJY29uQ2hhbmdlZE5vdGlmaWNhdGlvbiAvLyBkZWZhdWx0IHRydWVcclxuICAgIH0pLnRoZW4oKCkgPT4ge1xyXG4gICAgICAvLyBub3RoaW5nIHRvIGRvIGFzIHRoZXJlJ3MgYWxyZWFkeSBhIHByb21wdCBiZWluZyBzaG93blxyXG4gICAgfSwgKGVycm9yOiBhbnkpID0+IHtcclxuICAgICAgdGhpcy50b2FzdFNlcnZpY2Uuc2hvdyhgRXJyb3IgY29kZTogJHtlcnJvci5jb2RlfSwgRXJyb3IgbWVzc2FnZTogJHtlcnJvci5tZXNzYWdlfWAsIHRydWUpO1xyXG4gICAgfSk7XHJcbiAgfVxyXG5cclxuICBwcm90ZWN0ZWQgZ2V0UGx1Z2luSW5mbygpOiBQbHVnaW5JbmZvV3JhcHBlciB7XHJcbiAgICByZXR1cm4gbmV3IFBsdWdpbkluZm9XcmFwcGVyKFxyXG4gICAgICAgIFwiRmlkZGxlIHdpdGggeW91ciBhcHAncyBob21lIGljb24uIEN1cnJlbnRseSBmb3IgaU9TIG9ubHkuXCIsXHJcbiAgICAgICAgQXJyYXkub2YoXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtYXBwLXNob3J0Y3V0c1wiLFxyXG4gICAgICAgICAgICAgICAgXCJBcHAgU2hvcnRjdXRzXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9FZGR5VmVyYnJ1Z2dlbi9uYXRpdmVzY3JpcHQtYXBwLXNob3J0Y3V0c1wiLFxyXG4gICAgICAgICAgICAgICAgXCJIb21lIEljb24gQWN0aW9ucyBmb3IgeW91ciBOYXRpdmVTY3JpcHQgYXBwLlwiKSxcclxuXHJcbiAgICAgICAgICAgIG5ldyBQbHVnaW5JbmZvKFxyXG4gICAgICAgICAgICAgICAgXCJuYXRpdmVzY3JpcHQtYXBwLWljb24tY2hhbmdlclwiLFxyXG4gICAgICAgICAgICAgICAgXCJBcHAgSWNvbiBDaGFuZ2VyICDtoLztv6Ag7aC97bSBXCIsXHJcbiAgICAgICAgICAgICAgICBcImh0dHBzOi8vZ2l0aHViLmNvbS9FZGR5VmVyYnJ1Z2dlbi9uYXRpdmVzY3JpcHQtYXBwLWljb24tY2hhbmdlclwiLFxyXG4gICAgICAgICAgICAgICAgXCJDaGFuZ2UgdGhlIGhvbWVzY3JlZW4gaWNvbiBvZiB5b3VyIE5hdGl2ZVNjcmlwdCBpT1MgYXBwIGF0IHJ1bnRpbWUhXCJcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgIClcclxuICAgICk7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0=